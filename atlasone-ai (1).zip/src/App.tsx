/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  Activity,
  AlertTriangle,
  Award,
  Bot,
  Brain,
  Camera,
  CheckCircle,
  Coins,
  Cpu,
  Download,
  Flame,
  Heart,
  Layers,
  Lightbulb,
  Locate,
  MapPin,
  MessageSquare,
  Mic,
  Navigation,
  Plus,
  RotateCcw,
  Search,
  Send,
  Share2,
  ShieldAlert,
  Sparkles,
  TrendingUp,
  User,
  Users,
  Volume2,
  Wrench,
  Zap,
  MoreHorizontal,
  Menu,
  X,
  Lock,
  Unlock,
  Globe,
  RefreshCw,
  Database,
  FileText,
  Link,
  Upload,
  Smartphone,
  Copy,
  Check,
  Sun,
  Moon,
  Palette,
  ChevronDown,
  ChevronUp,
  Phone
} from 'lucide-react';
import { Issue, UserProfile, NGOProject, CSRCampaign, PredictiveHotspot, ChatMessage } from './types';

const RAW_MAPPLS_KEY =
  process.env.MAPPLS_API_KEY ||
  (import.meta as any).env?.VITE_MAPPLS_API_KEY ||
  (globalThis as any).MAPPLS_API_KEY ||
  process.env.GOOGLE_MAPS_PLATFORM_KEY ||
  (import.meta as any).env?.VITE_GOOGLE_MAPS_PLATFORM_KEY ||
  (globalThis as any).GOOGLE_MAPS_PLATFORM_KEY ||
  '';
const MAPPLS_KEY = RAW_MAPPLS_KEY.trim().replace(/^['"]|['"]$/g, '');
const hasMapplsKey = Boolean(MAPPLS_KEY) && MAPPLS_KEY !== 'YOUR_MAPPLS_KEY' && MAPPLS_KEY.length > 5;

const LOCAL_EMERGENCY_CONTACTS: Record<string, {
  cityName: string;
  contacts: { label: string; number: string; desc: string }[];
}> = {
  bengaluru: {
    cityName: 'Bengaluru (BBMP Area)',
    contacts: [
      { label: 'BBMP Central Control Room', number: '080-22221188', desc: 'Main civic disaster & flood control cell' },
      { label: 'BBMP Ward Nodal Office', number: '080-22133016', desc: 'Local ward-level grievance and emergency coordination' },
      { label: 'NDRF / SDRF South Unit', number: '080-22340676', desc: 'National/State Disaster Response Forces' },
      { label: 'Victoria Hospital Trauma Care', number: '080-22979294', desc: 'Primary government trauma and accident hospital' },
      { label: 'BESCOM Electricity Desk', number: '1912', desc: 'Power outages, sparks, or fallen power line alerts' },
      { label: 'BWSSB Sewage & Water Desk', number: '1916', desc: 'Critical sewer overflows and water grid issues' },
    ]
  },
  darbhanga: {
    cityName: 'Darbhanga (DMC Area)',
    contacts: [
      { label: 'DMC Municipal Nodal Control', number: '06272-222405', desc: 'Darbhanga Municipal Corporation civic cell' },
      { label: 'District Disaster Control Room', number: '06272-220033', desc: 'Floods, heavy rainfall, and disaster management' },
      { label: 'Darbhanga Medical College DMCH', number: '06272-233003', desc: 'State-run medical college & trauma response' },
      { label: 'Local Police Nodal Officer', number: '9431818385', desc: 'Emergency law enforcement coordinator' },
      { label: 'District Emergency Helpline', number: '06272-222575', desc: 'General public safety & administration helpline' },
      { label: 'Electricity Grievance Desk', number: '1912', desc: 'Fallen transformer or power failure support' },
    ]
  },
  patna: {
    cityName: 'Patna (PMC Area)',
    contacts: [
      { label: 'PMC Municipal Control Room', number: '0612-2211107', desc: 'Patna Municipal Corporation core helpline' },
      { label: 'Patna Medical College PMCH', number: '0612-2300080', desc: 'Primary government emergency ward' },
      { label: 'Bihar Disaster Management Cell', number: '1070', desc: 'State-level disaster & flood relief' },
      { label: 'Patna Police Helpline', number: '9431820421', desc: 'Local police control room chief desk' },
      { label: 'District Emergency Center', number: '0612-2217305', desc: 'Patna district command & control hub' },
      { label: 'PESU Electricity Helpline', number: '9264437206', desc: 'Power failures, wire snaps, and grid issues' },
    ]
  },
  mumbai: {
    cityName: 'Mumbai (BMC Area)',
    contacts: [
      { label: 'BMC Disaster Control Room', number: '1916', desc: 'Main Brihanmumbai Municipal Corp helpline' },
      { label: 'KEM Hospital Trauma Center', number: '022-24107000', desc: 'Primary public medical emergency cell' },
      { label: 'Mumbai Fire Division Station', number: '022-23076111', desc: 'Fire rescue and chemical spill response' },
      { label: 'BEST Electricity Emergency', number: '1800 227 575', desc: 'BEST power distribution control desk' },
      { label: 'Adani Power Emergency Desk', number: '19122', desc: 'Suburban power supply alerts' },
      { label: 'BMC Commissioner Nodal Line', number: '022-22620251', desc: 'High-level civic emergency coordination' },
    ]
  },
  delhi: {
    cityName: 'New Delhi (MCD Area)',
    contacts: [
      { label: 'MCD Central Control Room', number: '1266', desc: 'Municipal Corporation of Delhi civic emergency' },
      { label: 'Delhi Disaster Management DDMA', number: '1077', desc: 'DDMA centralized rescue and safety dispatch' },
      { label: 'AIIMS Trauma Center Helpline', number: '011-26593188', desc: 'Premier trauma care and emergency facility' },
      { label: 'Delhi Fire Service Control', number: '011-23412222', desc: 'Central fire rescue service control' },
      { label: 'BSES Yamuna Power Desk', number: '19123', desc: 'Power disruption and live wire emergency desk' },
      { label: 'Delhi Jal Board Water Emergency', number: '011-23527679', desc: 'Water contamination & pipeline burst control' },
    ]
  }
};

const mapCenters: Record<string, { lat: number; lng: number; address: string }> = {
  bengaluru: { lat: 12.9716, lng: 77.5946, address: 'Kanakapura Main Rd, Bengaluru, KA' },
  darbhanga: { lat: 26.1542, lng: 85.8918, address: 'Laheriasarai Tower Chowk, Darbhanga, BIH' },
  patna: { lat: 25.5941, lng: 85.1376, address: 'Boring Road Crossing, Patna, BIH' },
  mumbai: { lat: 18.9750, lng: 72.8258, address: 'Marine Drive Road, Mumbai, MH' },
  delhi: { lat: 28.6139, lng: 77.2090, address: 'Connaught Place Ring, New Delhi, DL' }
};


interface MapplsMapProps {
  center: { lat: number; lng: number };
  issues: any[];
  hotspots: any[];
  selectedCity: string;
  onIssueClick: (issue: any) => void;
  userLiveLocation: { lat: number; lng: number } | null;
}

function MapplsMapComponent({ center, issues, hotspots, selectedCity, onIssueClick, userLiveLocation }: MapplsMapProps) {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<any>(null);
  const markersRef = useRef<any[]>([]);
  const [scriptLoaded, setScriptLoaded] = useState(false);
  const [loadError, setLoadError] = useState(false);

  // Load script
  useEffect(() => {
    const scriptId = 'mappls-sdk-script';
    let script = document.getElementById(scriptId) as HTMLScriptElement;

    const onScriptLoad = () => {
      if ((window as any).mappls) {
        setScriptLoaded(true);
      } else {
        setLoadError(true);
      }
    };

    const onScriptError = () => {
      setLoadError(true);
    };

    if (!script) {
      script = document.createElement('script');
      script.id = scriptId;
      script.src = `https://apis.mappls.com/advanced-maps/api/${MAPPLS_KEY}/map_sdk?v=3.0&layer=vector`;
      script.async = true;
      script.defer = true;
      script.onload = onScriptLoad;
      script.onerror = onScriptError;
      document.head.appendChild(script);
    } else {
      if ((window as any).mappls) {
        setScriptLoaded(true);
      } else {
        script.addEventListener('load', onScriptLoad);
        script.addEventListener('error', onScriptError);
      }
    }

    return () => {
      if (script) {
        script.removeEventListener('load', onScriptLoad);
        script.removeEventListener('error', onScriptError);
      }
    };
  }, []);

  // Initialize and update Map
  useEffect(() => {
    if (!scriptLoaded || !mapContainerRef.current) return;

    const mappls = (window as any).mappls;
    if (!mappls || !mappls.Map) {
      setLoadError(true);
      return;
    }

    // Clean up previous markers
    markersRef.current.forEach(m => {
      if (m && typeof m.remove === 'function') {
        try {
          m.remove();
        } catch (e) {
          console.error(e);
        }
      }
    });
    markersRef.current = [];

    // If map does not exist, create it
    if (!mapInstanceRef.current) {
      try {
        mapInstanceRef.current = new mappls.Map(mapContainerRef.current, {
          center: [center.lat, center.lng],
          zoom: 12,
          zoomControl: true,
          hybrid: false
        });
      } catch (err) {
        console.error('Error initializing Mappls map:', err);
        setLoadError(true);
        return;
      }
    } else {
      // Re-center map when city/center changes
      try {
        mapInstanceRef.current.setCenter([center.lat, center.lng]);
      } catch (e) {
        console.error('Error setting center:', e);
      }
    }

    const map = mapInstanceRef.current;

    // Add User Live Location Pin
    if (userLiveLocation) {
      try {
        const userMarker = new mappls.Marker({
          map: map,
          position: [userLiveLocation.lat, userLiveLocation.lng],
          html: `<div class="relative flex items-center justify-center">
                   <span class="absolute inline-flex h-8 w-8 rounded-full bg-teal-400/40 animate-ping"></span>
                   <span class="relative rounded-full h-4 w-4 bg-teal-400 border border-slate-950 shadow-md"></span>
                 </div>`
        });
        markersRef.current.push(userMarker);
      } catch (e) {
        console.error(e);
      }
    }

    // Add Issue Markers
    issues.filter(i => (i.city || 'bengaluru') === selectedCity).forEach(issue => {
      try {
        const color = issue.status === 'completed' || issue.status === 'confirmed' ? '#10b981' : (issue.status === 'in_progress' ? '#f59e0b' : '#ef4444');
        const marker = new mappls.Marker({
          map: map,
          position: [issue.location.lat, issue.location.lng],
          html: `<div style="cursor: pointer; display: flex; align-items: center; justify-content: center; width: 14px; height: 14px; border-radius: 50%; background-color: ${color}; border: 2px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.4);" title="${issue.title}"></div>`
        });

        marker.addListener('click', () => {
          onIssueClick(issue);
        });

        markersRef.current.push(marker);
      } catch (e) {
        console.error(e);
      }
    });

    // Add AI Predictive Hotspots
    hotspots.forEach(hotspot => {
      try {
        const marker = new mappls.Marker({
          map: map,
          position: [hotspot.lat, hotspot.lng],
          html: `<div class="relative flex items-center justify-center" title="AI Hotspot: ${hotspot.riskLevel} Risk">
                   <span class="absolute inline-flex h-8 w-8 rounded-full bg-rose-500/25 animate-pulse"></span>
                   <span class="relative rounded-full h-3 w-3 bg-rose-500 border border-slate-950 shadow-md"></span>
                 </div>`
        });
        markersRef.current.push(marker);
      } catch (e) {
        console.error(e);
      }
    });

  }, [scriptLoaded, center, selectedCity, issues, hotspots, userLiveLocation, onIssueClick]);

  if (loadError) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-6 text-center bg-rose-950/20 text-rose-200">
        <p className="font-bold uppercase text-[11px] tracking-wider text-rose-400 mb-1">Mappls Load Error</p>
        <p className="text-xs text-slate-300 leading-relaxed max-w-sm">
          Failed to load MapmyIndia Mappls SDK. Please verify your <code className="bg-slate-950 text-rose-300 px-1 py-0.5 rounded text-[10px]">MAPPLS_API_KEY</code> is valid.
        </p>
      </div>
    );
  }

  if (!scriptLoaded) {
    return (
      <div className="flex flex-col items-center justify-center h-full bg-slate-950/40">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-teal-500 mb-3"></div>
        <p className="text-xs text-slate-400 font-mono">Loading Mappls India Map...</p>
      </div>
    );
  }

  return (
    <div className="w-full h-full relative" style={{ minHeight: '100%' }}>
      <div ref={mapContainerRef} className="w-full h-full rounded-xl" style={{ minHeight: '100%', height: '100%' }} />
      <div className="absolute bottom-2 right-2 bg-slate-950/90 text-[10px] text-slate-400 px-2 py-1 rounded border border-slate-800 pointer-events-none z-10 font-mono">
        Mappls MapmyIndia Active
      </div>
    </div>
  );
}


const userProfiles: Record<string, { displayName: string }> = {
  worker_sam: { displayName: 'Sam Bahadur' },
};

interface MCOfficial {
  role: string;
  name: string;
  contact: string;
}

interface MCDetails {
  name: string;
  code: string;
  headTitle: string;
  headName: string;
  email: string;
  phone: string;
  helpline: string;
  address: string;
  colorClass: string;
  bgGradient: string;
  officials: MCOfficial[];
}

export const MUNICIPAL_DATA: Record<string, MCDetails> = {
  bengaluru: {
    name: 'Bruhat Bengaluru Mahanagara Palike (BBMP)',
    code: 'BBMP-KA-12',
    headTitle: 'Chief Commissioner',
    headName: 'Shri Tushar Giri Nath, IAS',
    email: 'comm@bbmp.gov.in',
    phone: '+91 80 2222 1188',
    helpline: '080-2266-0000',
    address: 'BBMP Head Office, Hudson Circle, Bengaluru, Karnataka 560002',
    colorClass: 'text-emerald-400 border-emerald-500/30 bg-emerald-500/10',
    bgGradient: 'from-emerald-600/10 to-teal-600/10 border-emerald-800/40',
    officials: [
      { role: 'Chief Commissioner', name: 'Shri Tushar Giri Nath, IAS', contact: '+91 80 2222 1188' },
      { role: 'Special Commissioner (Solid Waste)', name: 'Shri Suralkar Vikas Kishore, IAS', contact: '+91 80 2222 3112' },
      { role: 'Zonal Commissioner (Indiranagar)', name: 'Smt. Preeti Gehlot, IAS', contact: '+91 94806 83011' }
    ]
  },
  darbhanga: {
    name: 'Darbhanga Municipal Corporation (DMC)',
    code: 'DMC-BIH-04',
    headTitle: 'Municipal Commissioner',
    headName: 'Dr. Kumar Gaurav, IAS',
    email: 'commissioner-dmc-bih@nic.in',
    phone: '+91 6272 222 301',
    helpline: '1800-345-6192',
    address: 'Municipal Corporation Road, Laheriasarai, Darbhanga, Bihar 846001',
    colorClass: 'text-indigo-400 border-indigo-500/30 bg-indigo-500/10',
    bgGradient: 'from-blue-600/10 to-indigo-600/10 border-indigo-800/40',
    officials: [
      { role: 'Municipal Commissioner', name: 'Dr. Kumar Gaurav, IAS', contact: '+91 6272 222 301' },
      { role: 'Mayor of Darbhanga', name: 'Smt. Anjum Ara', contact: '+91 6272 222 302' },
      { role: 'Deputy Mayor', name: 'Shri Nazia Hasan', contact: '+91 6272 222 303' },
      { role: 'Chief Sanitation Inspector', name: 'Shri R. K. Mishra', contact: '+91 94318 76543' }
    ]
  },
  patna: {
    name: 'Patna Municipal Corporation (PMC)',
    code: 'PMC-BIH-01',
    headTitle: 'Municipal Commissioner',
    headName: 'Shri Animesh Kumar Parashar, IAS',
    email: 'patnamunicipalcorporation@gmail.com',
    phone: '+91 612 221 0251',
    helpline: '155304',
    address: 'Maurya Lok Complex, C-Block, Patna, Bihar 800001',
    colorClass: 'text-amber-400 border-amber-500/30 bg-amber-500/10',
    bgGradient: 'from-amber-600/10 to-orange-600/10 border-amber-800/40',
    officials: [
      { role: 'Municipal Commissioner', name: 'Shri Animesh Kumar Parashar, IAS', contact: '+91 612 221 0251' },
      { role: 'Mayor of Patna', name: 'Smt. Sita Sahu', contact: '+91 612 221 0252' },
      { role: 'Deputy Mayor', name: 'Shri Reshma Prasad', contact: '+91 612 221 0253' }
    ]
  },
  mumbai: {
    name: 'Brihanmumbai Municipal Corporation (BMC)',
    code: 'BMC-MH-01',
    headTitle: 'Municipal Commissioner',
    headName: 'Shri Bhushan Gagrani, IAS',
    email: 'mc@mcgm.gov.in',
    phone: '+91 22 2262 0251',
    helpline: '1916',
    address: 'BMC Headquarters, Mahapalika Marg, Mumbai, Maharashtra 400001',
    colorClass: 'text-sky-400 border-sky-500/30 bg-sky-500/10',
    bgGradient: 'from-sky-600/10 to-blue-600/10 border-sky-800/40',
    officials: [
      { role: 'Municipal Commissioner', name: 'Shri Bhushan Gagrani, IAS', contact: '+91 22 2262 0251' },
      { role: 'Additional Commissioner (City)', name: 'Shri Ashwini Joshi, IAS', contact: '+91 22 2262 0252' },
      { role: 'Chief Engineer (Roads)', name: 'Shri Sanjay Darade', contact: '+91 98200 12345' }
    ]
  },
  delhi: {
    name: 'Municipal Corporation of Delhi (MCD)',
    code: 'MCD-DL-01',
    headTitle: 'Commissioner',
    headName: 'Shri Gyanesh Bharti, IAS',
    email: 'commissioner@mcd.nic.in',
    phone: '+91 11 2322 0011',
    helpline: '1266',
    address: 'Civic Centre, Minto Road, New Delhi 110002',
    colorClass: 'text-rose-400 border-rose-500/30 bg-rose-500/10',
    bgGradient: 'from-rose-600/10 to-pink-600/10 border-rose-800/40',
    officials: [
      { role: 'Commissioner', name: 'Shri Gyanesh Bharti, IAS', contact: '+91 11 2322 0011' },
      { role: 'Mayor of Delhi', name: 'Smt. Shelly Oberoi', contact: '+91 11 2322 0012' },
      { role: 'Chief Sanitary Inspector', name: 'Shri Vijay Kumar', contact: '+91 98110 54321' }
    ]
  }
};

export default function App() {
  // Roles and State
  const [currentRole, setCurrentRole] = useState<'citizen' | 'worker' | 'officer' | 'admin' | 'ngo' | 'csr'>('citizen');
  const [activeTab, setActiveTab] = useState<'home' | 'report' | 'map' | 'verify' | 'chatbot' | 'ngo-csr' | 'emergency'>('home');
  const [selectedCity, setSelectedCity] = useState<'bengaluru' | 'darbhanga' | 'patna' | 'mumbai' | 'delhi'>('bengaluru');
  const [resolutionPhotoUrl, setResolutionPhotoUrl] = useState('');
  
  // Real-Time Camera Operator State
  const [reportInputMode, setReportInputMode] = useState<'camera' | 'upload' | 'presets'>('camera');
  const [cameraActive, setCameraActive] = useState(false);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [dragActive, setDragActive] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  
  const [issues, setIssues] = useState<Issue[]>([]);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [hotspots, setHotspots] = useState<PredictiveHotspot[]>([]);
  const [ngoList, setNgoList] = useState<NGOProject[]>([]);
  const [csrList, setCsrList] = useState<CSRCampaign[]>([]);
  const [analytics, setAnalytics] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [mobileMoreOpen, setMobileMoreOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);
  const [userLiveLocation, setUserLiveLocation] = useState<{ lat: number; lng: number } | null>(null);

  // Play Store Dev Kit State
  const [playTab, setPlayTab] = useState<'listings' | 'assets' | 'bundle'>('listings');
  const [copiedText, setCopiedText] = useState<string | null>(null);

  // Theme State
  const [theme, setTheme] = useState<'light' | 'night' | 'space'>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('atlasone_theme');
      return (saved as 'light' | 'night' | 'space') || 'night';
    }
    return 'night';
  });

  const [isGovHubExpanded, setIsGovHubExpanded] = useState(false);

  const toggleTheme = (newTheme: 'light' | 'night' | 'space') => {
    setTheme(newTheme);
    localStorage.setItem('atlasone_theme', newTheme);
  };

  const handleCopyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(id);
    setTimeout(() => setCopiedText(null), 2000);
  };

  const downloadSvgAsPng = (svgId: string, filename: string, width: number, height: number) => {
    const svgElement = document.getElementById(svgId);
    if (!svgElement) {
      alert("Error: SVG Element not found");
      return;
    }
    try {
      const svgString = new XMLSerializer().serializeToString(svgElement);
      const svgBlob = new Blob([svgString], { type: 'image/svg+xml;charset=utf-8' });
      const blobURL = window.URL.createObjectURL(svgBlob);
      
      const image = new Image();
      image.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const context = canvas.getContext('2d');
        if (context) {
          context.fillStyle = '#0b1329';
          context.fillRect(0, 0, width, height);
          context.drawImage(image, 0, 0, width, height);
          
          const pngUrl = canvas.toDataURL('image/png');
          const downloadLink = document.createElement('a');
          downloadLink.href = pngUrl;
          downloadLink.download = filename;
          document.body.appendChild(downloadLink);
          downloadLink.click();
          document.body.removeChild(downloadLink);
        }
        window.URL.revokeObjectURL(blobURL);
      };
      image.onerror = (e) => {
        console.error("Failed to load image: ", e);
        alert("Could not render SVG to canvas. Please try downloading as SVG instead.");
      };
      image.src = blobURL;
    } catch (err) {
      console.error(err);
      alert("Error generating image.");
    }
  };

  // Authentication State
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [authEmail, setAuthEmail] = useState('');
  const [authDisplayName, setAuthDisplayName] = useState('');
  const [authRoleSelection, setAuthRoleSelection] = useState<'citizen' | 'worker' | 'officer' | 'admin' | 'ngo' | 'csr'>('citizen');
  const [authDepartment, setAuthDepartment] = useState('');
  const [authError, setAuthError] = useState('');
  const [authSuccess, setAuthSuccess] = useState('');

  // 1. Automated Grievance Drafting (Gemini AI) States
  const [grievanceDraftType, setGrievanceDraftType] = useState<'petition' | 'email' | 'work_order'>('petition');
  const [grievanceDraftText, setGrievanceDraftText] = useState<string>('');
  const [grievanceComplainantName, setGrievanceComplainantName] = useState<string>('');
  const [draftingGrievance, setDraftingGrievance] = useState<boolean>(false);

  // 2. CSR Escrow & Sponsoring States
  const [sponsorAmount, setSponsorAmount] = useState<number>(10000);
  const [sponsorCompanyName, setSponsorCompanyName] = useState<string>('');
  const [sponsoringIssue, setSponsoringIssue] = useState<boolean>(false);

  // 3. P2P Neighborhood Verification System States
  const [verificationTasks, setVerificationTasks] = useState<any[]>([]);
  const [loadingTasks, setLoadingTasks] = useState<boolean>(false);
  const [completedTaskIds, setCompletedTaskIds] = useState<string[]>([]);

  // 4. Edge-AI Offline-First Cache Syncing States
  const [offlineMode, setOfflineMode] = useState<boolean>(() => {
    return localStorage.getItem('atlasone_offline_mode') === 'true';
  });
  const [offlineQueue, setOfflineQueue] = useState<any[]>(() => {
    const cached = localStorage.getItem('atlasone_offline_queue');
    return cached ? JSON.parse(cached) : [];
  });
  const [syncingOfflineQueue, setSyncingOfflineQueue] = useState<boolean>(false);

  // Government Sync Status States
  const [govConnected, setGovConnected] = useState(true);
  const [govSyncing, setGovSyncing] = useState(false);
  const [govStatus, setGovStatus] = useState<any>({
    connected: true,
    gatewayName: 'National e-Gov Unified Civic Grid (CPGRAMS v4.0)',
    officialNode: 'BBMP-GRID-NODE-048',
    lastSyncTime: 'Never Synced',
    availableGovRecordsCount: 3,
  });
  const [govMessage, setGovMessage] = useState('');

  // Civic Karma Rewards States
  const [unlockedCoupons, setUnlockedCoupons] = useState<any[]>([]);

  // Capacitor Simulation States
  const [capacitorConsoleLogs, setCapacitorConsoleLogs] = useState<string[]>([
    "[System] Capacitor Runtime Engine initialized successfully.",
    "[Capacitor/Device] Registered main native-bridge event listeners.",
    "[Capacitor/StatusBar] Configured overlay mode with light content styles."
  ]);
  const [isSimulatingCamera, setIsSimulatingCamera] = useState(false);
  const [simulatedLocation, setSimulatedLocation] = useState<any>(null);
  const [filesystemSpace, setFilesystemSpace] = useState<string>("242.4 MB Used / 64.0 GB Total");

  // CPGRAMS Dispatch Simulation States
  const [dispatchingGrievanceId, setDispatchingGrievanceId] = useState<string | null>(null);
  const [dispatchStepsLog, setDispatchStepsLog] = useState<string[]>([]);
  const [selectedMinistry, setSelectedMinistry] = useState<string>("Ministry of Road Transport & Highways");

  // Search & Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  // AI Camera / Scanning Simulation State
  const [scanning, setScanning] = useState(false);
  const [scanResult, setScanResult] = useState<any>(null);
  const [selectedPresetImage, setSelectedPresetImage] = useState<string>('');
  const [customReportTitle, setCustomReportTitle] = useState('');
  const [customReportDesc, setCustomReportDesc] = useState('');
  const [customSeverity, setCustomSeverity] = useState<'low' | 'medium' | 'high' | 'critical'>('medium');

  // Voice report simulations
  const [isRecording, setIsRecording] = useState(false);
  const [recordedText, setRecordedText] = useState('');

  // Chatbot State
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    { id: '1', role: 'model', text: 'Hello! I am CivicHero AI. Tell me about any infrastructure issue or ask me how Atlasone AI works.', timestamp: new Date().toISOString() }
  ]);
  const [userInput, setUserInput] = useState('');
  const [botTyping, setBotTyping] = useState(false);

  // Selected Issue for Detail Modal
  const [selectedIssue, setSelectedIssue] = useState<Issue | null>(null);
  const [newComment, setNewComment] = useState('');

  // Active Worker / Officer actions
  const [assignedWorkerId, setAssignedWorkerId] = useState('worker_sam');
  const [completionNotes, setCompletionNotes] = useState('');

  // Preset Images for scanning simulation
  const scanPresets = [
    {
      name: 'Asphalt Pothole',
      category: 'pothole',
      url: 'https://images.unsplash.com/photo-1515162305285-0293e4767cc2?auto=format&fit=crop&w=600&q=80',
    },
    {
      name: 'Overflowing Sewage',
      category: 'overflow_drain',
      url: 'https://images.unsplash.com/photo-1584824486509-112e4181ff6b?auto=format&fit=crop&w=600&q=80',
    },
    {
      name: 'Litter Heap',
      category: 'garbage',
      url: 'https://images.unsplash.com/photo-1611284446314-60a58ac0deb9?auto=format&fit=crop&w=600&q=80',
    }
  ];

  // Preset voice statements
  const voicePresets = [
    "There is a huge pothole outside the Greenfield School on Sector 4 road, it is very dangerous for school buses.",
    "A broken streetlight pole with number EL-402 has been dark for three nights near the Indiranagar Metro pillar.",
    "Major clean water pipe leak flooding the sidewalk and wasting water at 12th cross defence colony."
  ];

  // Fetch Data on Role Change or Mount
  useEffect(() => {
    fetchInitialData();
  }, [currentRole]);

  useEffect(() => {
    if (activeTab === 'map' && navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setUserLiveLocation({ lat: latitude, lng: longitude });
        },
        (error) => {
          console.warn("Geolocation access error:", error);
        },
        { enableHighAccuracy: true, timeout: 5000, maximumAge: 0 }
      );
    }
  }, [activeTab]);

  const fetchInitialData = async () => {
    setLoading(true);
    try {
      // Use local logged-in profile if present, else fall back to role default
      const savedUserStr = localStorage.getItem('atlasone_logged_in_user');
      let uId = '';
      if (savedUserStr) {
        try {
          const savedUser = JSON.parse(savedUserStr);
          uId = savedUser.uid;
        } catch (e) {
          // parse failed
        }
      }

      if (!uId) {
        uId = currentRole === 'citizen' ? 'citizen_john' :
              currentRole === 'worker' ? 'worker_sam' :
              currentRole === 'officer' ? 'officer_meera' :
              currentRole === 'ngo' ? 'ngo_clean_green' :
              currentRole === 'csr' ? 'csr_tech_corp' : 'admin_hero';
      }

      const [resIssues, resProfile, resHotspots, resNGO, resCSR, resAnalytics] = await Promise.all([
        fetch('/api/issues').then(r => r.json()),
        fetch(`/api/users/${uId}`).then(r => r.json()),
        fetch('/api/predictive-hotspots').then(r => r.json()),
        fetch('/api/ngo-projects').then(r => r.json()),
        fetch('/api/csr-campaigns').then(r => r.json()),
        fetch('/api/analytics').then(r => r.json()),
      ]);

      setIssues(resIssues);
      setUserProfile(resProfile);
      if (resProfile && !savedUserStr) {
        // align default role
        setCurrentRole(resProfile.role);
      } else if (resProfile && savedUserStr) {
        setCurrentRole(resProfile.role);
      }
      setHotspots(resHotspots);
      setNgoList(resNGO);
      setCsrList(resCSR);
      setAnalytics(resAnalytics);

      // Fetch official government status too
      const resGov = await fetch('/api/gov/status').then(r => r.json());
      setGovStatus(resGov);
      setGovConnected(resGov.connected);
    } catch (err) {
      console.error('Error fetching dashboard state:', err);
    } finally {
      setLoading(false);
    }
  };

  // Auth Submit Handlers
  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthSuccess('');

    if (!authEmail.trim()) {
      setAuthError('Email address is required.');
      return;
    }

    try {
      if (authMode === 'login') {
        const res = await fetch('/api/users/auth/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: authEmail.trim() }),
        });
        const data = await res.json();
        if (res.ok) {
          setUserProfile(data);
          setCurrentRole(data.role);
          localStorage.setItem('atlasone_logged_in_user', JSON.stringify(data));
          setAuthSuccess(`Welcome back, ${data.displayName}!`);
          setTimeout(() => {
            setAuthModalOpen(false);
            setAuthSuccess('');
            setAuthEmail('');
          }, 1200);
        } else {
          setAuthError(data.error || 'Failed to sign in.');
        }
      } else {
        if (!authDisplayName.trim()) {
          setAuthError('Name is required for registering.');
          return;
        }
        const res = await fetch('/api/users/auth/register', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            email: authEmail.trim(),
            displayName: authDisplayName.trim(),
            role: authRoleSelection,
            department: authDepartment.trim() || undefined,
          }),
        });
        const data = await res.json();
        if (res.ok) {
          setUserProfile(data);
          setCurrentRole(data.role);
          localStorage.setItem('atlasone_logged_in_user', JSON.stringify(data));
          setAuthSuccess(`Account created! Welcoming ${data.displayName}.`);
          setTimeout(() => {
            setAuthModalOpen(false);
            setAuthSuccess('');
            setAuthEmail('');
            setAuthDisplayName('');
            setAuthDepartment('');
          }, 1200);
        } else {
          setAuthError(data.error || 'Failed to register.');
        }
      }
    } catch (err) {
      console.error('Authentication Error:', err);
      setAuthError('A network error occurred. Please try again.');
    }
  };

  const handleSignOut = () => {
    localStorage.removeItem('atlasone_logged_in_user');
    setUserProfile(null);
    setCurrentRole('citizen');
    setTimeout(() => {
      fetchInitialData();
    }, 100);
  };

  // Gov Portal triggers
  const handleToggleGovConnection = async () => {
    try {
      const res = await fetch('/api/gov/toggle-connection', { method: 'POST' });
      const data = await res.json();
      setGovConnected(data.connected);
      setGovStatus((prev: any) => ({ ...prev, connected: data.connected }));
      setGovMessage(`Government integration gateway is now ${data.connected ? 'Connected' : 'Disconnected'}.`);
      setTimeout(() => setGovMessage(''), 3000);
    } catch (err) {
      console.error('Error toggling gov:', err);
    }
  };

  const handleSyncGovRecords = async () => {
    if (!govConnected) return;
    setGovSyncing(true);
    setGovMessage('');
    try {
      const res = await fetch('/api/gov/sync', { method: 'POST' });
      const data = await res.json();
      if (res.ok) {
        setGovMessage(data.message);
        // Refresh cases list
        const resIssues = await fetch('/api/issues').then(r => r.json());
        setIssues(resIssues);
        // Refresh gov status
        const resGov = await fetch('/api/gov/status').then(r => r.json());
        setGovStatus(resGov);
      } else {
        setGovMessage(data.error || 'Sync failed.');
      }
    } catch (err) {
      console.error('Gov sync error:', err);
      setGovMessage('Network failed to sync with municipal grid.');
    } finally {
      setGovSyncing(false);
      setTimeout(() => setGovMessage(''), 4500);
    }
  };

  // Upvote Event
  const handleUpvote = async (issueId: string) => {
    if (!userProfile) return;
    try {
      const res = await fetch(`/api/issues/${issueId}/upvote`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: userProfile.uid }),
      });
      if (res.ok) {
        const updated = await res.json();
        setIssues(issues.map(i => i.id === issueId ? updated : i));
        if (selectedIssue && selectedIssue.id === issueId) {
          setSelectedIssue(updated);
        }
        // Locally add 10 XP
        setUserProfile(prev => prev ? { ...prev, xp: prev.xp + 10 } : null);
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Verification vote
  const handleVerifyVote = async (issueId: string, voteType: 'verified' | 'fixed' | 'fake' | 'evidence_needed', comment?: string) => {
    if (!userProfile) return;
    try {
      const res = await fetch(`/api/issues/${issueId}/vote`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: userProfile.uid,
          userName: userProfile.displayName,
          vote: voteType,
          comment: comment || 'Verified by community consensus.'
        }),
      });
      if (res.ok) {
        const updated = await res.json();
        setIssues(issues.map(i => i.id === issueId ? updated : i));
        if (selectedIssue && selectedIssue.id === issueId) {
          setSelectedIssue(updated);
        }
        // Add 40 XP and 20 Coins
        setUserProfile(prev => prev ? { ...prev, xp: prev.xp + 40, coins: prev.coins + 20 } : null);
        alert(`Thank you! Verification logged. You earned +40 XP and +20 Eco-Coins!`);
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Post Comment
  const handlePostComment = async () => {
    if (!selectedIssue || !newComment.trim() || !userProfile) return;
    try {
      const res = await fetch(`/api/issues/${selectedIssue.id}/comments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: userProfile.uid,
          userName: userProfile.displayName,
          userRole: userProfile.role,
          text: newComment,
        }),
      });
      if (res.ok) {
        const updated = await res.json();
        setIssues(issues.map(i => i.id === selectedIssue.id ? updated : i));
        setSelectedIssue(updated);
        setNewComment('');
        setUserProfile(prev => prev ? { ...prev, xp: prev.xp + 15 } : null);
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Stop camera stream whenever tab changes or on unmount
  useEffect(() => {
    if (activeTab !== 'report') {
      stopCamera();
    }
    return () => {
      stopCamera();
    };
  }, [activeTab]);

  const stopCamera = () => {
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setCameraActive(false);
  };

  const startCamera = async () => {
    setCameraError(null);
    setCapturedImage(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 640 }, height: { ideal: 480 } }
      });
      mediaStreamRef.current = stream;
      setCameraActive(true);
      // Wait a micro-task to ensure ref is bound before setting srcObject
      setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      }, 50);
    } catch (err: any) {
      console.error("Camera access failed:", err);
      setCameraError(err.message || "Could not access camera. Please check permissions.");
      setCameraActive(false);
    }
  };

  const capturePhoto = () => {
    if (videoRef.current) {
      const video = videoRef.current;
      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth || 640;
      canvas.height = video.videoHeight || 480;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
        setCapturedImage(dataUrl);
        stopCamera();
      }
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const processFile = (file: File) => {
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setCapturedImage(event.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    } else {
      alert('Please upload an image file (PNG, JPG, JPEG).');
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  // Submit Simulated AI Report
  const triggerAiScan = async (imgUrl: string) => {
    setScanning(true);
    setScanResult(null);
    setSelectedPresetImage(imgUrl);
    try {
      if (offlineMode) {
        // Run Simulated On-Device MobileNet V3 / WebNN diagnostic model
        await new Promise(resolve => setTimeout(resolve, 2200)); // Simulate edge-ML computation time
        
        let onDeviceResult: any = {
          title: "Pothole Defect Detected (On-Device ML)",
          category: "pothole",
          severity: "high",
          description: "This defect was identified completely offline using Atlasone-Lite MobileNet-V3 neural weights cached on-device. Detected a pavement fracture measuring approximately 8-10 inches in diameter.",
          confidence: 0.91,
          suggestedDepartment: "Road & Public Works Division",
          estimatedRepairCost: "₹6,800",
          estimatedRepairTime: "3 Hours",
          materialsRequired: "Hot Asphalt Mix, Bituminous Emulsion Tack Coat, Heavy Compactor Plate",
          recommendedPriority: "high",
          onDeviceModel: "Atlasone-Lite MobileNet-V3 (Float16 Quantized)"
        };
        
        if (imgUrl.includes('1584824486509') || imgUrl.includes('sewage')) {
          onDeviceResult = {
            title: "Clogged Storm/Sewer Drain (On-Device ML)",
            category: "overflow_drain",
            severity: "critical",
            description: "Identified blocked organic blockages and refuse buildup using offline tensor inference layers. High probability of flash flooding under monsoonal loads.",
            confidence: 0.89,
            suggestedDepartment: "Sanitation & Sewerage Board",
            estimatedRepairCost: "₹14,500",
            estimatedRepairTime: "5 Hours",
            materialsRequired: "Hydraulic Silt Dredger, Bio-enzymatic Desilt Agent, Safety Cage",
            recommendedPriority: "critical",
            onDeviceModel: "Atlasone-Lite MobileNet-V3 (Float16 Quantized)"
          };
        } else if (imgUrl.includes('1611284446314') || imgUrl.includes('garbage')) {
          onDeviceResult = {
            title: "Accumulated Litter Pile (On-Device ML)",
            category: "garbage",
            severity: "medium",
            description: "Identified solid waste accumulation with a visual volume estimate of ~1.2 cubic meters. On-device tensor layers class: Municipal Solid Waste.",
            confidence: 0.94,
            suggestedDepartment: "Solid Waste Management (SWM)",
            estimatedRepairCost: "₹3,000",
            estimatedRepairTime: "2 Hours",
            materialsRequired: "SWM Dump Truck, Organic Disinfectant Spray, High-density Waste Tarps",
            recommendedPriority: "medium",
            onDeviceModel: "Atlasone-Lite MobileNet-V3 (Float16 Quantized)"
          };
        }
        
        setScanResult(onDeviceResult);
        setCustomReportTitle(onDeviceResult.title);
        setCustomReportDesc(onDeviceResult.description);
        setCustomSeverity(onDeviceResult.severity);
        return;
      }

      // Simulate base64 scanner API payload
      const response = await fetch('/api/ai-analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: imgUrl, // sending URL as proof-of-work
          mimeType: 'image/jpeg'
        })
      });
      if (response.ok) {
        const parsed = await response.json();
        setScanResult(parsed);
        setCustomReportTitle(parsed.title);
        setCustomReportDesc(parsed.description);
        setCustomSeverity(parsed.severity);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setScanning(false);
    }
  };

  // Send Voice Simulation to Structured NLP parser
  const parseVoiceText = async (txt: string) => {
    setIsRecording(true);
    setRecordedText(txt);
    try {
      const res = await fetch('/api/voice-report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ speechText: txt })
      });
      if (res.ok) {
        const data = await res.json();
        setScanResult(data);
        setCustomReportTitle(data.title);
        setCustomReportDesc(data.description);
        setCustomSeverity(data.severity);
        setActiveTab('report');
        alert('Voice analyzed successfully! Auto-populating AI report page.');
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsRecording(false);
    }
  };

  // Submit Final Report to DB
  const submitReport = async () => {
    if (!userProfile) {
      setAuthMode('login');
      setAuthModalOpen(true);
      return;
    }
    
    // Coordinates mapping
    const mapCenters: Record<string, { lat: number; lng: number; address: string }> = {
      bengaluru: { lat: 12.9716, lng: 77.5946, address: 'Kanakapura Main Rd, Bengaluru, KA' },
      darbhanga: { lat: 26.1542, lng: 85.8918, address: 'Laheriasarai Tower Chowk, Darbhanga, BIH' },
      patna: { lat: 25.5941, lng: 85.1376, address: 'Boring Road Crossing, Patna, BIH' },
      mumbai: { lat: 18.9750, lng: 72.8258, address: 'Marine Drive Road, Mumbai, MH' },
      delhi: { lat: 28.6139, lng: 77.2090, address: 'Connaught Place Ring, New Delhi, DL' }
    };
    
    const center = mapCenters[selectedCity] || mapCenters.bengaluru;
    const offsetLat = center.lat + (Math.random() - 0.5) * 0.015;
    const offsetLng = center.lng + (Math.random() - 0.5) * 0.015;

    if (offlineMode) {
      const offlineReport = {
        id: `offline-${Date.now()}`,
        title: customReportTitle || 'Pothole on Main Road',
        description: customReportDesc || 'Detected via Atlasone AI vision scanner.',
        category: scanResult?.category || 'pothole',
        severity: customSeverity,
        imageUrl: selectedPresetImage || 'https://images.unsplash.com/photo-1515162305285-0293e4767cc2?auto=format&fit=crop&w=600&q=80',
        reportedBy: userProfile.uid,
        reportedByName: userProfile.displayName,
        isAnonymous: false,
        ocrAssetId: scanResult?.ocrAssetId || null,
        city: selectedCity,
        location: {
          lat: offsetLat,
          lng: offsetLng,
          address: `${customReportTitle || 'Reported Issue'} at ${center.address} (Offline Stored)`
        },
        confidence: scanResult?.confidence || 0.92,
        suggestedDepartment: scanResult?.suggestedDepartment || 'Department of Public Works',
        estimatedRepairCost: scanResult?.estimatedRepairCost || '₹8,500',
        estimatedRepairTime: scanResult?.estimatedRepairTime || '4 Hours',
        recommendedPriority: scanResult?.recommendedPriority || 'high'
      };

      const updatedQueue = [...offlineQueue, offlineReport];
      setOfflineQueue(updatedQueue);
      localStorage.setItem('atlasone_offline_queue', JSON.stringify(updatedQueue));

      setScanResult(null);
      setSelectedPresetImage('');
      setCapturedImage(null);
      setCustomReportTitle('');
      setCustomReportDesc('');
      setActiveTab('home');

      alert('⛈️ STORM OFFLINE CACHE ACTIVATED: Cellular network is unavailable. Your report and its GPS coordinates have been securely cached in browser local storage and will sync automatically when the connection is restored.');
      return;
    }

    try {
      const res = await fetch('/api/issues', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: customReportTitle || 'Pothole on Main Road',
          description: customReportDesc || 'Detected via Atlasone AI vision scanner.',
          category: scanResult?.category || 'pothole',
          severity: customSeverity,
          imageUrl: selectedPresetImage || 'https://images.unsplash.com/photo-1515162305285-0293e4767cc2?auto=format&fit=crop&w=600&q=80',
          reportedBy: userProfile.uid,
          reportedByName: userProfile.displayName,
          isAnonymous: false,
          ocrAssetId: scanResult?.ocrAssetId || null,
          city: selectedCity,
          location: {
            lat: offsetLat,
            lng: offsetLng,
            address: `${customReportTitle || 'Reported Issue'} at ${center.address}`
          }
        }),
      });
      if (res.ok) {
        const created = await res.json();
        setIssues([created, ...issues]);
        setScanResult(null);
        setSelectedPresetImage('');
        setCapturedImage(null);
        setCustomReportTitle('');
        setCustomReportDesc('');
        setActiveTab('home');
        // Refresh analytics
        fetchInitialData();
        alert('Civic issue filed successfully! You received +100 XP and +50 Eco-Coins for active civic participation!');
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Chatbot send
  const sendChat = async () => {
    if (!userInput.trim()) return;
    const newMsg: ChatMessage = {
      id: `m-${Date.now()}`,
      role: 'user',
      text: userInput,
      timestamp: new Date().toISOString(),
    };
    const updatedMessages = [...chatMessages, newMsg];
    setChatMessages(updatedMessages);
    setUserInput('');
    setBotTyping(true);

    try {
      const res = await fetch('/api/chatbot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: updatedMessages,
          userProfile,
        })
      });
      if (res.ok) {
        const data = await res.json();
        setChatMessages(prev => [...prev, {
          id: `b-${Date.now()}`,
          role: 'model',
          text: data.text,
          timestamp: new Date().toISOString()
        }]);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setBotTyping(false);
    }
  };

  // --- NEW FEATURES HELPER METHODS ---

  // 1. Automated Grievance Drafting (Gemini AI)
  const handleDraftGrievance = async (issueId: string) => {
    setDraftingGrievance(true);
    setGrievanceDraftText('');
    try {
      const res = await fetch(`/api/issues/${issueId}/draft-grievance`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: grievanceDraftType,
          complainantName: grievanceComplainantName || userProfile?.displayName || 'Concerned Ward Citizen'
        })
      });
      if (res.ok) {
        const data = await res.json();
        setGrievanceDraftText(data.text);
      } else {
        alert('Failed to contact Gemini drafting engine. Please try again.');
      }
    } catch (e) {
      console.error('Draft error:', e);
      alert('Network failure generating legal grievance paperwork.');
    } finally {
      setDraftingGrievance(false);
    }
  };

  // 2. CSR Escrow & Sponsoring
  const handleSponsorIssue = async (issueId: string) => {
    if (!sponsorCompanyName.trim()) {
      alert('Please enter your Corporate Sponsor Name / Entity to authorize funding.');
      return;
    }
    setSponsoringIssue(true);
    try {
      const res = await fetch(`/api/issues/${issueId}/sponsor`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          companyName: sponsorCompanyName,
          sponsorAmount: sponsorAmount,
          userId: userProfile?.uid || 'csr_tech_corp'
        })
      });
      if (res.ok) {
        const updated = await res.json();
        setIssues(issues.map(i => i.id === issueId ? updated : i));
        setSelectedIssue(updated);
        setSponsorCompanyName('');
        // Award XP update
        if (userProfile) {
          setUserProfile((prev: any) => ({
            ...prev,
            xp: prev.xp + 250,
            coins: prev.coins + 150,
            level: Math.floor((prev.xp + 250) / 500) + 1
          }));
        }
        alert(`🏆 CSR Escrow Secured! Stored ₹${sponsorAmount.toLocaleString()} in secure contract escrow. The local contractor queue has been synchronized.`);
      } else {
        alert('Sponsorship authorization failed. Try again.');
      }
    } catch (e) {
      console.error(e);
      alert('Escrow network error.');
    } finally {
      setSponsoringIssue(false);
    }
  };

  // 3. P2P Verification Tasks provider (auto-loaded via city useEffect)
  const fetchVerificationTasks = async (city: string) => {
    setLoadingTasks(true);
    try {
      const res = await fetch(`/api/verification-tasks?city=${city}`);
      const data = await res.json();
      setVerificationTasks(data);
    } catch (e) {
      console.error('Failed to load verification queue:', e);
    } finally {
      setLoadingTasks(false);
    }
  };

  useEffect(() => {
    fetchVerificationTasks(selectedCity);
  }, [selectedCity, issues]);

  const handleP2PAction = async (task: any, vote: 'verified' | 'fixed' | 'fake') => {
    setLoadingTasks(true);
    try {
      let url = `/api/issues/${task.issueId}/vote`;
      let payload: any = {
        userId: userProfile?.uid || 'citizen_john',
        userName: userProfile?.displayName || 'John Doe',
        vote: vote === 'verified' ? 'verified' : (vote === 'fake' ? 'fake' : 'verified'),
        comment: vote === 'verified'
          ? '🛡️ Neighborhood Audit: Verified that this reported issue is indeed active and requires municipal remediation.'
          : '🛡️ Neighborhood Audit: Flagged this report as a duplicate/spam/fake.'
      };

      if (vote === 'fixed') {
        url = `/api/issues/${task.issueId}/verify-resolution`;
        payload = {
          userId: userProfile?.uid || 'citizen_john',
          userName: userProfile?.displayName || 'John Doe',
          vote: 'verify_done',
          comment: '🛡️ Neighborhood Audit: Verified the field technician repair! Standard achieved.'
        };
      }

      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        const updatedIssue = await res.json();
        setIssues(issues.map(i => i.id === task.issueId ? updatedIssue : i));
        setCompletedTaskIds(prev => [...prev, task.id]);

        // Award reward XP and Coins
        if (userProfile) {
          const updatedUser = {
            ...userProfile,
            xp: userProfile.xp + task.rewardXp,
            coins: userProfile.coins + task.rewardCoins,
            level: Math.floor((userProfile.xp + task.rewardXp) / 500) + 1
          };
          setUserProfile(updatedUser);
          localStorage.setItem('atlasone_logged_in_user', JSON.stringify(updatedUser));
        }

        alert(`🎯 P2P Audit Successful! You verified the neighborhood grid and earned +${task.rewardXp} XP and +${task.rewardCoins} Eco-Coins!`);
      } else {
        const err = await res.json();
        alert(err.error || 'Failed to file P2P audit.');
      }
    } catch (e) {
      console.error(e);
      alert('P2P connection error.');
    } finally {
      setLoadingTasks(false);
    }
  };

  // 4. Offline Emergency Sync
  const toggleOfflineMode = () => {
    const nextMode = !offlineMode;
    setOfflineMode(nextMode);
    localStorage.setItem('atlasone_offline_mode', String(nextMode));
    if (nextMode) {
      alert('⛈️ STORM EMERGENCY RECOVERY: Offline mode is activated. Cell connection is simulated as severed. Reports will be cached locally in browser local storage and synced later.');
    } else {
      alert('📡 NETWORK RESTORED: Online cellular grid is back online.');
    }
  };

  const syncOfflineQueue = async () => {
    if (offlineQueue.length === 0) return;
    setSyncingOfflineQueue(true);
    let successCount = 0;

    // Beautiful UI feedback delays
    await new Promise(r => setTimeout(r, 1200));

    try {
      for (const report of offlineQueue) {
        const res = await fetch('/api/issues', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(report)
        });
        if (res.ok) {
          successCount++;
        }
      }

      setOfflineQueue([]);
      localStorage.removeItem('atlasone_offline_queue');
      await fetchInitialData();

      // Award extreme storm sync bonus!
      if (userProfile) {
        const updatedUser = {
          ...userProfile,
          xp: userProfile.xp + 150,
          coins: userProfile.coins + 75,
          level: Math.floor((userProfile.xp + 150) / 500) + 1
        };
        setUserProfile(updatedUser);
        localStorage.setItem('atlasone_logged_in_user', JSON.stringify(updatedUser));
      }

      alert(`⛈️ Storm Sync Complete: Successfully uploaded ${successCount} emergency reports! Stored offline data has been synced to State servers. Received +150 XP & +75 Emergency Resilience Coins!`);
    } catch (err) {
      console.error(err);
      alert('Sync failed. Please ensure your cellular or wifi network is stable.');
    } finally {
      setSyncingOfflineQueue(false);
    }
  };

  // Assign issue to Field worker
  const assignIssue = async (issueId: string, workerId: string) => {
    const workerName = userProfiles[workerId]?.displayName || 'Sam Bahadur';
    try {
      const res = await fetch(`/api/issues/${issueId}/assign`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ workerId, workerName })
      });
      if (res.ok) {
        const updated = await res.json();
        setIssues(issues.map(i => i.id === issueId ? updated : i));
        setSelectedIssue(updated);
        alert(`Successfully assigned work orders to ${workerName}!`);
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Submit Worker resolution
  const submitResolution = async (issueId: string, status: 'in_progress' | 'completed') => {
    try {
      const res = await fetch(`/api/issues/${issueId}/progress`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          status,
          completionNotes: status === 'completed' ? completionNotes : 'Work is actively in progress under heavy site supervision.',
          afterPhoto: status === 'completed' ? (resolutionPhotoUrl || 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=600&q=80') : undefined
        })
      });
      if (res.ok) {
        const updated = await res.json();
        setIssues(issues.map(i => i.id === issueId ? updated : i));
        setSelectedIssue(updated);
        setCompletionNotes('');
        setResolutionPhotoUrl('');
        alert(status === 'completed' ? 'Fantastic! Issue resolved and uploaded live for public citizen verification.' : 'Work logged as In Progress.');
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Dispatch Notification to local MC Head
  const handleNotifyHead = async (issueId: string) => {
    const mc = MUNICIPAL_DATA[selectedCity] || MUNICIPAL_DATA.bengaluru;
    try {
      const res = await fetch(`/api/issues/${issueId}/notify-head`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          headName: mc.headName,
          headRole: mc.headTitle,
          mcName: mc.name
        })
      });
      if (res.ok) {
        const updated = await res.json();
        setIssues(issues.map(i => i.id === issueId ? updated : i));
        setSelectedIssue(updated);
        // Dispatch sound or visual alert
        alert(`🚨 Notification formally filed with ${mc.headTitle} ${mc.headName}. The ${mc.name} has accepted and logged the grievance into their dispatcher portal.`);
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Submit Citizen Resolution Verification or Dispute
  const handleVerifyResolution = async (issueId: string, vote: 'verify_done' | 'dispute_fake', userComment?: string) => {
    if (!userProfile) {
      setAuthModalOpen(true);
      return;
    }
    try {
      const res = await fetch(`/api/issues/${issueId}/verify-resolution`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: userProfile.uid,
          userName: userProfile.displayName,
          vote,
          comment: userComment
        })
      });
      if (res.ok) {
        const updated = await res.json();
        setIssues(issues.map(i => i.id === issueId ? updated : i));
        setSelectedIssue(updated);
        alert(vote === 'verify_done'
          ? 'Verification successful! Thank you for active community policing. You earned +40 XP & +20 Eco-Coins!'
          : 'Dispute recorded. We have flagged this resolution and forwarded the feedback back to the field supervisor.'
        );
      } else {
        const data = await res.json();
        alert(data.error || 'You have already verified/disputed this issue.');
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Volunteer NGO
  const handleVolunteer = async (ngoId: string) => {
    if (!userProfile) return;
    try {
      const res = await fetch(`/api/ngo-projects/${ngoId}/volunteer`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: userProfile.uid }),
      });
      if (res.ok) {
        const updated = await res.json();
        setNgoList(ngoList.map(n => n.id === ngoId ? updated : n));
        setUserProfile(prev => prev ? { ...prev, xp: prev.xp + 150, coins: prev.coins + 50 } : null);
        alert(`Thank you for registering to volunteer! You received +150 XP and +50 Eco-Coins for physical stewardship!`);
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Redeem Civic Karma Reward
  const handleRedeemCoupon = (rewardId: string, cost: number, title: string) => {
    if (!userProfile) {
      alert("Please login to access the Civic Karma rewards store!");
      return;
    }
    if (userProfile.coins < cost) {
      alert(`Insufficient Eco-Coins balance! You need ${cost} Eco-Coins to redeem this voucher, but you currently have only ${userProfile.coins} Eco-Coins.`);
      return;
    }

    // Deduct coins and update state
    setUserProfile(prev => prev ? { ...prev, coins: prev.coins - cost } : null);

    const couponCode = `${rewardId.toUpperCase()}-${Math.floor(1000 + Math.random() * 9000)}-${Math.floor(1000 + Math.random() * 9000)}`;
    const newCoupon = {
      rewardId,
      title,
      code: couponCode,
      cost,
      redeemedAt: new Date().toISOString()
    };

    setUnlockedCoupons(prev => [newCoupon, ...prev]);
    alert(`Success! You spent ${cost} Eco-Coins and unlocked: ${title}. Coupon code: ${couponCode}`);
  };

  // Dispatch reported issue to CPGRAMS Central Hub
  const handleExecuteCpgramsDispatch = async (issueId: string) => {
    if (!userProfile) {
      alert("Please authenticate to authorize official e-Gov CPGRAMS dispatch.");
      return;
    }
    setDispatchingGrievanceId(issueId);
    setDispatchStepsLog([]);

    const steps = [
      "📡 Establishing handshake with CPGRAMS gateway node (GRID-NODE-048)...",
      "📝 Compiling defect coordinates and citizen-audit verification receipts...",
      "🔐 Generating SHA-256 digital signature of credentials and image hashes...",
      "🗳️ Encrypting complainant identity protocols...",
      "📤 Routing GrievanceSchemaV4 payload to Ministry central server...",
      "💾 Awaiting registration response from official PG Portal API..."
    ];

    // Simulating sequence log with setTimeouts
    for (let i = 0; i < steps.length; i++) {
      setDispatchStepsLog(prev => [...prev, steps[i]]);
      await new Promise(resolve => setTimeout(resolve, 350 + Math.random() * 200));
    }

    try {
      const res = await fetch('/api/gov/dispatch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          issueId,
          ministry: selectedMinistry,
          complainantName: userProfile.displayName,
          email: userProfile.email || 'citizen@atlasone.ai',
          notes: "Automated dispatch request verified by local neighborhood peer audit."
        })
      });

      if (res.ok) {
        const data = await res.json();
        setDispatchStepsLog(prev => [...prev, `✅ SUCCESS! Received registration response. Official Ticket: ${data.dispatchReceipt.ticketNumber}`]);
        
        // Update active issues list
        setIssues(prevIssues => prevIssues.map(i => i.id === issueId ? {
          ...i,
          isGovSynced: true,
          cpgramsDispatch: data.dispatchReceipt
        } : i));

        // Update selectedIssue if currently open
        if (selectedIssue && selectedIssue.id === issueId) {
          setSelectedIssue(prev => prev ? {
            ...prev,
            isGovSynced: true,
            cpgramsDispatch: data.dispatchReceipt
          } : null);
        }

        alert(`Official grievance successfully registered! Ticket Number is: ${data.dispatchReceipt.ticketNumber}`);
      } else {
        const err = await res.json();
        setDispatchStepsLog(prev => [...prev, `❌ ERROR: ${err.error || 'Server rejected gateway dispatch transaction.'}`]);
      }
    } catch (err) {
      console.error(err);
      setDispatchStepsLog(prev => [...prev, `❌ CRITICAL: Network failure during node routing.`]);
    } finally {
      setTimeout(() => {
        setDispatchingGrievanceId(null);
      }, 1500);
    }
  };

  // Filter and Search logic
  const filteredIssues = issues.filter(i => {
    const matchesSearch = i.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          i.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          i.location.address.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = filterCategory === 'all' || i.category === filterCategory;
    const matchesStatus = filterStatus === 'all' || i.status === filterStatus;
    const matchesCity = (i.city || 'bengaluru') === selectedCity;
    return matchesSearch && matchesCategory && matchesStatus && matchesCity;
  });

  if (typeof window !== 'undefined' && window.location.pathname === '/privacy') {
    return (
      <div className={`min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-teal-500 selection:text-slate-900 p-6 md:p-12 items-center justify-center theme-transition ${theme === 'night' ? 'theme-night' : theme === 'space' ? 'theme-space' : 'theme-light'}`}>
        <div className="max-w-3xl w-full bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-10 shadow-2xl space-y-6 relative overflow-hidden">
          {/* Glowing background */}
          <div className="absolute top-0 right-0 w-72 h-72 bg-teal-500/5 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-72 h-72 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none" />

          <div className="flex items-center gap-3 pb-6 border-b border-slate-800">
            <div className="p-2.5 rounded-2xl bg-teal-500/10 border border-teal-500/20 text-teal-400">
              <Smartphone className="w-8 h-8 animate-pulse" />
            </div>
            <div>
              <h1 className="text-2xl font-black text-slate-100 tracking-tight">Atlasone AI</h1>
              <p className="text-[10px] text-teal-400 font-extrabold tracking-widest uppercase">Official Privacy Policy</p>
            </div>
          </div>

          <div className="space-y-4 text-xs text-slate-300 leading-relaxed max-h-[350px] overflow-y-auto pr-2 scrollbar-thin">
            <p className="text-slate-400">
              <strong>Effective Date:</strong> June 30, 2026
            </p>
            
            <h2 className="text-sm font-bold text-slate-100 uppercase tracking-wider">1. Introduction</h2>
            <p>
              Welcome to Atlasone AI, the hyperlocal community problem-solving platform. We respect your privacy and are committed to protecting any personal data processed through our application. This Privacy Policy outlines what information we collect, how we use it, and how we keep it safe.
            </p>

            <h2 className="text-sm font-bold text-slate-100 uppercase tracking-wider">2. Data We Collect</h2>
            <ul className="list-disc pl-5 space-y-1">
              <li><strong>Precise GPS Location Data:</strong> Used strictly to map reported ward issues (potholes, water leaks, streetlights) and verify nearby citizen reports.</li>
              <li><strong>Camera & Photo Uploads:</strong> Accessed only when you snap photos of civic issues to be analyzed by our Gemini AI vision system.</li>
              <li><strong>Profile Credentials:</strong> Name, role, and avatar details used to track civic rewards, XP, levels, and certificates.</li>
            </ul>

            <h2 className="text-sm font-bold text-slate-100 uppercase tracking-wider">3. AI Processing & Third-Parties</h2>
            <p>
              Atlasone AI uses the secure server-side <strong>Google Gemini API</strong> to identify civic issues in uploaded photos. No personal identifiers or facial data are shared with third parties.
            </p>

            <h2 className="text-sm font-bold text-slate-100 uppercase tracking-wider">4. Data Security</h2>
            <p>
              Your data is secured through high-grade encryption and saved on secure Firestore/Cloud databases, with advanced client-side caching implemented for offline storm resilience.
            </p>

            <h2 className="text-sm font-bold text-slate-100 uppercase tracking-wider">5. Contact & Deletions</h2>
            <p>
              For any questions regarding your data, or to request a full account deletion, please contact us at: <strong className="text-teal-400">satyam15e@gmail.com</strong>.
            </p>
          </div>

          <div className="pt-4 border-t border-slate-800 flex justify-between items-center text-[11px] text-slate-500">
            <span>© 2026 Atlasone AI. All Rights Reserved.</span>
            <a href="/" className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg transition font-bold uppercase tracking-wider">
              Return to App
            </a>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen bg-slate-900 text-slate-100 flex flex-col font-sans selection:bg-teal-500 selection:text-slate-900 pb-24 lg:pb-0 theme-transition ${theme === 'night' ? 'theme-night' : theme === 'space' ? 'theme-space' : 'theme-light'}`}>
      
      {/* 1. Global Header & Role Simulator */}
      <header id="app-header" className="sticky top-0 z-40 backdrop-blur-md bg-slate-900/80 border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-2 md:px-4 py-1 md:py-3 flex justify-between items-center gap-2 md:gap-3">
          <div className="flex items-center gap-1.5 md:gap-3 select-none">
            {/* High-Fidelity AtlasOne AI SVG Logo Icon */}
            <svg viewBox="0 0 200 200" className="w-6.5 h-6.5 md:w-12 md:h-12 flex-shrink-0" id="atlasone-logo-icon">
              <defs>
                <linearGradient id="blueLeg" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#2563eb" />
                  <stop offset="100%" stopColor="#1e3a8a" />
                </linearGradient>
                <linearGradient id="blueRight" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#3b82f6" />
                  <stop offset="100%" stopColor="#1d4ed8" />
                </linearGradient>
                <linearGradient id="tealGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#2dd4bf" />
                  <stop offset="100%" stopColor="#0d9488" />
                </linearGradient>
                <linearGradient id="orbitGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#2563eb" />
                  <stop offset="50%" stopColor="#0d9488" />
                  <stop offset="100%" stopColor="#2dd4bf" />
                </linearGradient>
              </defs>

              {/* Globe Grid in Background */}
              <g stroke="#94a3b8" strokeWidth="0.75" fill="none" opacity="0.25">
                <circle cx="100" cy="85" r="65" strokeDasharray="3,3" />
                <path d="M 100 20 A 65 65 0 0 0 100 150" strokeDasharray="2,2" />
                <path d="M 100 20 A 35 65 0 0 0 100 150" strokeDasharray="2,2" />
                <path d="M 100 20 A 35 65 0 0 1 100 150" strokeDasharray="2,2" />
                <path d="M 45 50 A 65 25 0 0 0 155 50" strokeDasharray="2,2" />
                <path d="M 35 85 A 65 15 0 0 0 165 85" strokeDasharray="2,2" />
                <path d="M 45 120 A 65 25 0 0 0 155 120" strokeDasharray="2,2" />
              </g>

              {/* Stylized A - Left Leg */}
              <path d="M 58 150 L 98 40 L 115 40 L 76 150 Z" fill="url(#blueLeg)" />

              {/* Stylized A - Right Leg */}
              <path d="M 105 40 L 145 150 L 126 150 L 95 65 Z" fill="url(#blueRight)" />

              {/* Stylized '1' standing inside/overlapping */}
              <path d="M 88 95 C 93 88 100 81 107 80 L 107 140 L 95 140 L 95 152 L 122 152 L 122 140 L 115 140 L 115 80 C 111 81 103 84 95 90 Z" fill="url(#tealGrad)" />

              {/* Sweeping Orbit Swoosh */}
              <path d="M 45 105 C 30 115 60 135 110 135 C 150 135 170 115 170 100 C 170 85 150 75 135 75" fill="none" stroke="url(#orbitGrad)" strokeWidth="6" strokeLinecap="round" />

              {/* Location Pin on the Orbit */}
              <g transform="translate(165, 88)">
                <path d="M 0 0 C -6 -6 -10 -12 -10 -18 C -10 -24 -5 -29 0 -29 C 5 -29 10 -24 10 -18 C 10 -12 6 -6 0 0 Z" fill="#2dd4bf" />
                <circle cx="0" cy="-18" r="4" fill="#0f172a" />
              </g>
            </svg>

            {/* Styled Brand Name & Tagline */}
            <div className="flex flex-col">
              <div className="flex items-baseline gap-0.5 md:gap-1">
                <span className="text-sm md:text-xl font-black tracking-tight text-slate-100">Atlas</span>
                <span className="text-sm md:text-xl font-black tracking-tight text-teal-600">One</span>
                <span className="text-sm md:text-xl font-bold tracking-tight text-blue-600 ml-0.5">AI</span>
              </div>
              <div className="hidden md:flex items-center gap-1">
                <span className="h-[1px] w-3 bg-blue-500/30"></span>
                <span className="text-[8px] font-bold tracking-wider text-slate-400 uppercase">
                  The Intelligence Behind Better Communities
                </span>
                <span className="h-[1px] w-3 bg-teal-500/30"></span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 md:gap-3">
            {/* Theme Toggle Button & Segmented Control */}
            <div className="flex items-center bg-slate-950/40 p-1 md:p-1.5 rounded-2xl border border-slate-800 gap-1 backdrop-blur-sm shadow-inner select-none">
              <button
                onClick={() => toggleTheme('light')}
                className={`p-1 md:p-1.5 rounded-xl transition-all duration-200 cursor-pointer ${
                  theme === 'light'
                    ? 'bg-amber-500 text-slate-950 font-extrabold shadow scale-105'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/30'
                }`}
                title="Sleek Light Mode"
              >
                <Sun className="w-3.5 h-3.5" />
              </button>
              
              <button
                onClick={() => toggleTheme('night')}
                className={`p-1 md:p-1.5 rounded-xl transition-all duration-200 cursor-pointer ${
                  theme === 'night'
                    ? 'bg-blue-600 text-white font-extrabold shadow scale-105'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/30'
                }`}
                title="Classic Night Mode"
              >
                <Moon className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={() => toggleTheme('space')}
                className={`p-1 md:p-1.5 rounded-xl transition-all duration-200 cursor-pointer ${
                  theme === 'space'
                    ? 'bg-indigo-600 text-teal-300 font-extrabold shadow scale-105'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/30'
                }`}
                title="Sexy Deep Space Mode"
              >
                <Palette className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* User Profile Circular Avatar Section */}
            <div className="relative">
              <button
                onClick={() => {
                  if (userProfile) {
                    setProfileDropdownOpen(!profileDropdownOpen);
                  } else {
                    setAuthMode('login');
                    setAuthModalOpen(true);
                  }
                }}
                className="w-8 h-8 md:w-10 md:h-10 rounded-full bg-slate-950/50 hover:bg-slate-950 border border-slate-800 hover:border-teal-500/50 flex items-center justify-center text-slate-200 transition-all shadow-md cursor-pointer relative overflow-hidden"
                title={userProfile ? `${userProfile.displayName}'s Profile` : "Log In or Create Account"}
              >
                {userProfile ? (
                  <div className="w-full h-full bg-gradient-to-br from-teal-500 to-emerald-600 flex items-center justify-center font-black text-slate-950 text-sm">
                    {userProfile.displayName.split(' ').map((n: string) => n[0]).join('').substring(0, 2).toUpperCase()}
                  </div>
                ) : (
                  <User className="w-5 h-5 text-slate-400" />
                )}
              </button>

              {/* Profile Dropdown Popover */}
              {profileDropdownOpen && userProfile && (
                <>
                  <div 
                    className="fixed inset-0 z-40" 
                    onClick={() => setProfileDropdownOpen(false)} 
                  />
                  <div className="absolute right-0 mt-2.5 w-64 bg-slate-950 border border-slate-800 rounded-2xl p-4 shadow-2xl space-y-4 z-50 animate-in fade-in slide-in-from-top-3 duration-200">
                    <div className="flex items-center gap-3 border-b border-slate-900 pb-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-teal-500 to-emerald-600 flex items-center justify-center text-sm font-black text-slate-950">
                        {userProfile.displayName.split(' ').map((n: string) => n[0]).join('').substring(0, 2).toUpperCase()}
                      </div>
                      <div className="overflow-hidden">
                        <p className="text-xs font-black text-slate-100 truncate">{userProfile.displayName}</p>
                        <p className="text-[10px] text-teal-400 font-extrabold uppercase tracking-wider">{userProfile.role}</p>
                      </div>
                    </div>

                    <div className="space-y-2 text-[11px] text-slate-400">
                      <div className="flex justify-between">
                        <span>XP Progress</span>
                        <span className="font-bold text-slate-200">{userProfile.xp} XP</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Eco-Coins balance</span>
                        <span className="font-bold text-amber-500">{userProfile.coins} Coins</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Participation Level</span>
                        <span className="font-bold text-indigo-400">Level {userProfile.level}</span>
                      </div>
                      {userProfile.department && (
                        <div className="flex justify-between">
                          <span>Division</span>
                          <span className="font-bold text-slate-300 truncate max-w-[120px]">{userProfile.department}</span>
                        </div>
                      )}
                    </div>

                    <div className="pt-2 border-t border-slate-900 flex flex-col gap-2">
                      <button
                        onClick={() => {
                          setAuthMode('register');
                          setAuthModalOpen(true);
                          setProfileDropdownOpen(false);
                        }}
                        className="w-full py-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-200 text-xs font-bold rounded-xl transition"
                      >
                        Create Another Profile
                      </button>
                      <button
                        onClick={() => {
                          handleSignOut();
                          setProfileDropdownOpen(false);
                        }}
                        className="w-full py-2 bg-rose-950/20 hover:bg-rose-950/40 border border-rose-900/30 text-rose-400 text-xs font-bold rounded-xl transition"
                      >
                        Sign Out
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>

            {/* Stunning 3-Line Hamburger Menu Button */}
            <button
              onClick={() => setMenuOpen(true)}
              id="hamburger-menu-btn"
              className="flex items-center gap-1 md:gap-2 px-2 py-1.5 md:px-3.5 md:py-2 rounded-lg md:rounded-xl bg-slate-950/40 hover:bg-slate-950/70 border border-slate-800 hover:border-slate-700/80 text-slate-100 hover:text-white transition-all shadow-sm active:scale-95 cursor-pointer"
              aria-label="Open navigation menu"
            >
              <Menu className="w-4 h-4 md:w-5 md:h-5 text-teal-600 animate-pulse" />
              <span className="hidden sm:inline text-xs font-bold tracking-wider uppercase text-slate-400 hover:text-slate-200">Menu</span>
            </button>
          </div>
        </div>
      </header>

      {/* Out of Network / Last Located Emergency Contacts Banner */}
      {offlineMode && (
        <div className="bg-rose-950/90 border-b border-rose-900/60 text-rose-200 py-3 px-4 text-xs font-medium animate-in slide-in-from-top duration-300 relative z-30">
          <div className="max-w-7xl mx-auto flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-rose-500"></span>
              </span>
              <div>
                <span className="font-extrabold uppercase tracking-widest text-[9px] text-rose-400 bg-rose-900/40 px-1.5 py-0.5 rounded border border-rose-800/50 mr-2">OUT OF NETWORK</span>
                <span className="text-slate-100">
                  Using local cached data. Here are the offline emergency services for your last located area:{' '}
                  <strong className="text-rose-400 capitalize underline decoration-rose-500/30 underline-offset-2">{selectedCity}</strong>
                </span>
              </div>
            </div>
            <button
              onClick={() => setActiveTab('emergency')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-extrabold text-[10px] uppercase tracking-wider transition-all self-start sm:self-center shadow-lg shadow-rose-950/50 cursor-pointer hover:scale-[1.02] active:scale-95"
            >
              <Phone className="w-3 h-3" />
              <span>Get Emergency Contacts</span>
            </button>
          </div>
        </div>
      )}

      {/* 2. Secondary User Info bar & Gamification Tracker */}
      <section id="user-info-section" className="bg-slate-950/60 border-b border-slate-800 py-1 md:py-2 px-2 md:px-4">
        <div className="max-w-7xl mx-auto flex flex-nowrap overflow-x-auto md:flex-wrap md:overflow-visible justify-between items-center gap-3 text-xs w-full scrollbar-none">
          {userProfile ? (
            <div className="flex items-center gap-2 md:gap-4 flex-shrink-0">
              <div className="flex items-center gap-1.5 md:gap-2 bg-slate-900 px-2.5 md:px-3 py-1 md:py-1.5 rounded-full border border-slate-800 flex-shrink-0">
                <div className="w-4 h-4 md:w-5 md:h-5 rounded-full bg-indigo-500 flex items-center justify-center text-[9px] md:text-[10px] font-bold text-white">
                  {userProfile.level}
                </div>
                <span className="text-slate-300 font-semibold text-[11px] md:text-xs">{userProfile.displayName}</span>
                <span className="text-[9px] bg-slate-800 text-teal-400 px-1.5 md:px-2 py-0.5 rounded-full uppercase tracking-wider font-bold">
                  {userProfile.role}
                </span>
                {userProfile.department && (
                  <span className="text-[8px] md:text-[9px] text-indigo-400 font-medium px-1.5 py-0.5 bg-indigo-950/40 rounded border border-indigo-900/30 hidden xs:inline-block">
                    {userProfile.department}
                  </span>
                )}
              </div>

              {/* Coins, XP & Streak */}
              <div className="flex items-center gap-1.5 md:gap-2.5 flex-shrink-0 text-[10px] md:text-xs">
                <div className="flex items-center gap-1 text-amber-500 bg-amber-950/40 px-2 md:px-2.5 py-0.5 md:py-1 rounded-full border border-amber-900/40">
                  <Coins className="w-3 h-3 md:w-3.5 md:h-3.5 text-amber-500" />
                  <span className="font-bold">{userProfile.coins} Coins</span>
                </div>
                <div className="flex items-center gap-1 text-teal-500 bg-teal-950/40 px-2 md:px-2.5 py-0.5 md:py-1 rounded-full border border-teal-900/40">
                  <Award className="w-3 h-3 md:w-3.5 md:h-3.5 text-teal-500" />
                  <span className="font-bold">{userProfile.xp} XP</span>
                </div>
                <div className="flex items-center gap-1 text-rose-500 bg-rose-950/40 px-2 md:px-2.5 py-0.5 md:py-1 rounded-full border border-rose-900/40">
                  <Flame className="w-3 h-3 md:w-3.5 md:h-3.5 text-rose-500 animate-pulse" />
                  <span className="font-bold">{userProfile.streak}d Streak</span>
                </div>
              </div>

              {/* Sign Out Button */}
              <button
                onClick={handleSignOut}
                id="sign-out-btn" style={{ display: 'none' }}
                className="text-[10px] text-slate-400 hover:text-rose-400 transition font-bold uppercase tracking-wider underline cursor-pointer"
              >
                Sign Out
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2 md:gap-3 flex-shrink-0">
              <span className="text-slate-400 text-[10px] md:text-xs">Viewing with simulation credentials.</span>
              <button
                onClick={() => { setAuthMode('login'); setAuthModalOpen(true); }}
                id="trigger-login-btn"
                className="bg-teal-500/10 text-teal-400 hover:bg-teal-500/20 border border-teal-500/30 px-2 py-0.5 md:px-3 md:py-1 rounded-lg text-[9px] md:text-[10px] font-extrabold uppercase tracking-wider transition-all"
              >
                Log In / Register Profile
              </button>
            </div>
          )}

          {/* GovConnect Gateway Status Indicator */}
          <div className="flex items-center gap-3 md:gap-4 flex-shrink-0">
            <div className="flex items-center gap-1.5 md:gap-2 bg-slate-900/80 px-2 md:px-3 py-1 md:py-1.5 rounded-full border border-slate-800">
              <span className={`w-1 h-1 md:w-1.5 md:h-1.5 rounded-full ${govConnected ? 'bg-emerald-500 animate-pulse' : 'bg-slate-600'}`} />
              <span className="text-[9px] md:text-[10px] text-slate-400 font-bold uppercase tracking-wider flex items-center gap-1">
                <Globe className="w-2.5 h-2.5 md:w-3 md:h-3 text-slate-400" /> GovConnect:
              </span>
              <span className={`text-[9px] md:text-[10px] font-extrabold ${govConnected ? 'text-emerald-400' : 'text-slate-500'}`}>
                {govConnected ? 'ACTIVE' : 'OFFLINE'}
              </span>
              
              <button
                onClick={handleToggleGovConnection}
                id="toggle-gov-btn"
                className="ml-1 text-[8px] bg-slate-800 hover:bg-slate-750 text-slate-300 px-1.5 py-0.5 rounded transition font-bold uppercase cursor-pointer"
                title="Toggle government portal link status"
              >
                {govConnected ? 'Disconnect' : 'Connect'}
              </button>
            </div>

            {/* Quick Voice simulation buttons */}
            <div className="hidden md:flex items-center gap-2 bg-slate-900 p-1.5 rounded-lg border border-slate-800">
              <span className="text-slate-400 text-[10px] font-medium flex items-center gap-1">
                <Mic className="w-3 h-3 text-rose-500" /> Speech Sim:
              </span>
              {voicePresets.map((txt, index) => (
                <button
                  key={index}
                  id={`voice-preset-${index}`}
                  onClick={() => parseVoiceText(txt)}
                  className="bg-slate-800 hover:bg-slate-750 text-[10px] text-slate-300 px-2 py-0.5 rounded transition"
                  title={txt}
                >
                  Sample {index + 1}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* 3. Main Container Layout */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 grid grid-cols-1 lg:grid-cols-4 gap-6">

        {/* Sidebar Nav (1 Column) */}
        <nav id="app-sidebar-navigation" className="hidden lg:block lg:col-span-1 space-y-4">
          <div className="bg-slate-950/40 p-4 rounded-2xl border border-slate-800/80 space-y-1.5">
            <p className="text-[10px] uppercase tracking-wider font-bold text-slate-500 px-3 mb-2">Main Menu</p>
            
            <button
              id="nav-home"
              onClick={() => setActiveTab('home')}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-sm font-medium transition ${
                activeTab === 'home' ? 'bg-teal-500 text-slate-950 shadow-md' : 'text-slate-300 hover:bg-slate-800/50'
              }`}
            >
              <span className="flex items-center gap-2.5">
                <Activity className="w-4 h-4" /> Issue Dashboard
              </span>
              <span className="text-[10px] bg-slate-900/40 px-2 py-0.5 rounded text-white font-bold">{issues.length}</span>
            </button>

            <button
              id="nav-report"
              onClick={() => {
                setActiveTab('report');
                setScanResult(null);
                setSelectedPresetImage('');
              }}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm font-medium transition ${
                activeTab === 'report' ? 'bg-teal-500 text-slate-950 shadow-md' : 'text-slate-300 hover:bg-slate-800/50'
              }`}
            >
              <Camera className="w-4 h-4" /> AI Vision Camera
            </button>

            <button
              id="nav-map"
              onClick={() => setActiveTab('map')}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm font-medium transition ${
                activeTab === 'map' ? 'bg-teal-500 text-slate-950 shadow-md' : 'text-slate-300 hover:bg-slate-800/50'
              }`}
            >
              <Layers className="w-4 h-4" /> Interactive Map & Hotspots
            </button>

            <button
              id="nav-verify"
              onClick={() => setActiveTab('verify')}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-sm font-medium transition ${
                activeTab === 'verify' ? 'bg-teal-500 text-slate-950 shadow-md' : 'text-slate-300 hover:bg-slate-800/50'
              }`}
            >
              <span className="flex items-center gap-2.5">
                <Users className="w-4 h-4" /> Citizen Verifications
              </span>
              <span className="text-[10px] bg-rose-500/20 text-rose-300 px-2 py-0.5 rounded font-bold">LIVE</span>
            </button>

            <button
              id="nav-chatbot"
              onClick={() => setActiveTab('chatbot')}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm font-medium transition ${
                activeTab === 'chatbot' ? 'bg-teal-500 text-slate-950 shadow-md' : 'text-slate-300 hover:bg-slate-800/50'
              }`}
            >
              <Bot className="w-4 h-4" /> CivicHero Bot
            </button>

            <button
              id="nav-ngo"
              onClick={() => setActiveTab('ngo-csr')}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm font-medium transition ${
                activeTab === 'ngo-csr' ? 'bg-teal-500 text-slate-950 shadow-md' : 'text-slate-300 hover:bg-slate-800/50'
              }`}
            >
              <Heart className="w-4 h-4" /> NGO & CSR Portal
            </button>

            <button
              id="nav-playstore"
              onClick={() => setActiveTab('playstore')}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm font-medium transition ${
                activeTab === 'playstore' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-300 hover:bg-slate-800/50'
              }`}
            >
              <Smartphone className="w-4 h-4 text-indigo-400" /> Play Store Dev Kit
            </button>

            <button
              id="nav-emergency"
              onClick={() => setActiveTab('emergency')}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm font-medium transition bg-rose-50 text-rose-600 hover:bg-rose-100 border border-rose-200/80`}
            >
              <AlertTriangle className="w-4 h-4 text-rose-500 animate-pulse" /> Emergency SOS Panel
            </button>
          </div>

          {/* Quick AI Suggestions & Micro Weather Widget */}
          <div className="bg-gradient-to-br from-blue-50 to-indigo-50/50 p-4 rounded-2xl border border-indigo-100 shadow-sm">
            <div className="flex items-center gap-2 text-indigo-600 text-xs font-bold mb-2">
              <Brain className="w-4 h-4" />
              <span>AI Civic Suggestions</span>
            </div>
            <p className="text-xs text-slate-700 leading-relaxed mb-3">
              "Heavy rains forecast on July 1st. Topographic models flag **Vasanth Nagar Lowland** as high risk for flooding. Solid Waste Dept should clear silt traps."
            </p>
            <div className="flex items-center justify-between text-[11px] text-slate-500 border-t border-indigo-100 pt-2.5">
              <span>Weather: 24°C • Rainy</span>
              <span className="text-teal-600 font-bold">94% Confidence</span>
            </div>
          </div>

          {/* Daily Challenges */}
          <div className="bg-slate-950/40 p-4 rounded-2xl border border-slate-800/80">
            <div className="flex items-center gap-2 text-teal-400 text-xs font-bold mb-3">
              <Award className="w-4 h-4 text-amber-500" />
              <span>Active Daily Challenges</span>
            </div>
            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span className="text-slate-300 font-medium">Verify 2 Road potholes nearby</span>
                  <span className="text-slate-400 font-bold">50 XP</span>
                </div>
                <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-teal-400 h-full w-1/2 rounded-full"></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span className="text-slate-300 font-medium">Report 1 illegal waste heap</span>
                  <span className="text-slate-400 font-bold">100 XP</span>
                </div>
                <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-teal-400 h-full w-0 rounded-full"></div>
                </div>
              </div>
            </div>
          </div>
        </nav>

        {/* Dashboard Content area (3 Columns) */}
        <section id="dashboard-content-area" className="lg:col-span-3 space-y-6">

          {/* LOADING STATE */}
          {loading && (
            <div className="flex flex-col items-center justify-center py-20 gap-4 bg-slate-950/20 rounded-2xl border border-slate-800/50">
              <div className="w-12 h-12 rounded-full border-4 border-slate-700 border-t-teal-400 animate-spin"></div>
              <p className="text-slate-400 text-sm animate-pulse">Retrieving civic data streams...</p>
            </div>
          )}

          {/* TAB 1: LIST DASHBOARD */}
          {!loading && activeTab === 'home' && (
            <div className="space-y-6">
              {/* CENTRALIZED ACTIVE MUNICIPAL & GOVERNMENT OPERATIONS CENTER */}
              <div id="centralized-gov-ops-hub" className="bg-slate-950/40 rounded-3xl border border-slate-800 p-5 space-y-4 shadow-2xl relative overflow-hidden transition-all duration-300">
                <div className="absolute top-0 right-0 w-96 h-96 bg-teal-500/5 rounded-full blur-3xl pointer-events-none" />
                <div className="absolute bottom-0 left-0 w-96 h-96 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none" />
                
                {/* Header */}
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-800/60 relative z-10">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="relative flex h-2 w-2">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-teal-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-2 w-2 bg-teal-500"></span>
                      </span>
                      <span className="text-[9px] uppercase font-black tracking-widest text-teal-400">Integrated Government & Citizen Portal</span>
                    </div>
                    <h2 className="text-lg font-black text-slate-100 flex items-center gap-2">
                      <Globe className="w-5 h-5 text-teal-400 animate-pulse" />
                      Active Local Government Hub
                    </h2>
                    <p className="text-xs text-slate-400">
                      Centralizing official gateway nodes, offline disaster-resilience protocols, and crowd-sourced verification loops.
                    </p>
                  </div>

                  {/* Territory Selector & Expand Toggle Button */}
                  <div className="flex flex-wrap items-center gap-2">
                    <div className="flex items-center gap-2 bg-slate-950 p-2 rounded-xl border border-slate-800">
                      <MapPin className="w-4 h-4 text-teal-400 animate-bounce" />
                      <div className="text-left">
                        <span className="block text-[8px] uppercase font-black text-slate-500 tracking-wider">Active Territory</span>
                        <select
                          value={selectedCity}
                          onChange={(e: any) => {
                            setSelectedCity(e.target.value);
                            const selectedNodeMap: any = {
                              bengaluru: 'BBMP-GRID-NODE-048',
                              darbhanga: 'DMC-BIH-GRID-092',
                              patna: 'PMC-BIH-GRID-011',
                              mumbai: 'BMC-MH-GRID-204',
                              delhi: 'MCD-DL-GRID-105'
                            };
                            setGovStatus((prev: any) => ({
                              ...prev,
                              officialNode: selectedNodeMap[e.target.value] || 'BBMP-GRID-NODE-048'
                            }));
                          }}
                          className="bg-transparent text-xs font-bold text-slate-200 outline-none cursor-pointer capitalize pr-4 select-none"
                        >
                          <option value="darbhanga" className="bg-slate-950">Bihar, Darbhanga (DMC)</option>
                          <option value="bengaluru" className="bg-slate-950">Karnataka, Bengaluru (BBMP)</option>
                          <option value="patna" className="bg-slate-950">Bihar, Patna (PMC)</option>
                          <option value="mumbai" className="bg-slate-950">Maharashtra, Mumbai (BMC)</option>
                          <option value="delhi" className="bg-slate-950">New Delhi, Delhi (MCD)</option>
                        </select>
                      </div>
                    </div>

                    <button
                      onClick={() => setIsGovHubExpanded(!isGovHubExpanded)}
                      className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md transition-all active:scale-95 cursor-pointer select-none"
                    >
                      <span>{isGovHubExpanded ? 'Confine Hub' : 'Expand Portal Operations'}</span>
                      {isGovHubExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Collapsed quick status highlights */}
                {!isGovHubExpanded && (
                  <div className="relative z-10 grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-1 text-xs">
                    <div className="bg-slate-900/30 p-2.5 rounded-xl border border-slate-800/80 flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                      <div>
                        <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider leading-none">Officials Directory</p>
                        <p className="text-[11px] font-semibold text-slate-300 mt-1">Directory Active</p>
                      </div>
                    </div>
                    <div className="bg-slate-900/30 p-2.5 rounded-xl border border-slate-800/80 flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                      <div>
                        <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider leading-none">CPGRAMS Sync</p>
                        <p className="text-[11px] font-semibold text-slate-300 mt-1">{govConnected ? 'Connected' : 'Offline Mode'}</p>
                      </div>
                    </div>
                    <div className="bg-slate-900/30 p-2.5 rounded-xl border border-slate-800/80 flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
                      <div>
                        <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider leading-none">Storm Protocol</p>
                        <p className="text-[11px] font-semibold text-slate-300 mt-1">{offlineMode ? 'Offline Queue' : 'Monsoon Active'}</p>
                      </div>
                    </div>
                    <div className="bg-slate-900/30 p-2.5 rounded-xl border border-slate-800/80 flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-indigo-500" />
                      <div>
                        <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider leading-none">P2P Verification</p>
                        <p className="text-[11px] font-semibold text-slate-300 mt-1">{verificationTasks.length} Live Audits</p>
                      </div>
                    </div>
                  </div>
                )}

                {/* Expanded Portal Sections */}
                {isGovHubExpanded && (
                  <div className="space-y-6 pt-2">
                    {/* Sub-grid: 1. Officials & Contact Board | 2. GovConnect Registry Sync */}
                    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 relative z-10">
                  {/* Left Column: Officials Directory */}
                  <div className="lg:col-span-7 space-y-4">
                    {(() => {
                      const mc = MUNICIPAL_DATA[selectedCity] || MUNICIPAL_DATA.bengaluru;
                      return (
                        <div className="space-y-4">
                          <div className="bg-slate-900/40 p-4 rounded-2xl border border-slate-800 space-y-3">
                            <div className="flex items-center justify-between">
                              <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">{mc.name} (Desk)</h3>
                              <span className="text-[9px] bg-teal-500/10 text-teal-400 border border-teal-500/30 px-2 py-0.5 rounded font-black">{mc.code}</span>
                            </div>
                            <p className="text-[11px] text-slate-400 leading-relaxed">{mc.address}</p>
                            
                            <div className="grid grid-cols-2 gap-2 pt-2 text-[11px] border-t border-slate-800">
                              <div>
                                <span className="text-slate-500 font-bold block">Grievance Cell Email</span>
                                <span className="text-slate-300 font-medium truncate block select-all underline cursor-pointer">{mc.email}</span>
                              </div>
                              <div>
                                <span className="text-slate-500 font-bold block">Emergency Helpline</span>
                                <span className="text-teal-400 font-extrabold flex items-center gap-1">
                                  <Volume2 className="w-3.5 h-3.5" /> {mc.helpline}
                                </span>
                              </div>
                            </div>
                          </div>

                          <div className="space-y-2">
                            <h4 className="text-[10px] font-black uppercase text-slate-500 tracking-wider">Responsible Municipal Officials</h4>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                              {mc.officials.map((off, index) => (
                                <div key={index} className="bg-slate-900/20 p-3 rounded-xl border border-slate-800/80 space-y-1 hover:border-slate-700 transition">
                                  <p className="text-[9px] text-slate-500 font-bold uppercase leading-none">{off.role}</p>
                                  <p className="text-xs font-black text-slate-200 leading-tight mt-0.5">{off.name}</p>
                                  <p className="text-[10px] text-teal-400 hover:underline cursor-pointer pt-1" onClick={() => {
                                    alert(`Direct phone for ${off.name} (${off.role}) copied: ${off.contact}`);
                                  }}>
                                    📞 {off.contact}
                                  </p>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      );
                    })()}
                  </div>

                  {/* Right Column: GovConnect Registry Sync */}
                  <div className="lg:col-span-5 bg-slate-900/30 p-4 rounded-2xl border border-slate-800/80 space-y-4 flex flex-col justify-between">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5 text-xs font-extrabold text-slate-200">
                          <Database className="w-4 h-4 text-indigo-400 animate-pulse" />
                          <span>GovConnect™ Registry</span>
                        </div>
                        <span className={`text-[9px] px-2 py-0.5 rounded font-black ${govConnected ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30' : 'bg-slate-800 text-slate-500'}`}>
                          {govConnected ? 'CONNECTED' : 'OFFLINE'}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 leading-relaxed">
                        Pulls and synchronizes officially filed public complaints from CPGRAMS & state databases into your local active feed.
                      </p>

                      <div className="space-y-2 text-[11px]">
                        <div className="flex justify-between border-b border-slate-800/50 pb-1">
                          <span className="text-slate-500">Gateway Node:</span>
                          <span className="text-slate-300 font-bold truncate max-w-[150px]">{govStatus?.gatewayName || 'CPGRAMS'}</span>
                        </div>
                        <div className="flex justify-between border-b border-slate-800/50 pb-1">
                          <span className="text-slate-500">Registry ID:</span>
                          <span className="text-indigo-400 font-extrabold">{govStatus?.officialNode || 'NODE-048'}</span>
                        </div>
                        <div className="flex justify-between pb-1">
                          <span className="text-slate-500">Pending Sync:</span>
                          <span className="text-amber-500 font-bold">{govConnected ? `${govStatus?.availableGovRecordsCount || 0} Official Cases` : 'N/A'}</span>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2 pt-2">
                      <button
                        onClick={handleSyncGovRecords}
                        disabled={!govConnected || govSyncing}
                        className={`w-full flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider transition ${
                          govConnected && !govSyncing
                            ? 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg active:scale-95'
                            : 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
                        }`}
                      >
                        <RefreshCw className={`w-3.5 h-3.5 ${govSyncing ? 'animate-spin' : ''}`} />
                        {govSyncing ? 'Synchronizing Nodes...' : 'Pull Official Cases'}
                      </button>
                      
                      {govMessage && (
                        <p className="text-[10px] text-center text-teal-400 animate-pulse">{govMessage}</p>
                      )}
                    </div>
                  </div>
                </div>

                {/* Grid 2: 3. Storm Resilience Offline Sync | 4. P2P Neighborhood Audit Hub */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-slate-800/60 relative z-10">
                  
                  {/* Left Panel: Storm Resilience offline-first mode */}
                  <div className="bg-slate-900/30 p-4 rounded-2xl border border-slate-800 space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <Zap className="w-4 h-4 text-yellow-400 animate-bounce" />
                        <h3 className="text-xs font-black text-slate-200 uppercase tracking-wider">Storm Resilience Protocol</h3>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-[10px] text-slate-400 font-medium">Offline Storage:</span>
                        <button
                          onClick={toggleOfflineMode}
                          className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors focus:outline-none ${offlineMode ? 'bg-rose-600' : 'bg-slate-800'}`}
                        >
                          <span className={`inline-block h-3.5 w-3.5 transform rounded-full bg-white transition-transform ${offlineMode ? 'translate-x-4.5' : 'translate-x-1'}`} />
                        </button>
                      </div>
                    </div>

                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      Snap photos & report defects in cell dead zones during monsoons. Reports are cached locally in browser IndexedDB/SQLite & uploaded once the stable network grid returns.
                    </p>

                    <div className="bg-slate-950 p-3 rounded-xl border border-slate-800/80 space-y-3">
                      <div className="flex justify-between items-center text-xs">
                        <span className="text-slate-500 font-bold">Local Queue Status:</span>
                        <span className={`font-black ${offlineQueue.length > 0 ? 'text-yellow-400 animate-pulse' : 'text-emerald-400'}`}>
                          {offlineQueue.length > 0 ? `${offlineQueue.length} Stored Reports` : 'Database Synchronized'}
                        </span>
                      </div>

                      {offlineQueue.length > 0 && (
                        <div className="space-y-2 border-t border-slate-900 pt-2.5">
                          <div className="max-h-20 overflow-y-auto space-y-1 pr-1">
                            {offlineQueue.map((item, idx) => (
                              <div key={idx} className="flex justify-between items-center text-[10px] bg-slate-900 p-1.5 rounded border border-slate-800">
                                <span className="text-slate-300 font-bold truncate max-w-[120px]">{item.title}</span>
                                <span className="text-slate-500 font-mono text-[9px]">Monsoon Queue</span>
                              </div>
                            ))}
                          </div>
                          
                          <button
                            onClick={syncOfflineQueue}
                            disabled={syncingOfflineQueue}
                            className="w-full bg-gradient-to-r from-yellow-500 to-amber-600 hover:from-yellow-400 hover:to-amber-500 text-slate-950 font-black text-xs py-2.5 rounded-lg transition uppercase tracking-wider flex items-center justify-center gap-1"
                          >
                            <RefreshCw className={`w-3.5 h-3.5 ${syncingOfflineQueue ? 'animate-spin' : ''}`} />
                            {syncingOfflineQueue ? 'Uploading Queue...' : 'Sync Queued Reports (+150 XP)'}
                          </button>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Right Panel: P2P Neighborhood Audit Hub */}
                  <div className="bg-slate-900/30 p-4 rounded-2xl border border-slate-800 space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <Users className="w-4 h-4 text-emerald-400" />
                        <h3 className="text-xs font-black text-slate-200 uppercase tracking-wider">P2P Verification Tasks</h3>
                      </div>
                      <span className="text-[9px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded font-black">CROWD-SOURCED</span>
                    </div>

                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      Validate active neighborhood reports within 200m to eliminate duplicates, confirm contractor repairs, and earn XP / Eco-Coins.
                    </p>

                    <div className="space-y-2.5 max-h-[140px] overflow-y-auto pr-1">
                      {loadingTasks ? (
                        <div className="text-center py-6 text-slate-500 text-xs animate-pulse">Loading active neighborhood tasks...</div>
                      ) : verificationTasks.length === 0 ? (
                        <div className="text-center py-6 text-slate-500 text-xs">No active audits pending in this ward territory.</div>
                      ) : (
                        verificationTasks.slice(0, 3).map((task) => {
                          const isCompleted = completedTaskIds.includes(task.id);
                          return (
                            <div key={task.id} className={`bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex items-center justify-between gap-3 transition ${isCompleted ? 'opacity-40 line-through border-emerald-950' : 'hover:border-slate-700'}`}>
                              <div className="flex items-center gap-2 flex-1 min-w-0">
                                <img src={task.imageUrl} className="w-9 h-9 object-cover rounded-lg border border-slate-800" alt="" />
                                <div className="min-w-0">
                                  <p className="text-[10px] font-black text-slate-200 truncate leading-tight">{task.title}</p>
                                  <p className="text-[9px] text-slate-500 truncate leading-tight mt-0.5">📍 ~150 meters away</p>
                                </div>
                              </div>
                              
                              {isCompleted ? (
                                <span className="text-[10px] font-black text-emerald-400 bg-emerald-950/20 px-2 py-1 rounded">COMPLETED</span>
                              ) : (
                                <div className="flex items-center gap-1">
                                  <button
                                    onClick={() => handleP2PAction(task, task.status === 'completed' ? 'fixed' : 'verified')}
                                    className="bg-emerald-500/10 hover:bg-emerald-500 text-emerald-400 hover:text-slate-950 text-[9px] font-bold px-2 py-1 rounded border border-emerald-500/30 transition"
                                    title={task.status === 'completed' ? 'Confirm defect is completely fixed' : 'Confirm this issue is currently active'}
                                  >
                                    {task.status === 'completed' ? 'Fixed' : 'Active'}
                                  </button>
                                  <button
                                    onClick={() => handleP2PAction(task, 'fake')}
                                    className="bg-rose-500/10 hover:bg-rose-500 text-rose-400 hover:text-white text-[9px] font-bold px-2 py-1 rounded border border-rose-500/30 transition"
                                    title="Flag report as duplicate, spam, or fake"
                                  >
                                    Fake
                                  </button>
                                </div>
                              )}
                            </div>
                          );
                        })
                      )}
                    </div>
                  </div>

                </div>
                  </div>
                )}
              </div>

              {/* Stats Overview */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-slate-950/40 p-4 rounded-2xl border border-slate-800/80 text-center">
                  <p className="text-xs text-slate-400 font-medium">Reported Issues</p>
                  <p className="text-3xl font-black text-slate-100 mt-1">{analytics?.totalReports || issues.length}</p>
                </div>
                <div className="bg-slate-950/40 p-4 rounded-2xl border border-slate-800/80 text-center">
                  <p className="text-xs text-slate-400 font-medium">Resolution Rate</p>
                  <p className="text-3xl font-black text-teal-600 mt-1">{analytics?.resolutionRate || '82'}%</p>
                </div>
                <div className="bg-slate-950/40 p-4 rounded-2xl border border-slate-800/80 text-center">
                  <p className="text-xs text-slate-400 font-medium">Avg Resolution</p>
                  <p className="text-3xl font-black text-indigo-600 mt-1">{analytics?.averageResolutionTime || '4.8h'}</p>
                </div>
                <div className="bg-slate-950/40 p-4 rounded-2xl border border-slate-800/80 text-center">
                  <p className="text-xs text-slate-400 font-medium">Active Workers</p>
                  <p className="text-3xl font-black text-rose-600 mt-1">4</p>
                </div>
              </div>

              {/* Department Load Benchmarking (Only shown for Officers, Admins & CSRs) */}
              {['officer', 'admin', 'csr'].includes(currentRole) && analytics?.departmentLoad && (
                <div className="bg-slate-950/40 p-5 rounded-2xl border border-slate-800/80 space-y-4">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                    <TrendingUp className="w-4 h-4 text-teal-400" /> Departmental Load & Budget Allocations
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    {analytics.departmentLoad.map((dept: any, index: number) => (
                      <div key={index} className="bg-slate-900 p-3.5 rounded-xl border border-slate-800">
                        <p className="text-xs font-semibold text-slate-200 truncate">{dept.name}</p>
                        <div className="flex items-center justify-between mt-2.5">
                          <span className="text-[11px] text-slate-400">Load: {dept.load} active</span>
                          <span className="text-[11px] text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded font-bold">{dept.budget}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Filters Header */}
              <div className="flex flex-wrap justify-between items-center gap-4 bg-slate-950/40 p-4 rounded-2xl border border-slate-800/80">
                <div className="flex-1 min-w-[200px] relative">
                  <Search className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                  <input
                    id="search-input"
                    type="text"
                    placeholder="Search by street name, title or category..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full bg-slate-900 text-slate-200 text-xs pl-9 pr-4 py-2.5 rounded-xl border border-slate-800 focus:outline-none focus:border-teal-500 transition"
                  />
                </div>

                <div className="flex items-center gap-2">
                  <select
                    id="category-filter"
                    value={filterCategory}
                    onChange={(e) => setFilterCategory(e.target.value)}
                    className="bg-slate-900 text-slate-300 text-xs py-2.5 px-3 rounded-xl border border-slate-800 focus:outline-none focus:border-teal-500"
                  >
                    <option value="all">All Categories</option>
                    <option value="pothole">Potholes</option>
                    <option value="garbage">Garbage Pileups</option>
                    <option value="broken_streetlight">Streetlights</option>
                    <option value="water_leakage">Water Leakages</option>
                    <option value="overflow_drain">Sewers / Drains</option>
                    <option value="park_damage">Parks</option>
                  </select>

                  <select
                    id="status-filter"
                    value={filterStatus}
                    onChange={(e) => setFilterStatus(e.target.value)}
                    className="bg-slate-900 text-slate-300 text-xs py-2.5 px-3 rounded-xl border border-slate-800 focus:outline-none focus:border-teal-500"
                  >
                    <option value="all">All Statuses</option>
                    <option value="reported">Reported</option>
                    <option value="verified">Verified</option>
                    <option value="assigned">Assigned</option>
                    <option value="in_progress">In Progress</option>
                    <option value="completed">Completed</option>
                    <option value="confirmed">Confirmed</option>
                  </select>
                </div>
              </div>

              {/* Issues Grid layout */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredIssues.map((issue) => (
                  <div
                    key={issue.id}
                    id={`issue-card-${issue.id}`}
                    className="bg-slate-950/40 rounded-2xl border border-slate-800/80 overflow-hidden hover:border-slate-700 transition flex flex-col group"
                  >
                    {/* Header Image */}
                    <div className="relative h-44 bg-slate-900 overflow-hidden">
                      <img
                        src={issue.imageUrl}
                        alt={issue.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent"></div>
                      
                      {/* Gov Sync Badge */}
                      {issue.isGovSynced && (
                        <span className="absolute top-3 left-3 text-[9px] bg-indigo-600/90 text-white border border-indigo-500/45 px-2 py-0.5 rounded-md font-extrabold uppercase tracking-widest flex items-center gap-1 shadow-md z-10">
                          <Globe className="w-2.5 h-2.5 animate-pulse" /> Gov Portal Record
                        </span>
                      )}

                      {/* Priority Tag */}
                      <span className={`absolute top-3 right-3 text-[10px] px-2.5 py-1 rounded-full font-bold uppercase tracking-wider ${
                        issue.recommendedPriority === 'immediate' ? 'bg-rose-500 text-white animate-pulse' :
                        issue.recommendedPriority === 'high' ? 'bg-orange-500 text-white' :
                        'bg-teal-500 text-slate-950'
                      }`}>
                        {issue.recommendedPriority}
                      </span>

                      {/* Status Tag */}
                      <span className="absolute bottom-3 left-3 text-[10px] bg-slate-900/80 text-teal-400 border border-teal-500/30 px-2.5 py-1 rounded-full font-bold uppercase tracking-widest">
                        {issue.status}
                      </span>
                    </div>

                    {/* Content */}
                    <div className="p-4 flex-1 flex flex-col justify-between">
                      <div className="space-y-2">
                        <div className="flex items-center gap-1 text-[11px] text-slate-400 font-semibold">
                          <MapPin className="w-3.5 h-3.5 text-teal-400" />
                          <span className="truncate">{issue.location.address}</span>
                        </div>
                        <h4 className="font-bold text-slate-100 leading-tight line-clamp-1 group-hover:text-teal-400 transition">
                          {issue.title}
                        </h4>
                        <p className="text-slate-400 text-xs line-clamp-2 leading-relaxed">
                          {issue.description}
                        </p>
                      </div>

                      {/* AI Analytics attributes */}
                      <div className="grid grid-cols-2 gap-2 my-4 bg-slate-900/50 p-2.5 rounded-xl border border-slate-800 text-[11px]">
                        <div>
                          <span className="text-slate-500">Dept:</span>
                          <span className="text-slate-300 font-medium ml-1 truncate block">{issue.suggestedDepartment}</span>
                        </div>
                        <div>
                          <span className="text-slate-500">Cost Est:</span>
                          <span className="text-slate-300 font-bold ml-1 block">{issue.estimatedRepairCost}</span>
                        </div>
                      </div>

                      {/* Interaction Footer */}
                      <div className="flex items-center justify-between border-t border-slate-800 pt-3 text-xs">
                        <button
                          onClick={() => handleUpvote(issue.id)}
                          className={`flex items-center gap-1.5 transition ${
                            issue.citizenUpvoters?.includes(userProfile?.uid || '')
                              ? 'text-rose-400 font-bold'
                              : 'text-slate-400 hover:text-white'
                          }`}
                        >
                          <TrendingUp className="w-4 h-4 text-rose-500" /> Endorse ({issue.citizenUpvotes})
                        </button>

                        <button
                          onClick={() => setSelectedIssue(issue)}
                          className="text-teal-400 hover:text-teal-300 font-semibold flex items-center gap-1"
                        >
                          Inspect & Audit <ChevronRight />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}

                {filteredIssues.length === 0 && (
                  <div className="col-span-2 py-16 text-center bg-slate-950/20 rounded-2xl border border-slate-800/50">
                    <p className="text-slate-400 text-sm">No reported issues found matching criteria.</p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: AI SCANNER CAMERA */}
          {!loading && activeTab === 'report' && (
            <div className="bg-slate-950/40 p-6 rounded-2xl border border-slate-800/80 space-y-6">
              <div>
                <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2">
                  <Camera className="w-5 h-5 text-teal-600" />
                  Hyperlocal AI Vision Scan
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  Simulate taking a live photo of a community issue. Gemini Vision automatically reads, categorizes, logs pole IDs, and estimates repairs instantly.
                </p>
              </div>

              {/* Selection Tabs */}
              <div className="flex border-b border-slate-800 pb-1 gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setReportInputMode('camera');
                    setCapturedImage(null);
                    setScanResult(null);
                    setSelectedPresetImage('');
                  }}
                  className={`px-4 py-2 text-xs font-black uppercase tracking-wider border-b-2 transition ${
                    reportInputMode === 'camera'
                      ? 'border-teal-400 text-teal-400'
                      : 'border-transparent text-slate-400 hover:text-slate-300'
                  }`}
                >
                  📸 Live Camera Stream
                </button>
                <button
                  type="button"
                  onClick={() => {
                    stopCamera();
                    setReportInputMode('upload');
                    setCapturedImage(null);
                    setScanResult(null);
                    setSelectedPresetImage('');
                  }}
                  className={`px-4 py-2 text-xs font-black uppercase tracking-wider border-b-2 transition ${
                    reportInputMode === 'upload'
                      ? 'border-teal-400 text-teal-400'
                      : 'border-transparent text-slate-400 hover:text-slate-300'
                  }`}
                >
                  📤 Upload Photo File
                </button>
                <button
                  type="button"
                  onClick={() => {
                    stopCamera();
                    setReportInputMode('presets');
                    setCapturedImage(null);
                    setScanResult(null);
                    setSelectedPresetImage('');
                  }}
                  className={`px-4 py-2 text-xs font-black uppercase tracking-wider border-b-2 transition ${
                    reportInputMode === 'presets'
                      ? 'border-teal-400 text-teal-400'
                      : 'border-transparent text-slate-400 hover:text-slate-300'
                  }`}
                >
                  🖼️ Mock Issue Presets
                </button>
              </div>

              {/* Mode 1: Real-Time Camera */}
              {reportInputMode === 'camera' && (
                <div className="space-y-4">
                  {capturedImage ? (
                    /* Captured Preview */
                    <div className="space-y-4">
                      <div className="relative rounded-2xl overflow-hidden border border-teal-500/30 max-h-[380px] bg-slate-900 shadow-lg flex items-center justify-center">
                        <img src={capturedImage} alt="Captured community issue" className="w-full h-full max-h-[380px] object-cover" />
                        <div className="absolute top-3 left-3 bg-teal-950/90 border border-teal-500/40 text-teal-400 text-[10px] font-black px-2.5 py-1 rounded-md uppercase tracking-wider shadow-md">
                          Preview Captured Photo
                        </div>
                      </div>

                      <div className="flex flex-col sm:flex-row gap-3">
                        <button
                          type="button"
                          onClick={() => triggerAiScan(capturedImage)}
                          disabled={scanning}
                          className="flex-1 py-3 bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-400 hover:to-emerald-400 text-slate-950 font-black text-xs rounded-xl transition flex items-center justify-center gap-2 shadow-md cursor-pointer disabled:opacity-50"
                        >
                          <Sparkles className="w-4 h-4" />
                          {scanning ? 'Analyzing with Gemini...' : 'Analyze Captured Photo with Gemini AI'}
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setCapturedImage(null);
                            startCamera();
                          }}
                          className="px-5 py-3 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 font-bold text-xs rounded-xl transition flex items-center justify-center gap-2 cursor-pointer"
                        >
                          <RotateCcw className="w-4 h-4" />
                          Retake Photo
                        </button>
                      </div>
                    </div>
                  ) : cameraActive ? (
                    /* Live video feed */
                    <div className="space-y-4">
                      <div className="relative rounded-2xl overflow-hidden border-2 border-slate-800 bg-black aspect-video max-h-[380px] mx-auto shadow-2xl flex items-center justify-center">
                        <video
                          ref={videoRef}
                          autoPlay
                          playsInline
                          muted
                          className="w-full h-full object-cover"
                        />
                        
                        {/* High-Tech HUD Overlays */}
                        <div className="absolute inset-0 border-8 border-transparent flex flex-col justify-between p-4 pointer-events-none">
                          <div className="flex justify-between items-start">
                            <div className="flex items-center gap-2 bg-slate-950/80 border border-slate-800/80 rounded-md px-2.5 py-1">
                              <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
                              <span className="text-[9px] text-rose-400 font-black uppercase tracking-widest">LIVE HUD FEED</span>
                            </div>
                            <span className="text-[9px] text-slate-400 font-mono bg-slate-950/80 border border-slate-800/80 px-2 py-1 rounded">
                              FPS: 30 / ISO: AUTO
                            </span>
                          </div>

                          {/* Crosshairs target in middle */}
                          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                            <div className="w-12 h-12 border border-dashed border-teal-500/40 rounded-full flex items-center justify-center">
                              <div className="w-2 h-2 bg-teal-400/50 rounded-full" />
                            </div>
                          </div>

                          <div className="flex justify-between items-end">
                            <span className="text-[9px] text-slate-400 font-mono bg-slate-950/80 border border-slate-800/80 px-2 py-1 rounded">
                              GRID: ACTIVE
                            </span>
                            <span className="text-[9px] text-teal-400 font-black tracking-wider bg-slate-950/80 border border-slate-800/80 px-2 py-1 rounded">
                              ATLASONE EYE v2.1
                            </span>
                          </div>
                        </div>
                      </div>

                      <div className="flex gap-3 justify-center">
                        <button
                          type="button"
                          onClick={capturePhoto}
                          className="flex-1 max-w-md py-3.5 bg-rose-500 hover:bg-rose-400 text-white font-black text-xs rounded-xl transition flex items-center justify-center gap-2 shadow-lg shadow-rose-500/20 active:scale-95 cursor-pointer"
                        >
                          <Camera className="w-4 h-4" /> Click / Snap Photo of Civic Problem
                        </button>
                        <button
                          type="button"
                          onClick={stopCamera}
                          className="px-5 py-3.5 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 font-bold text-xs rounded-xl transition flex items-center justify-center cursor-pointer"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  ) : (
                    /* Initial Turn-on-camera button state */
                    <div className="bg-slate-950 p-8 rounded-2xl border border-slate-800/60 text-center space-y-4">
                      <div className="w-14 h-14 bg-teal-500/10 border border-teal-500/20 rounded-full flex items-center justify-center mx-auto text-teal-400">
                        <Camera className="w-7 h-7" />
                      </div>
                      <div className="space-y-1">
                        <h3 className="text-sm font-black text-slate-100">Click Live Photo of Civic Issue</h3>
                        <p className="text-xs text-slate-400 max-w-md mx-auto">
                          AtlasOne requires on-site photographic evidence to automatically extract metadata, confirm geographical coordinates, and register reports.
                        </p>
                      </div>
                      
                      {cameraError && (
                        <div className="bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs px-4 py-2.5 rounded-xl max-w-md mx-auto font-medium">
                          🚨 {cameraError}
                        </div>
                      )}

                      <button
                        type="button"
                        onClick={startCamera}
                        className="py-3 px-6 bg-teal-500 hover:bg-teal-400 text-slate-950 font-black text-xs rounded-xl shadow-md transition inline-flex items-center gap-2 cursor-pointer"
                      >
                        <Camera className="w-4 h-4" /> Start Live Camera Device
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* Mode 1.5: Upload Photo File */}
              {reportInputMode === 'upload' && (
                <div className="space-y-4">
                  {capturedImage ? (
                    /* Uploaded Preview with Action to scan */
                    <div className="space-y-4">
                      <div className="relative rounded-2xl overflow-hidden border border-teal-500/30 max-h-[380px] bg-slate-900 shadow-lg flex items-center justify-center">
                        <img src={capturedImage} alt="Uploaded community issue" className="w-full h-full max-h-[380px] object-cover" />
                        <div className="absolute top-3 left-3 bg-teal-950/90 border border-teal-500/40 text-teal-400 text-[10px] font-black px-2.5 py-1 rounded-md uppercase tracking-wider shadow-md">
                          Uploaded Photo Preview
                        </div>
                      </div>

                      <div className="flex flex-col sm:flex-row gap-3">
                        <button
                          type="button"
                          onClick={() => triggerAiScan(capturedImage)}
                          disabled={scanning}
                          className="flex-1 py-3 bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-400 hover:to-emerald-400 text-slate-950 font-black text-xs rounded-xl transition flex items-center justify-center gap-2 shadow-md cursor-pointer disabled:opacity-50"
                        >
                          <Sparkles className="w-4 h-4" />
                          {scanning ? 'Analyzing with Gemini...' : 'Analyze Uploaded Photo with Gemini AI'}
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setCapturedImage(null);
                          }}
                          className="px-5 py-3 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 font-bold text-xs rounded-xl transition flex items-center justify-center gap-2 cursor-pointer"
                        >
                          <RotateCcw className="w-4 h-4" />
                          Clear / Upload Another
                        </button>
                      </div>
                    </div>
                  ) : (
                    /* File Upload Dropzone (Interactive Drag-and-Drop & Manual Selection) */
                    <div
                      onDragEnter={handleDrag}
                      onDragOver={handleDrag}
                      onDragLeave={handleDrag}
                      onDrop={handleDrop}
                      className={`relative bg-slate-950/60 p-8 rounded-2xl border-2 border-dashed text-center space-y-4 transition ${
                        dragActive ? 'border-teal-400 bg-teal-500/5' : 'border-slate-800 hover:border-slate-700/80'
                      }`}
                    >
                      <input
                        type="file"
                        id="photo-file-upload"
                        accept="image/*"
                        onChange={handleFileChange}
                        className="hidden"
                      />
                      
                      <div className="w-14 h-14 bg-teal-500/10 border border-teal-500/20 rounded-full flex items-center justify-center mx-auto text-teal-400">
                        <Upload className="w-7 h-7" />
                      </div>
                      
                      <div className="space-y-1">
                        <h3 className="text-sm font-black text-slate-100">Drag & Drop Image Here</h3>
                        <p className="text-xs text-slate-400 max-w-md mx-auto">
                          Accepts JPEG, PNG, or WebP files from your desktop or mobile device.
                        </p>
                      </div>

                      <div className="flex items-center justify-center gap-3">
                        <span className="h-px bg-slate-800 w-12"></span>
                        <span className="text-[10px] text-slate-500 font-bold uppercase">Or</span>
                        <span className="h-px bg-slate-800 w-12"></span>
                      </div>

                      <label
                        htmlFor="photo-file-upload"
                        className="inline-flex py-3 px-6 bg-teal-500 hover:bg-teal-400 text-slate-950 font-black text-xs rounded-xl shadow-md transition cursor-pointer select-none items-center gap-2"
                      >
                        <Upload className="w-4 h-4" /> Browse Local Files
                      </label>
                    </div>
                  )}
                </div>
              )}

              {/* Mode 2: Presets */}
              {reportInputMode === 'presets' && (
                <div className="space-y-4">
                  <p className="text-[11px] text-slate-500 font-bold uppercase tracking-wider">Select a realistic preset problem image:</p>
                  <div className="grid grid-cols-3 gap-4">
                    {scanPresets.map((preset) => (
                      <button
                        key={preset.name}
                        id={`scan-preset-${preset.category}`}
                        onClick={() => triggerAiScan(preset.url)}
                        className={`relative rounded-xl overflow-hidden border-2 h-28 group transition ${
                          selectedPresetImage === preset.url ? 'border-teal-400 shadow-lg shadow-teal-500/20' : 'border-slate-800 hover:border-slate-700'
                        }`}
                      >
                        <img src={preset.url} alt={preset.name} className="w-full h-full object-cover" />
                        <div className="absolute inset-0 bg-slate-950/50 flex items-center justify-center">
                          <span className="text-[11px] font-bold text-white uppercase tracking-wider px-2 text-center">
                            {preset.name}
                          </span>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Scan Loader */}
              {scanning && (
                <div className="bg-slate-900/90 p-6 rounded-2xl border border-rose-500/30 space-y-4 text-center shadow-2xl">
                  {offlineMode ? (
                    <div className="space-y-4">
                      <div className="flex items-center justify-center gap-2">
                        <Cpu className="w-5 h-5 text-rose-400 animate-pulse" />
                        <span className="text-xs font-black text-rose-400 uppercase tracking-widest">Local Edge-ML Processing Active</span>
                      </div>
                      
                      {/* Matrix tensor calculations simulation */}
                      <div className="bg-slate-950 p-4 rounded-xl border border-rose-950/40 font-mono text-[10px] text-left text-rose-300 space-y-1.5 max-h-[160px] overflow-hidden relative">
                        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent pointer-events-none" />
                        <p className="text-teal-400 animate-pulse">Initializing WASM WebNN Accelerator...</p>
                        <p className="text-slate-500">Loading model weights: atlasone_lite_v3.onnx (4.2 MB Cached)</p>
                        <p className="text-teal-400">Model loaded successfully. Performing local image tensor compilation...</p>
                        <p className="text-slate-400">Processing pixel matrix: [1, 224, 224, 3] float32 array...</p>
                        <p className="text-rose-400 animate-pulse">Evaluating convolutional layers (stride=2)... [94.8% Done]</p>
                        <p className="text-rose-400 animate-pulse">Running Softmax categorical probabilities... Done [Latency: 18ms]</p>
                      </div>

                      <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-rose-950">
                        <div className="bg-rose-500 h-full rounded-full animate-[pulse_1s_infinite]"></div>
                      </div>

                      <div className="text-[10px] text-rose-400 font-extrabold uppercase animate-pulse">
                        Analyzing photograph completely offline...
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-3 py-4">
                      <div className="w-10 h-10 border-4 border-slate-700 border-t-teal-400 rounded-full animate-spin mx-auto"></div>
                      <p className="text-xs text-slate-300 animate-pulse font-medium">Gemini 3.5 Flash modeling pixels & resolving geographic data...</p>
                    </div>
                  )}
                </div>
              )}

              {/* Analysis Result Box */}
              {scanResult && (
                <div className="bg-slate-900/60 p-5 rounded-xl border border-teal-500/20 space-y-4">
                  <div className="flex justify-between items-center pb-3 border-b border-slate-800">
                    <span className="text-xs font-bold uppercase tracking-wider text-teal-400 flex items-center gap-1.5">
                      {scanResult.onDeviceModel ? <Cpu className="w-4 h-4 text-rose-400 animate-pulse" /> : <Sparkles className="w-4 h-4 text-teal-400" />}
                      {scanResult.onDeviceModel ? 'On-Device MobileNet-V3 Assessment' : 'Gemini AI Vision Assessment'}
                    </span>
                    <span className={`text-[10px] px-2.5 py-1 rounded font-bold ${scanResult.onDeviceModel ? 'bg-rose-950/40 text-rose-400 border border-rose-500/20' : 'bg-teal-500/10 text-teal-300'}`}>
                      {(scanResult.confidence * 100).toFixed(0)}% Confidence ({scanResult.onDeviceModel ? 'OFFLINE ML' : 'CLOUD'})
                    </span>
                  </div>

                  {/* Form fields with auto-filled values */}
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[11px] text-slate-400 font-bold uppercase mb-1">Generated Title</label>
                        <input
                          id="report-title"
                          type="text"
                          value={customReportTitle}
                          onChange={(e) => setCustomReportTitle(e.target.value)}
                          className="w-full bg-slate-950 text-slate-100 text-xs p-2.5 rounded-lg border border-slate-800"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] text-slate-400 font-bold uppercase mb-1">Suggested Department</label>
                        <input
                          type="text"
                          disabled
                          value={scanResult.suggestedDepartment}
                          className="w-full bg-slate-950 text-slate-400 text-xs p-2.5 rounded-lg border border-slate-800"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] text-slate-400 font-bold uppercase mb-1">Problem Description</label>
                      <textarea
                        id="report-desc"
                        rows={3}
                        value={customReportDesc}
                        onChange={(e) => setCustomReportDesc(e.target.value)}
                        className="w-full bg-slate-950 text-slate-100 text-xs p-2.5 rounded-lg border border-slate-800 resize-none"
                      />
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div>
                        <label className="block text-[11px] text-slate-400 font-bold uppercase mb-1">Cost Projection</label>
                        <div className="bg-slate-950 p-2.5 rounded-lg text-xs font-bold text-slate-200 border border-slate-800">
                          {scanResult.estimatedRepairCost}
                        </div>
                      </div>
                      <div>
                        <label className="block text-[11px] text-slate-400 font-bold uppercase mb-1">Time Frame</label>
                        <div className="bg-slate-950 p-2.5 rounded-lg text-xs font-bold text-slate-200 border border-slate-800">
                          {scanResult.estimatedRepairTime}
                        </div>
                      </div>
                      <div>
                        <label className="block text-[11px] text-slate-400 font-bold uppercase mb-1">Target Asset Code</label>
                        <div className="bg-slate-950 p-2.5 rounded-lg text-xs font-bold text-slate-200 border border-slate-800">
                          {scanResult.ocrAssetId || 'No Asset Tag detected'}
                        </div>
                      </div>
                      <div>
                        <label className="block text-[11px] text-slate-400 font-bold uppercase mb-1">Severity Priority</label>
                        <select
                          id="report-severity"
                          value={customSeverity}
                          onChange={(e: any) => setCustomSeverity(e.target.value)}
                          className="w-full bg-slate-950 text-slate-100 text-xs p-2.5 rounded-lg border border-slate-800"
                        >
                          <option value="low">Low</option>
                          <option value="medium">Medium</option>
                          <option value="high">High</option>
                          <option value="critical">Critical</option>
                        </select>
                      </div>
                    </div>

                    <button
                      id="submit-report-btn"
                      onClick={submitReport}
                      className="w-full py-3 bg-gradient-to-r from-teal-500 to-emerald-500 text-slate-950 font-bold text-xs rounded-xl shadow-md transition hover:scale-[1.01]"
                    >
                      File Issue & Verify with Nearby Citizens
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: MAPS & HOTSPOTS */}
          {!loading && activeTab === 'map' && (
            <div className="space-y-6">
              <div className="bg-slate-950/40 p-5 rounded-2xl border border-slate-800/80">
                <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 mb-4">
                  <div>
                    <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2">
                      <Layers className="w-5 h-5 text-teal-600" />
                      Live Grid Map & Predictive Hotspots
                    </h2>
                    <p className="text-xs text-slate-400">
                      Topographical machine learning matches weather metrics to predict future assets failure using MapmyIndia Mappls.
                    </p>
                  </div>
                </div>
                   {/* Map Simulator or Live Mappls Map */}
                 <div className="relative bg-slate-950 rounded-xl h-96 overflow-hidden border border-slate-800">
                   {hasMapplsKey ? (
                     <MapplsMapComponent
                       center={userLiveLocation || (mapCenters[selectedCity] || mapCenters.bengaluru)}
                       issues={issues}
                       hotspots={hotspots}
                       selectedCity={selectedCity}
                       onIssueClick={setSelectedIssue}
                       userLiveLocation={userLiveLocation}
                     />
                   ) : (
                     /* Instruction Splash screen within the component */
                     <div className="flex flex-col items-center justify-center h-full p-8 text-center bg-slate-900/60 rounded-xl border border-slate-800">
                       <div className="w-12 h-12 rounded-full bg-teal-500/10 border border-teal-500/20 flex items-center justify-center mb-3">
                         <MapPin className="w-6 h-6 text-teal-400 animate-bounce" />
                       </div>
                       <h3 className="text-sm font-black text-slate-100 uppercase tracking-wider mb-2">Mappls India Map Ready</h3>
                       <p className="text-xs text-slate-400 max-w-md leading-relaxed mb-4">
                         Unlock real-time topographical visualization, interactive pins, and live user tracking with MapmyIndia Mappls.
                       </p>
                       <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80 text-[11px] text-left text-slate-300 space-y-1.5 w-full max-w-sm">
                         <p className="font-extrabold text-teal-400 uppercase tracking-widest text-[9px]">How to activate live map:</p>
                         <p>1. Open <strong className="text-slate-100">Settings</strong> (⚙️ gear icon, top-right corner).</p>
                         <p>2. Select <strong className="text-slate-100">Secrets</strong>.</p>
                         <p>3. Add <code className="bg-slate-900 px-1 py-0.5 rounded text-teal-300 font-mono">MAPPLS_API_KEY</code> or <code className="bg-slate-900 px-1 py-0.5 rounded text-teal-300 font-mono">GOOGLE_MAPS_PLATFORM_KEY</code>.</p>
                         <p>4. Paste your key & press Enter. The app activates automatically!</p>
                       </div>
                     </div>
                   )}

                   {/* Floating Map Legend */}
                   <div className="absolute bottom-4 right-4 bg-slate-950/90 border border-slate-800 p-3.5 rounded-xl space-y-2 text-[10px] w-48 z-10">
                    <p className="font-bold text-slate-300 border-b border-slate-800 pb-1.5 uppercase tracking-wider">Legend</p>
                    <div className="flex items-center gap-2 text-slate-400">
                      <span className="w-2.5 h-2.5 rounded-full bg-teal-500 inline-block"></span>
                      <span>Active reported issue</span>
                    </div>
                    <div className="flex items-center gap-2 text-slate-400">
                      <span className="w-4 h-4 rounded-full bg-rose-500/20 border border-rose-500 inline-flex items-center justify-center">
                        <span className="w-1.5 h-1.5 bg-rose-500 rounded-full"></span>
                      </span>
                      <span>AI Predictive Hotspot</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Predictive list */}
              <div className="bg-slate-950/40 p-5 rounded-2xl border border-slate-800/80 space-y-4">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                  <Brain className="w-4.5 h-4.5 text-indigo-400" /> Machine Learning Damage Risk Forecasts
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {hotspots.map((hotspot) => (
                    <div key={hotspot.id} className="bg-slate-900 p-4 rounded-xl border border-slate-800 hover:border-slate-700 transition space-y-3">
                      <div className="flex justify-between items-start">
                        <span className="text-[10px] bg-slate-800 text-indigo-300 font-bold px-2 py-0.5 rounded uppercase">
                          {hotspot.category}
                        </span>
                        <span className="text-xs font-black text-rose-400">
                          {hotspot.riskScore}% Risk
                        </span>
                      </div>
                      <div className="space-y-1">
                        <p className="text-xs font-bold text-slate-200 truncate">{hotspot.address}</p>
                        <p className="text-[11px] text-slate-400 line-clamp-3 leading-relaxed">{hotspot.predictionReason}</p>
                      </div>
                      <div className="border-t border-slate-800/80 pt-2 text-[10px] text-emerald-400">
                        <span className="font-semibold block uppercase text-[8px] text-slate-500 mb-0.5">Recommended Mitigation:</span>
                        {hotspot.recommendedPreventativeAction}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: CITIZEN VERIFICATION */}
          {!loading && activeTab === 'verify' && (
            <div className="space-y-6">
              <div className="bg-slate-950/40 p-5 rounded-2xl border border-slate-800/80">
                <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2">
                  <Users className="w-5 h-5 text-teal-400" />
                  Community Consensus Loop
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  Help filter spam and speed up resolution. Earn 40 XP and 20 Eco-Coins for confirming or signaling fake issues!
                </p>
              </div>

              {/* Verify Queue cards */}
              <div className="space-y-4">
                {issues.filter(i => i.status === 'reported' || i.status === 'completed').map((issue) => (
                  <div key={issue.id} className="bg-slate-950/40 p-5 rounded-2xl border border-slate-800 flex flex-wrap md:flex-nowrap gap-5">
                    <img src={issue.imageUrl} className="w-full md:w-44 h-32 object-cover rounded-xl" alt="" />
                    <div className="flex-1 space-y-3">
                      <div>
                        <span className="text-[9px] bg-indigo-950 text-indigo-400 border border-indigo-900/40 px-2 py-0.5 rounded uppercase font-bold">
                          {issue.status === 'reported' ? 'Awaiting initial validation' : 'Worker Resolution Proof'}
                        </span>
                        <h4 className="font-bold text-slate-100 mt-1">{issue.title}</h4>
                        <p className="text-slate-400 text-xs line-clamp-2 mt-0.5">{issue.description}</p>
                      </div>

                      <div className="flex items-center gap-2 text-[10px] text-slate-500">
                        <MapPin className="w-3.5 h-3.5" /> <span>{issue.location.address}</span>
                      </div>

                      {/* Vote Buttons */}
                      <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-800/60">
                        {issue.status === 'reported' ? (
                          <>
                            <button
                              onClick={() => handleVerifyVote(issue.id, 'verified')}
                              className="bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 text-[11px] px-3 py-1.5 rounded-lg font-bold border border-emerald-500/20"
                            >
                              ✓ Still Exists / Genuine
                            </button>
                            <button
                              onClick={() => handleVerifyVote(issue.id, 'fake')}
                              className="bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 text-[11px] px-3 py-1.5 rounded-lg font-bold border border-rose-500/20"
                            >
                              ✗ Spam / Doesn't Exist
                            </button>
                          </>
                        ) : (
                          <>
                            <button
                              onClick={() => handleVerifyVote(issue.id, 'fixed')}
                              className="bg-teal-500/10 hover:bg-teal-500/20 text-teal-400 text-[11px] px-3 py-1.5 rounded-lg font-bold border border-teal-500/20"
                            >
                              ✓ I Confirm It is Beautifully Fixed
                            </button>
                          </>
                        )}
                        <button
                          onClick={() => handleVerifyVote(issue.id, 'evidence_needed')}
                          className="bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] px-3 py-1.5 rounded-lg font-bold border border-slate-700"
                        >
                          Need more Photo Evidence
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 5: AI CHATBOT */}
          {!loading && activeTab === 'chatbot' && (
            <div className="bg-slate-950/40 p-5 rounded-2xl border border-slate-800/80 h-[500px] flex flex-col justify-between">
              <div>
                <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
                  <Bot className="w-5 h-5 text-teal-400" /> CivicHero AI Assistant
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  Ask me how to report issues, claim rewards, check progress, or why green waste recycling matters.
                </p>
              </div>

              {/* Chat log */}
              <div className="flex-1 overflow-y-auto my-4 space-y-3 pr-2 scrollbar-thin">
                {chatMessages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div className={`p-3 rounded-xl max-w-[80%] text-xs leading-relaxed ${
                      msg.role === 'user'
                        ? 'bg-gradient-to-r from-teal-500 to-emerald-500 text-slate-950 font-medium'
                        : 'bg-slate-900 border border-slate-800 text-slate-200'
                    }`}>
                      {msg.text}
                    </div>
                  </div>
                ))}
                {botTyping && (
                  <div className="flex justify-start">
                    <div className="bg-slate-900 border border-slate-800 p-3 rounded-xl text-xs text-slate-400 animate-pulse">
                      CivicHero is compiling metadata reply...
                    </div>
                  </div>
                )}
              </div>

              {/* Message Input box */}
              <div className="flex gap-2">
                <input
                  id="chat-input"
                  type="text"
                  placeholder="Type your civic query here..."
                  value={userInput}
                  onChange={(e) => setUserInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && sendChat()}
                  className="flex-1 bg-slate-900 text-slate-100 text-xs p-3 rounded-xl border border-slate-800 focus:outline-none focus:border-teal-500"
                />
                <button
                  id="send-chat-btn"
                  onClick={sendChat}
                  className="p-3 bg-teal-500 text-slate-950 rounded-xl hover:scale-105 transition shadow-md"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* TAB 6: NGO & CSR PORTALS */}
          {!loading && activeTab === 'ngo-csr' && (
            <div className="space-y-6">

              {/* Civic Karma & Eco-Coin Rewards Shop */}
              <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 p-6 rounded-2xl border border-teal-500/30 space-y-5 shadow-2xl relative overflow-hidden">
                <div className="absolute top-0 right-0 w-64 h-64 bg-teal-500/5 rounded-full blur-3xl pointer-events-none" />
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 pb-4 border-b border-slate-800/80">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <Award className="w-5 h-5 text-amber-500" />
                      <h2 className="text-xl font-black text-slate-100">Civic Karma & Eco-Coin Shop</h2>
                    </div>
                    <p className="text-xs text-slate-400">
                      Redeem the Eco-Coins you earned from peer-verifications, active cleanups, and local reporting!
                    </p>
                  </div>
                  <div className="bg-teal-500/10 border border-teal-500/30 px-4 py-2.5 rounded-xl flex items-center gap-2 shadow-lg">
                    <Coins className="w-5 h-5 text-amber-400 animate-bounce" />
                    <div>
                      <span className="text-[9px] text-slate-400 block uppercase font-bold leading-none">Your Balance</span>
                      <span className="text-base font-black text-teal-400 mt-1 block leading-none">{userProfile?.coins || 0} Eco-Coins</span>
                    </div>
                  </div>
                </div>

                {/* Rewards Grid */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  {[
                    {
                      id: 'bmtc_pass',
                      title: 'BMTC Metro 1-Day Pass',
                      sponsor: 'Bengaluru Transit Board',
                      cost: 150,
                      icon: '🚇',
                      desc: 'Full day unlimited travel on standard metropolitan routes.'
                    },
                    {
                      id: 'park_entry',
                      title: 'Botanical Gardens Pass',
                      sponsor: 'DMC Horticulture Dept',
                      cost: 100,
                      icon: '🌳',
                      desc: 'Free weekend entry for up to two people to the botanical gardens.'
                    },
                    {
                      id: 'metro_ride',
                      title: '50% Metro Ride Coupon',
                      sponsor: 'Namma Metro Transit',
                      cost: 75,
                      icon: '🚈',
                      desc: 'Save 50% on your next trip fare of any distance.'
                    },
                    {
                      id: 'greens_cafe',
                      title: 'Free Coffee Voucher',
                      sponsor: 'Greens Organic Cafe',
                      cost: 50,
                      icon: '☕',
                      desc: 'Redeem for an organic, ethically sourced espresso or herbal infusion.'
                    }
                  ].map((reward) => (
                    <div key={reward.id} className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 flex flex-col justify-between hover:border-teal-500/30 transition relative">
                      <div className="space-y-2">
                        <div className="flex justify-between items-start">
                          <span className="text-2xl">{reward.icon}</span>
                          <span className="text-[10px] bg-slate-950 px-2 py-0.5 rounded-md text-amber-400 font-bold border border-amber-500/20">
                            🪙 {reward.cost} Coins
                          </span>
                        </div>
                        <div>
                          <h4 className="text-xs font-black text-slate-200 mt-1">{reward.title}</h4>
                          <span className="text-[9px] text-teal-400 font-semibold">{reward.sponsor}</span>
                          <p className="text-[10px] text-slate-400 mt-1.5 leading-relaxed">{reward.desc}</p>
                        </div>
                      </div>
                      <button
                        onClick={() => handleRedeemCoupon(reward.id, reward.cost, reward.title)}
                        className="w-full bg-slate-950 hover:bg-teal-500 hover:text-slate-950 text-slate-300 border border-slate-800 hover:border-teal-400/50 text-[10px] font-bold py-2 rounded-lg mt-3.5 transition cursor-pointer"
                      >
                        Redeem Voucher
                      </button>
                    </div>
                  ))}
                </div>

                {/* Unlocked Coupons Section */}
                {unlockedCoupons.length > 0 && (
                  <div className="border-t border-slate-800/80 pt-4 space-y-3">
                    <p className="text-xs font-black text-slate-300 uppercase tracking-widest flex items-center gap-1 flex-wrap">
                      <CheckCircle className="w-4 h-4 text-emerald-400" /> Active Unlocked Vouchers ({unlockedCoupons.length})
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {unlockedCoupons.map((coupon, idx) => (
                        <div key={idx} className="bg-slate-950 rounded-xl overflow-hidden border border-emerald-500/20 flex relative">
                          {/* Left Stub */}
                          <div className="bg-gradient-to-b from-teal-500 to-emerald-500 w-2.5" />
                          
                          {/* Main stub body */}
                          <div className="p-4 flex-1 space-y-2.5">
                            <div className="flex justify-between items-start">
                              <div>
                                <span className="text-[8px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded font-black uppercase">SECURE CIVIC VOUCHER</span>
                                <h4 className="text-xs font-black text-slate-200 mt-1">{coupon.title}</h4>
                              </div>
                              <span className="text-xs text-slate-500 font-mono">CODE UNLOCKED</span>
                            </div>

                            <div className="flex items-center justify-between gap-2 bg-slate-900 px-3 py-2 rounded border border-slate-800">
                              <span className="font-mono text-xs text-emerald-400 font-black tracking-wider select-all">{coupon.code}</span>
                              <button
                                onClick={() => {
                                  navigator.clipboard.writeText(coupon.code);
                                  alert("Voucher code copied to clipboard!");
                                }}
                                className="text-[10px] text-slate-400 hover:text-white flex items-center gap-1 font-semibold"
                              >
                                <Copy className="w-3 h-3" /> Copy
                              </button>
                            </div>

                            {/* Ticket security barcode */}
                            <div className="flex items-center justify-between pt-1 border-t border-slate-900 text-[9px] text-slate-500 font-mono">
                              <div className="flex flex-col gap-0.5">
                                <span>REDEEMED: {new Date(coupon.redeemedAt).toLocaleDateString()}</span>
                                <span className="text-amber-500">EXPIRES: 15 MINUTES</span>
                              </div>
                              {/* Vector Barcode Representation */}
                              <div className="flex items-end gap-0.5 h-6 bg-slate-900 px-1.5 py-1 rounded">
                                <span className="w-0.5 h-full bg-slate-400" />
                                <span className="w-1 h-full bg-slate-400" />
                                <span className="w-0.5 h-2/3 bg-slate-400" />
                                <span className="w-1.5 h-full bg-slate-400" />
                                <span className="w-0.5 h-1/2 bg-slate-400" />
                                <span className="w-0.5 h-full bg-slate-400" />
                                <span className="w-1 h-full bg-slate-400" />
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
              
              {/* NGO Projects section */}
              <div className="bg-slate-950/40 p-5 rounded-2xl border border-slate-800/80 space-y-4">
                <div>
                  <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2">
                    <Heart className="w-5 h-5 text-rose-500 animate-pulse" />
                    NGO Restorative Campaigns
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    NGOs adopt unresolved civic complaints to drive cleanups. Join a local campaign to clean up your neighborhood!
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {ngoList.map((ngo) => (
                    <div key={ngo.id} className="bg-slate-900 rounded-xl overflow-hidden border border-slate-800 flex flex-col justify-between">
                      <img src={ngo.imageUrl} className="h-40 w-full object-cover" alt="" />
                      <div className="p-4 space-y-3">
                        <div>
                          <span className="text-[9px] bg-teal-500/10 text-teal-300 px-2 py-0.5 rounded font-bold uppercase tracking-wider">
                            {ngo.ngoName}
                          </span>
                          <h4 className="font-bold text-slate-200 mt-1 text-sm">{ngo.title}</h4>
                          <p className="text-slate-400 text-xs mt-1 leading-relaxed line-clamp-3">{ngo.description}</p>
                        </div>

                        {/* Volunteer indicators */}
                        <div className="space-y-2">
                          <div className="flex justify-between text-[11px] text-slate-400">
                            <span>Volunteers Joined: {ngo.volunteersCount} / {ngo.volunteersNeeded}</span>
                            <span className="text-teal-400 font-bold">{Math.round((ngo.volunteersCount / ngo.volunteersNeeded) * 100)}% Complete</span>
                          </div>
                          <div className="w-full bg-slate-950 h-1 rounded-full overflow-hidden">
                            <div className="bg-teal-400 h-full" style={{ width: `${(ngo.volunteersCount / ngo.volunteersNeeded) * 100}%` }}></div>
                          </div>
                        </div>

                        <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-xs">
                          <button
                            onClick={() => handleVolunteer(ngo.id)}
                            className="bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold px-3 py-1.5 rounded-lg text-[11px] transition"
                          >
                            ✓ Join as Volunteer (+150 XP)
                          </button>
                          <span className="text-slate-500 text-[10px]">{ngo.location}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* CSR Campaigns Section */}
              <div className="bg-slate-950/40 p-5 rounded-2xl border border-slate-800/80 space-y-4">
                <div>
                  <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2">
                    <Users className="w-5 h-5 text-indigo-400" />
                    Corporate Social Responsibility (CSR) Impacts
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    Multinational companies funding larger capital infrastructure works (Solar panels, pipeline sensors, park upgrades).
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {csrList.map((csr) => (
                    <div key={csr.id} className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-3">
                      <div className="flex justify-between items-start">
                        <div>
                          <h4 className="font-bold text-slate-200 text-sm">{csr.projectTitle}</h4>
                          <p className="text-xs text-teal-400 font-semibold">{csr.companyName}</p>
                        </div>
                        <span className="text-xs bg-indigo-950 text-indigo-300 px-2 py-1 rounded font-bold">
                          ₹{(csr.fundingAmount / 100000).toFixed(1)} Lakhs
                        </span>
                      </div>
                      <p className="text-slate-400 text-xs leading-relaxed">{csr.impactDescription}</p>
                      
                      <div className="flex items-center justify-between border-t border-slate-800 pt-2 text-[10px] text-slate-500">
                        <span>Sectors: {csr.supportedSectors.join(', ')}</span>
                        <span className="text-emerald-400 font-bold bg-emerald-950/30 px-2 py-0.5 rounded">
                          {csr.activeIssuesResolved} issues solved
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 7: EMERGENCY SOS */}
          {!loading && activeTab === 'emergency' && (
            <div className="bg-slate-950/40 p-6 rounded-2xl border border-rose-900/30 space-y-6">
              <div className="text-center space-y-2">
                <AlertTriangle className="w-12 h-12 text-rose-500 animate-ping mx-auto" />
                <h2 className="text-2xl font-black text-rose-500 tracking-tight">ONE TAP CIVIC EMERGENCY SOS</h2>
                <p className="text-xs text-slate-400 max-w-md mx-auto">
                  Instantly transmits your exact live geolocation coords and profile details to police, ambulance, fire, gas control room, and nearby disaster volunteers.
                </p>
              </div>

              {/* SOS Emergency Buttons */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <button
                  onClick={() => alert('SOS: Sending live coordinates to Fire Rescue Services!')}
                  className="bg-rose-500 text-slate-950 font-bold p-5 rounded-2xl flex flex-col items-center justify-center gap-2 hover:scale-105 transition"
                >
                  <Flame className="w-8 h-8 text-slate-950" />
                  <span className="text-sm font-black uppercase">Gas Leak / Fire SOS</span>
                </button>
                <button
                  onClick={() => alert('SOS: Dispatching Municipal Flood and Disaster Unit with boats!')}
                  className="bg-indigo-500 text-slate-950 font-bold p-5 rounded-2xl flex flex-col items-center justify-center gap-2 hover:scale-105 transition"
                >
                  <Activity className="w-8 h-8 text-slate-950 animate-pulse" />
                  <span className="text-sm font-black uppercase">Flood / Drainage SOS</span>
                </button>
                <button
                  onClick={() => alert('SOS: Summoning Road Accident Emergency Ambulance!')}
                  className="bg-amber-500 text-slate-950 font-bold p-5 rounded-2xl flex flex-col items-center justify-center gap-2 hover:scale-105 transition"
                >
                  <Navigation className="w-8 h-8 text-slate-950 animate-spin" />
                  <span className="text-sm font-black uppercase">Road Accident SOS</span>
                </button>
              </div>

              {/* Emergency Contacts card */}
              <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 text-xs space-y-3">
                <p className="font-bold text-slate-300 uppercase tracking-wider text-[10px]">National Helpline Protocols</p>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="bg-slate-950 p-3 rounded border border-slate-800">
                    <p className="text-slate-500 uppercase text-[9px]">Police Central</p>
                    <p className="text-sm font-black text-slate-200 mt-1">112</p>
                  </div>
                  <div className="bg-slate-950 p-3 rounded border border-slate-800">
                    <p className="text-slate-500 uppercase text-[9px]">Ambulance</p>
                    <p className="text-sm font-black text-slate-200 mt-1">108</p>
                  </div>
                  <div className="bg-slate-950 p-3 rounded border border-slate-800">
                    <p className="text-slate-500 uppercase text-[9px]">Fire Safety</p>
                    <p className="text-sm font-black text-slate-200 mt-1">101</p>
                  </div>
                  <div className="bg-slate-950 p-3 rounded border border-slate-800">
                    <p className="text-slate-500 uppercase text-[9px]">Women Helpline</p>
                    <p className="text-sm font-black text-slate-200 mt-1">1091</p>
                  </div>
                </div>
              </div>

              {/* Local Territory Emergency Contacts (Last Located Area) */}
              <div className={`p-5 rounded-2xl border text-xs space-y-4 transition-all duration-300 ${
                offlineMode 
                  ? 'bg-rose-950/25 border-rose-500/40 shadow-lg shadow-rose-950/30' 
                  : 'bg-slate-900/80 border-slate-800'
              }`}>
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <MapPin className={`w-4 h-4 ${offlineMode ? 'text-rose-400 animate-pulse' : 'text-teal-400'}`} />
                      <h3 className="text-sm font-bold text-slate-100 uppercase tracking-wide">
                        {offlineMode ? '🚨 Offline Local Emergency Contacts' : '📍 Local Emergency Contacts Grid'}
                      </h3>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      {offlineMode 
                        ? 'App is OUT OF NETWORK. Loaded cached physical emergency lines for your last known location.'
                        : 'Emergency dispatch lines and local nodal offices for the selected territory.'}
                    </p>
                  </div>
                  
                  <div className={`px-3 py-1.5 rounded-xl border text-[10px] font-black uppercase tracking-wider flex items-center gap-1.5 ${
                    offlineMode 
                      ? 'bg-rose-900/30 border-rose-500/30 text-rose-300 animate-pulse' 
                      : 'bg-emerald-950/30 border-emerald-500/20 text-emerald-300'
                  }`}>
                    <span className="relative flex h-1.5 w-1.5">
                      <span className={`absolute inline-flex h-full w-full rounded-full opacity-75 ${offlineMode ? 'bg-rose-400 animate-ping' : 'bg-emerald-400'}`}></span>
                      <span className={`relative inline-flex rounded-full h-1.5 w-1.5 ${offlineMode ? 'bg-rose-500' : 'bg-emerald-500'}`}></span>
                    </span>
                    <span>Last Located: <span className="capitalize">{selectedCity}</span></span>
                  </div>
                </div>

                {/* Local Grid Numbers */}
                {(() => {
                  const localData = LOCAL_EMERGENCY_CONTACTS[selectedCity] || LOCAL_EMERGENCY_CONTACTS.bengaluru;
                  return (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                      {localData.contacts.map((contact, idx) => (
                        <div 
                          key={idx} 
                          className={`p-3.5 rounded-xl border transition-all duration-200 flex flex-col justify-between gap-3 ${
                            offlineMode 
                              ? 'bg-slate-950/70 border-rose-900/30 hover:border-rose-800/50' 
                              : 'bg-slate-950/50 border-slate-800/80 hover:border-slate-700/60'
                          }`}
                        >
                          <div>
                            <div className="flex items-center justify-between gap-1">
                              <span className="text-[10px] font-black text-slate-300 uppercase tracking-wider truncate">
                                {contact.label}
                              </span>
                              <Phone className="w-3.5 h-3.5 text-teal-400 flex-shrink-0" />
                            </div>
                            <p className="text-[10px] text-slate-500 mt-1 font-medium leading-relaxed">
                              {contact.desc}
                            </p>
                          </div>

                          <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-800/60">
                            <span className="font-mono text-xs font-black text-teal-300">
                              {contact.number}
                            </span>
                            <div className="flex gap-1.5">
                              <a 
                                href={`tel:${contact.number.replace(/[-\s]/g, '')}`}
                                className="px-2.5 py-1 rounded bg-teal-500 hover:bg-teal-400 text-slate-950 text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer"
                              >
                                Call
                              </a>
                              <button 
                                onClick={() => {
                                  navigator.clipboard.writeText(contact.number);
                                  alert(`Copied number: ${contact.number}`);
                                }}
                                className="px-2.5 py-1 rounded bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 text-[10px] font-bold uppercase transition cursor-pointer"
                              >
                                Copy
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  );
                })()}
              </div>
            </div>
          )}

          {/* Tab 8: Google Play Store Dev Kit */}
          {!loading && activeTab === 'playstore' && (
            <div className="bg-slate-950/40 p-6 rounded-2xl border border-indigo-900/40 space-y-6 animate-in fade-in duration-200">
              {/* Header */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
                <div className="flex items-center gap-3">
                  <div className="p-3 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
                    <Smartphone className="w-7 h-7" />
                  </div>
                  <div>
                    <h2 className="text-xl font-black text-slate-100 tracking-tight">Google Play Store Developer Kit</h2>
                    <p className="text-[10px] text-indigo-400 font-extrabold uppercase tracking-wider mt-0.5">Atlasone AI Submission Hub & Assets</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setPlayTab('listings')}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                      playTab === 'listings' ? 'bg-indigo-600 text-white shadow' : 'bg-slate-900 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Store Listings
                  </button>
                  <button
                    onClick={() => setPlayTab('assets')}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                      playTab === 'assets' ? 'bg-indigo-600 text-white shadow' : 'bg-slate-900 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Visual Assets
                  </button>
                  <button
                    onClick={() => setPlayTab('bundle')}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                      playTab === 'bundle' ? 'bg-indigo-600 text-white shadow' : 'bg-slate-900 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Signed AAB Build
                  </button>
                </div>
              </div>

              {/* SECTION 1: STORE LISTINGS METADATA */}
              {playTab === 'listings' && (
                <div className="space-y-6">
                  <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 text-xs text-slate-400 leading-relaxed">
                    Use these professionally drafted titles, descriptions, contact emails, and privacy policy URLs directly inside the <strong>Google Play Console</strong> under the <em>Store Presence &gt; Main Store Listing</em> section.
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* App Identity */}
                    <div className="space-y-4">
                      <div>
                        <label className="text-[10px] font-extrabold uppercase text-slate-500 block mb-1.5">App Name (max 30 chars)</label>
                        <div className="flex items-center gap-2">
                          <input
                            type="text"
                            readOnly
                            value="Atlasone AI"
                            className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 w-full focus:outline-none"
                          />
                          <button
                            onClick={() => handleCopyToClipboard('Atlasone AI', 'appname')}
                            className="p-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-slate-200 rounded-xl transition"
                          >
                            {copiedText === 'appname' ? <CheckCircle className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                          </button>
                        </div>
                      </div>

                      <div>
                        <label className="text-[10px] font-extrabold uppercase text-slate-500 block mb-1.5">Short Description (max 80 chars)</label>
                        <div className="flex items-center gap-2">
                          <input
                            type="text"
                            readOnly
                            value="AI-powered hyperlocal civic problem solver: Scan road defects & earn rewards!"
                            className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 w-full focus:outline-none"
                          />
                          <button
                            onClick={() => handleCopyToClipboard('AI-powered hyperlocal civic problem solver: Scan road defects & earn rewards!', 'shortdesc')}
                            className="p-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-slate-200 rounded-xl transition"
                          >
                            {copiedText === 'shortdesc' ? <CheckCircle className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                          </button>
                        </div>
                      </div>

                      <div>
                        <label className="text-[10px] font-extrabold uppercase text-slate-500 block mb-1.5">Hosted Privacy Policy URL (Compliant for submissions)</label>
                        <div className="flex items-center gap-2">
                          <input
                            type="text"
                            readOnly
                            value={`${window.location.origin}/privacy`}
                            className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 w-full focus:outline-none"
                          />
                          <button
                            onClick={() => handleCopyToClipboard(`${window.location.origin}/privacy`, 'privacypol')}
                            className="p-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-slate-200 rounded-xl transition"
                          >
                            {copiedText === 'privacypol' ? <CheckCircle className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                          </button>
                        </div>
                        <p className="text-[9px] text-slate-500 mt-1">
                          Our server intercepts <strong className="text-teal-400">/privacy</strong> paths to serve a legal-grade, responsive privacy agreement.
                        </p>
                      </div>

                      <div>
                        <label className="text-[10px] font-extrabold uppercase text-slate-500 block mb-1.5">Developer Contact Email</label>
                        <div className="flex items-center gap-2">
                          <input
                            type="text"
                            readOnly
                            value="satyam15e@gmail.com"
                            className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 w-full focus:outline-none"
                          />
                          <button
                            onClick={() => handleCopyToClipboard('satyam15e@gmail.com', 'contactemail')}
                            className="p-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-slate-200 rounded-xl transition"
                          >
                            {copiedText === 'contactemail' ? <CheckCircle className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Full Description */}
                    <div>
                      <div className="flex items-center justify-between mb-1.5">
                        <label className="text-[10px] font-extrabold uppercase text-slate-500 block">Full Description (max 4000 chars)</label>
                        <button
                          onClick={() => handleCopyToClipboard(`Atlasone AI is a revolutionary AI-powered hyperlocal civic participation and problem-solving platform. Designed to bridge the gap between residents, local ward councilors, and municipal field teams, Atlasone AI lets citizens actively monitor, audit, and improve their urban infrastructure.\n\nKey Features:\n- AI Vision Camera Scan: Snaps photos of public defects like potholes, damaged streetlights, water-logging, or overflowing waste dumps. The built-in Google Gemini model automatically processes, categorizes, and estimates repair materials & costs.\n- Automated Ward-Level Grievance Drafting: Converts your scanned photos directly into formatted, formal civic petition PDFs and official municipal complaints ready to dispatch.\n- Peer-to-Peer Neighborhood Verification: Participate in micro-tasks to verify community reports nearby, increasing dispatch speed and accuracy.\n- NGO & CSR Portal Integration: Local corporate partners and businesses can directly fund community issue repair budgets to resolve urgent civic backlog without delays.\n- Gamification & Eco-Coins: Earn profile experience points (XP) and Eco-Coins for completing civic steward activities, which can be redeemed for localized community perks.\n- Direct Municipal Routing: Complaints are categorized with estimated budgets and routed to specialized departments (Public Works, Electricity, Sanitation).\n\nEmpower your community and help build the smart cities of tomorrow. Clean up, fix up, and audit your ward with Atlasone AI!`, 'fulldesc')}
                          className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-[10px] text-slate-300 rounded-lg transition"
                        >
                          {copiedText === 'fulldesc' ? (
                            <>
                              <CheckCircle className="w-3 h-3 text-emerald-400" /> Copied Text
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3" /> Copy Description
                            </>
                          )}
                        </button>
                      </div>
                      <textarea
                        readOnly
                        rows={11}
                        value={`Atlasone AI is a revolutionary AI-powered hyperlocal civic participation and problem-solving platform. Designed to bridge the gap between residents, local ward councilors, and municipal field teams, Atlasone AI lets citizens actively monitor, audit, and improve their urban infrastructure.

Key Features:
- AI Vision Camera Scan: Snaps photos of public defects like potholes, damaged streetlights, water-logging, or overflowing waste dumps. The built-in Google Gemini model automatically processes, categorizes, and estimates repair materials & costs.
- Automated Ward-Level Grievance Drafting: Converts your scanned photos directly into formatted, formal civic petition PDFs and official municipal complaints ready to dispatch.
- Peer-to-Peer Neighborhood Verification: Participate in micro-tasks to verify community reports nearby, increasing dispatch speed and accuracy.
- NGO & CSR Portal Integration: Local corporate partners and businesses can directly fund community issue repair budgets to resolve urgent civic backlog without delays.
- Gamification & Eco-Coins: Earn profile experience points (XP) and Eco-Coins for completing civic steward activities, which can be redeemed for localized community perks.
- Direct Municipal Routing: Complaints are categorized with estimated budgets and routed to specialized departments (Public Works, Electricity, Sanitation).

Empower your community and help build the smart cities of tomorrow. Clean up, fix up, and audit your ward with Atlasone AI!`}
                        className="bg-slate-900 border border-slate-800 rounded-xl p-3 text-xs text-slate-300 w-full focus:outline-none resize-none scrollbar-thin leading-relaxed"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* SECTION 2: VISUAL ASSET DOWNLOADERS (VECTORS & CANVASES) */}
              {playTab === 'assets' && (
                <div className="space-y-6">
                  <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 text-xs text-slate-400 leading-relaxed">
                    Generate and download high-resolution <strong>Google Play compliant assets</strong>. Click the <em>Download PNG</em> button to render and save the asset as a pixel-perfect image directly through your browser.
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    
                    {/* APP ICON CARD */}
                    <div className="bg-slate-900/60 border border-slate-800/80 p-4 rounded-2xl flex flex-col items-center text-center space-y-4">
                      <div>
                        <h3 className="text-xs font-extrabold text-slate-200 uppercase tracking-wider">Play Store App Icon</h3>
                        <p className="text-[10px] text-slate-500 mt-1">Required: 512 x 512 PNG</p>
                      </div>

                      {/* Vector SVG display */}
                      <div className="p-3 bg-slate-950 rounded-2xl border border-slate-850">
                        <svg id="play-store-icon" viewBox="0 0 512 512" className="w-28 h-28 bg-slate-950 rounded-xl">
                          <defs>
                            <linearGradient id="logoIconBg" x1="0%" y1="0%" x2="100%" y2="100%">
                              <stop offset="0%" stopColor="#0a0f24" />
                              <stop offset="100%" stopColor="#111827" />
                            </linearGradient>
                            <linearGradient id="logoIconGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                              <stop offset="0%" stopColor="#2dd4bf" />
                              <stop offset="50%" stopColor="#3b82f6" />
                              <stop offset="100%" stopColor="#6366f1" />
                            </linearGradient>
                          </defs>
                          <rect width="512" height="512" rx="30" fill="url(#logoIconBg)" />
                          <circle cx="256" cy="256" r="220" fill="none" stroke="url(#logoIconGrad)" strokeWidth="6" opacity="0.3" strokeDasharray="20 12"/>
                          <circle cx="256" cy="256" r="180" fill="none" stroke="url(#logoIconGrad)" strokeWidth="2" opacity="0.15"/>
                          
                          <path d="M256,90 C330,90 390,150 390,224 C390,320 256,420 256,420 C256,420 122,320 122,224 C122,150 182,90 256,90 Z" fill="none" stroke="url(#logoIconGrad)" strokeWidth="18" strokeLinejoin="round"/>
                          <circle cx="256" cy="210" r="50" fill="#090d16" stroke="url(#logoIconGrad)" strokeWidth="12" />
                          <circle cx="256" cy="210" r="22" fill="#2dd4bf" />
                          
                          <path d="M185,280 L327,280" stroke="url(#logoIconGrad)" strokeWidth="16" strokeLinecap="round" opacity="0.95"/>
                          <line x1="256" y1="210" x2="256" y2="350" stroke="url(#logoIconGrad)" strokeWidth="6" strokeDasharray="12 6" opacity="0.4" />
                        </svg>
                      </div>

                      <div className="flex w-full gap-2 pt-2">
                        <button
                          onClick={() => downloadSvgAsPng('play-store-icon', 'android_app_icon.png', 512, 512)}
                          className="flex-1 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-[10px] font-black uppercase tracking-wider transition active:scale-95"
                        >
                          Download PNG
                        </button>
                      </div>
                    </div>

                    {/* FEATURE GRAPHIC CARD */}
                    <div className="bg-slate-900/60 border border-slate-800/80 p-4 rounded-2xl flex flex-col items-center text-center space-y-4 md:col-span-2">
                      <div>
                        <h3 className="text-xs font-extrabold text-slate-200 uppercase tracking-wider">Play Store Feature Graphic</h3>
                        <p className="text-[10px] text-slate-500 mt-1">Required: 1024 x 500 PNG (App store header visual)</p>
                      </div>

                      {/* Vector SVG Display */}
                      <div className="w-full bg-slate-950 rounded-2xl border border-slate-850 p-2 overflow-hidden">
                        <svg id="play-store-banner" viewBox="0 0 1024 500" className="w-full aspect-[1024/500] bg-slate-950">
                          <defs>
                            <linearGradient id="bannerBg" x1="0" y1="0" x2="1" y2="1">
                              <stop offset="0%" stopColor="#050814" />
                              <stop offset="100%" stopColor="#0d1527" />
                            </linearGradient>
                            <linearGradient id="bannerAccent" x1="0" y1="0" x2="1" y2="0">
                              <stop offset="0%" stopColor="#2dd4bf" />
                              <stop offset="100%" stopColor="#3b82f6" />
                            </linearGradient>
                          </defs>
                          <rect width="1024" height="500" fill="url(#bannerBg)" />
                          <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#1e293b" strokeWidth="1" opacity="0.3"/>
                          <path d="M100,450 L350,300 L600,400 L850,200 L950,280" fill="none" stroke="#2563eb" strokeWidth="2.5" opacity="0.25"/>
                          <path d="M150,100 L450,220 L750,120 L900,350" fill="none" stroke="#0d9488" strokeWidth="2.5" opacity="0.2"/>
                          
                          <circle cx="350" cy="300" r="8" fill="#3b82f6" opacity="0.7"/>
                          <circle cx="350" cy="300" r="18" fill="none" stroke="#3b82f6" strokeWidth="2" opacity="0.45"/>
                          <circle cx="850" cy="200" r="8" fill="#2dd4bf" opacity="0.7"/>
                          <circle cx="850" cy="200" r="18" fill="none" stroke="#2dd4bf" strokeWidth="2" opacity="0.45"/>
                          
                          <g transform="translate(80, 190)">
                            <rect x="-10" y="-35" width="220" height="5" fill="url(#bannerAccent)" />
                            <text fill="#ffffff" fontSize="58" fontWeight="900" fontFamily="sans-serif" letterSpacing="-1.5">Atlasone AI</text>
                            <text fill="#94a3b8" fontSize="18" fontWeight="600" fontFamily="sans-serif" letterSpacing="0.5" y="48">AI-Powered Hyperlocal Civic Action</text>
                            
                            <g transform="translate(0, 85)">
                              <rect width="115" height="28" rx="6" fill="#111827" stroke="#1f2937" strokeWidth="1"/>
                              <text fill="#2dd4bf" fontSize="10" fontWeight="800" fontFamily="sans-serif" x="14" y="17" letterSpacing="0.5">MUNICIPAL AI</text>
                              
                              <rect x="130" width="130" height="28" rx="6" fill="#111827" stroke="#1f2937" strokeWidth="1"/>
                              <text fill="#3b82f6" fontSize="10" fontWeight="800" fontFamily="sans-serif" x="142" y="17" letterSpacing="0.5">GEO-VERIFICATION</text>
                            </g>
                          </g>
                          
                          <g transform="translate(760, 250)">
                            <circle cx="0" cy="0" r="110" fill="none" stroke="url(#bannerAccent)" strokeWidth="3" opacity="0.1" strokeDasharray="12 6"/>
                            <circle cx="0" cy="0" r="85" fill="none" stroke="url(#bannerAccent)" strokeWidth="1.5" opacity="0.2"/>
                            <circle cx="0" cy="0" r="62" fill="#060913" stroke="url(#bannerAccent)" strokeWidth="4" />
                            
                            <path d="M-15,18 L0,-24 L15,18" fill="none" stroke="#2dd4bf" strokeWidth="8" strokeLinecap="round" strokeLinejoin="round"/>
                            <line x1="-10" y1="4" x2="10" y2="4" stroke="#2dd4bf" strokeWidth="8" strokeLinecap="round"/>
                            <circle cx="0" cy="0" r="9" fill="#3b82f6" />
                          </g>
                        </svg>
                      </div>

                      <button
                        onClick={() => downloadSvgAsPng('play-store-banner', 'feature_graphic.png', 1024, 500)}
                        className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-[10px] font-black uppercase tracking-wider transition active:scale-95"
                      >
                        Download Feature Graphic PNG
                      </button>
                    </div>

                    {/* PHONE SCREENSHOTS SECTION */}
                    <div className="md:col-span-3 border-t border-slate-900 pt-6 space-y-4">
                      <div>
                        <h3 className="text-xs font-extrabold text-slate-200 uppercase tracking-wider">Play Store Phone Screenshots</h3>
                        <p className="text-[10px] text-slate-500 mt-1">Required: Minimum 2-4 screenshots. High fidelity mockups showcasing key sections.</p>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
                        
                        {/* SCREENSHOT 1: DASHBOARD */}
                        <div className="bg-slate-900/40 border border-slate-800/60 p-4 rounded-2xl flex flex-col items-center space-y-4">
                          <span className="text-[10px] bg-indigo-500/10 text-indigo-400 font-extrabold tracking-widest px-2.5 py-1 rounded-full border border-indigo-500/20 uppercase">
                            Screenshot 1: Civic Dashboard
                          </span>
                          
                          <div className="w-full bg-slate-950 rounded-2xl border border-slate-850 p-2 overflow-hidden aspect-[800/1200] max-w-[280px]">
                            <svg id="ss-dash-visual" viewBox="0 0 800 1200" className="w-full bg-slate-950">
                              <rect width="800" height="1200" fill="#080c14"/>
                              <circle cx="400" cy="200" r="300" fill="#2563eb" opacity="0.06" filter="blur(60px)"/>
                              <circle cx="400" cy="1000" r="250" fill="#2dd4bf" opacity="0.06" filter="blur(60px)"/>

                              <text x="400" y="110" textAnchor="middle" fill="#ffffff" fontSize="38" fontWeight="900" fontFamily="sans-serif" letterSpacing="-1">CIVIC DASHBOARD</text>
                              <text x="400" y="152" textAnchor="middle" fill="#94a3b8" fontSize="16" fontWeight="600" fontFamily="sans-serif">Track dispatches in real-time</text>

                              <g transform="translate(180, 210)">
                                <rect width="440" height="880" rx="40" fill="#1e293b" stroke="#334155" strokeWidth="8"/>
                                <rect x="160" y="15" width="120" height="24" rx="12" fill="#0f172a"/>
                                <rect x="12" y="48" width="416" height="814" rx="28" fill="#090d16"/>
                                
                                <g transform="translate(30, 90)">
                                  <text fill="#ffffff" fontSize="21" fontWeight="900" fontFamily="sans-serif">Atlasone AI</text>
                                  <text fill="#2dd4bf" fontSize="9" fontWeight="800" fontFamily="sans-serif" y="16" letterSpacing="1">WARD SERVICE HUB</text>
                                  
                                  <g transform="translate(0, 35)">
                                    <rect width="356" height="60" rx="14" fill="#111827" stroke="#1f2937" strokeWidth="1"/>
                                    <text fill="#94a3b8" fontSize="9" fontWeight="700" fontFamily="sans-serif" x="15" y="25">CITIZEN STATUS</text>
                                    <text fill="#ffffff" fontSize="13" fontWeight="800" fontFamily="sans-serif" x="15" y="42">Satyam Kumar</text>
                                    <rect x="250" y="15" width="90" height="30" rx="10" fill="#2dd4bf" />
                                    <text fill="#090d16" fontSize="10" fontWeight="900" fontFamily="sans-serif" x="265" y="34">LVL 4 (Pro)</text>
                                  </g>
                                </g>
                                
                                <g transform="translate(30, 230)">
                                  <text fill="#94a3b8" fontSize="10" fontWeight="800" fontFamily="sans-serif" letterSpacing="0.5">ACTIVE WARD STATISTICS</text>
                                  <g transform="translate(0, 15)">
                                    <rect width="170" height="85" rx="16" fill="#111827" stroke="#2dd4bf" strokeWidth="1.5" opacity="0.8"/>
                                    <text fill="#2dd4bf" fontSize="11" fontWeight="800" x="15" y="30" fontFamily="sans-serif">OFFICIAL SOLVED</text>
                                    <text fill="#ffffff" fontSize="28" fontWeight="900" x="15" y="65" fontFamily="sans-serif">142</text>
                                    
                                    <rect x="185" width="171" height="85" rx="16" fill="#111827" stroke="#1f2937" strokeWidth="1"/>
                                    <text fill="#94a3b8" fontSize="11" fontWeight="800" x="200" y="30" fontFamily="sans-serif" transform="translate(-185, 0)">REPAIR BACKLOG</text>
                                    <text fill="#ffffff" fontSize="28" fontWeight="900" x="200" y="65" fontFamily="sans-serif" transform="translate(-185, 0)">19 Cases</text>
                                  </g>
                                </g>
                                
                                <g transform="translate(30, 365)">
                                  <text fill="#94a3b8" fontSize="10" fontWeight="800" fontFamily="sans-serif" letterSpacing="0.5">REPORTED COMPLAINTS NEARBY</text>
                                  <g transform="translate(0, 18)">
                                    <rect width="356" height="85" rx="16" fill="#111827" stroke="#1f2937" strokeWidth="1"/>
                                    <circle cx="35" cy="42" r="18" fill="#3b82f6" opacity="0.15"/>
                                    <text fill="#3b82f6" fontSize="14" fontWeight="900" x="29" y="47" fontFamily="sans-serif">⚙</text>
                                    <text fill="#ffffff" fontSize="12" fontWeight="800" x="70" y="35" fontFamily="sans-serif">Severe Pothole on Ward Rd 4</text>
                                    <text fill="#6b7280" fontSize="10" x="70" y="52" fontFamily="sans-serif">Vasanth Nagar • Reported by citizen</text>
                                    <rect x="260" y="28" width="80" height="24" rx="8" fill="#22c55e" opacity="0.15"/>
                                    <text fill="#22c55e" fontSize="9" fontWeight="900" x="272" y="43" fontFamily="sans-serif">RESOLVED</text>
                                  </g>
                                  <g transform="translate(0, 115)">
                                    <rect width="356" height="85" rx="16" fill="#111827" stroke="#1f2937" strokeWidth="1"/>
                                    <circle cx="35" cy="42" r="18" fill="#ef4444" opacity="0.15"/>
                                    <text fill="#ef4444" fontSize="14" fontWeight="900" x="29" y="47" fontFamily="sans-serif">⚠</text>
                                    <text fill="#ffffff" fontSize="12" fontWeight="800" x="70" y="35" fontFamily="sans-serif">Broken Streetlight Corridor</text>
                                    <text fill="#6b7280" fontSize="10" x="70" y="52" fontFamily="sans-serif">Rajaji Sector B • Awaiting parts</text>
                                    <rect x="260" y="28" width="80" height="24" rx="8" fill="#eab308" opacity="0.15"/>
                                    <text fill="#eab308" fontSize="9" fontWeight="900" x="270" y="43" fontFamily="sans-serif">DISPATCHED</text>
                                  </g>
                                  <g transform="translate(0, 212)">
                                    <rect width="356" height="85" rx="16" fill="#111827" stroke="#1f2937" strokeWidth="1"/>
                                    <circle cx="35" cy="42" r="18" fill="#2dd4bf" opacity="0.15"/>
                                    <text fill="#2dd4bf" fontSize="14" fontWeight="900" x="29" y="47" fontFamily="sans-serif">✉</text>
                                    <text fill="#ffffff" fontSize="12" fontWeight="800" x="70" y="35" fontFamily="sans-serif">Clogged Storm Drain</text>
                                    <text fill="#6b7280" fontSize="10" x="70" y="52" fontFamily="sans-serif">Vasanth Main • 15 micro-tasks</text>
                                    <rect x="260" y="28" width="80" height="24" rx="8" fill="#3b82f6" opacity="0.15"/>
                                    <text fill="#3b82f6" fontSize="9" fontWeight="900" x="274" y="43" fontFamily="sans-serif">VERIFIED</text>
                                  </g>
                                </g>
                              </g>
                            </svg>
                          </div>

                          <button
                            onClick={() => downloadSvgAsPng('ss-dash-visual', 'screenshot_dashboard.png', 800, 1200)}
                            className="w-full py-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:text-white text-slate-300 rounded-xl text-[10px] font-black uppercase tracking-wider transition active:scale-95"
                          >
                            Download Screenshot 1
                          </button>
                        </div>

                        {/* SCREENSHOT 2: AI SCANNER */}
                        <div className="bg-slate-900/40 border border-slate-800/60 p-4 rounded-2xl flex flex-col items-center space-y-4">
                          <span className="text-[10px] bg-indigo-500/10 text-indigo-400 font-extrabold tracking-widest px-2.5 py-1 rounded-full border border-indigo-500/20 uppercase">
                            Screenshot 2: AI Vision Scanner
                          </span>
                          
                          <div className="w-full bg-slate-950 rounded-2xl border border-slate-850 p-2 overflow-hidden aspect-[800/1200] max-w-[280px]">
                            <svg id="ss-vision-visual" viewBox="0 0 800 1200" className="w-full bg-slate-950">
                              <rect width="800" height="1200" fill="#080c14"/>
                              <circle cx="400" cy="200" r="300" fill="#14b8a6" opacity="0.06" filter="blur(60px)"/>
                              <circle cx="400" cy="1000" r="250" fill="#6366f1" opacity="0.06" filter="blur(60px)"/>

                              <text x="400" y="110" textAnchor="middle" fill="#ffffff" fontSize="38" fontWeight="900" fontFamily="sans-serif" letterSpacing="-1">AI HYPERLOCAL CAMERA</text>
                              <text x="400" y="152" textAnchor="middle" fill="#94a3b8" fontSize="16" fontWeight="600" fontFamily="sans-serif">Analyze public defects instantly</text>

                              <g transform="translate(180, 210)">
                                <rect width="440" height="880" rx="40" fill="#1e293b" stroke="#334155" strokeWidth="8"/>
                                <rect x="160" y="15" width="120" height="24" rx="12" fill="#0f172a"/>
                                <rect x="12" y="48" width="416" height="814" rx="28" fill="#090d16"/>
                                
                                {/* Camera UI */}
                                <rect x="12" y="48" width="416" height="520" rx="0" fill="#111827" />
                                
                                {/* Scanning Reticle */}
                                <rect x="90" y="180" width="260" height="230" rx="16" fill="none" stroke="#2dd4bf" strokeWidth="4" strokeDasharray="30 15"/>
                                <line x1="80" y1="295" x2="360" y2="295" stroke="#2dd4bf" strokeWidth="2" opacity="0.8" />
                                
                                {/* Pothole Graphic */}
                                <path d="M140,320 C180,260 280,270 320,330 C290,360 220,380 140,320 Z" fill="#374151" stroke="#1f2937" strokeWidth="4"/>
                                <path d="M170,330 C200,300 250,300 280,330 C250,345 210,345 170,330 Z" fill="#1f2937"/>
                                
                                {/* AI Scanning Box */}
                                <g transform="translate(40, 480)">
                                  <rect width="336" height="180" rx="16" fill="#030712" stroke="#2dd4bf" strokeWidth="2"/>
                                  
                                  <circle cx="30" cy="30" r="12" fill="#2dd4bf" opacity="0.15"/>
                                  <text fill="#2dd4bf" fontSize="12" fontWeight="900" x="48" y="34" fontFamily="sans-serif">GEMINI VISION SCANNER</text>
                                  
                                  <text fill="#ffffff" fontSize="11" fontWeight="800" x="20" y="65" fontFamily="sans-serif">OBJECT: Municipal Road defect (Pothole)</text>
                                  <text fill="#ffffff" fontSize="11" fontWeight="800" x="20" y="85" fontFamily="sans-serif">CONFIDENCE INDEX: 94.2% Verified</text>
                                  <text fill="#2dd4bf" fontSize="11" fontWeight="800" x="20" y="105" fontFamily="sans-serif">DEPT MAPPING: Public Works (Roads Division)</text>
                                  
                                  <rect x="20" y="125" width="296" height="36" rx="8" fill="#1f2937" />
                                  <text fill="#94a3b8" fontSize="10" fontWeight="700" x="35" y="146" fontFamily="sans-serif">ESTIMATED REPAIR COST: ₹12,500 ($150)</text>
                                </g>
                                
                                {/* Camera Trigger footer */}
                                <g transform="translate(12, 690)">
                                  <rect width="416" height="100" fill="#020617" />
                                  <circle cx="208" cy="45" r="30" fill="none" stroke="#2dd4bf" strokeWidth="4" />
                                  <circle cx="208" cy="45" r="23" fill="#ffffff" />
                                </g>
                              </g>
                            </svg>
                          </div>

                          <button
                            onClick={() => downloadSvgAsPng('ss-vision-visual', 'screenshot_ai_scanner.png', 800, 1200)}
                            className="w-full py-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:text-white text-slate-300 rounded-xl text-[10px] font-black uppercase tracking-wider transition active:scale-95"
                          >
                            Download Screenshot 2
                          </button>
                        </div>

                      </div>
                    </div>

                  </div>
                </div>
              )}

              {/* SECTION 3: STEP-BY-STEP SIGNED AAB PIPELINE */}
              {playTab === 'bundle' && (
                <div className="space-y-6">

                  {/* Capacitor Live Native Bridge Simulator */}
                  <div className="bg-gradient-to-br from-slate-950 via-indigo-950/20 to-slate-950 p-5 rounded-2xl border border-indigo-500/20 space-y-4 shadow-xl">
                    <div className="flex justify-between items-center pb-3 border-b border-slate-800">
                      <div className="flex items-center gap-2">
                        <Smartphone className="w-5 h-5 text-indigo-400 animate-pulse" />
                        <div>
                          <h4 className="text-xs font-black text-slate-100 uppercase tracking-widest">Capacitor Live Native Bridge Tester</h4>
                          <span className="text-[9px] text-slate-500 font-bold block uppercase">Hardware & Native SDK API Simulation Console</span>
                        </div>
                      </div>
                      <span className="text-[9px] bg-indigo-500/10 text-indigo-300 border border-indigo-500/30 px-2 py-0.5 rounded font-black uppercase">Active Bridge</span>
                    </div>

                    {/* Simulating Geolocation & Camera Viewfinders */}
                    {isSimulatingCamera && (
                      <div className="bg-black rounded-xl border-2 border-dashed border-rose-500/40 p-4 text-center space-y-3 relative overflow-hidden">
                        <div className="absolute inset-0 bg-radial-gradient from-transparent to-black/60 pointer-events-none" />
                        <span className="absolute top-2 left-2 text-[8px] bg-rose-500 text-white font-bold px-1.5 py-0.5 rounded uppercase">Camera Viewfinder SDK</span>
                        
                        {/* Shutter box overlay */}
                        <div className="w-full h-40 bg-slate-900 rounded-lg flex items-center justify-center border border-slate-800 relative overflow-hidden">
                          {/* Crosshairs */}
                          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                            <div className="w-10 h-10 border border-dashed border-rose-500/30 rounded-full" />
                            <div className="w-1.5 h-1.5 bg-rose-500/60 rounded-full" />
                          </div>
                          <span className="text-3xl animate-bounce">📸</span>
                        </div>

                        <div className="flex justify-center gap-2">
                          <button
                            onClick={() => {
                              setCapacitorConsoleLogs(prev => [
                                ...prev,
                                `[Capacitor/Camera] invoking shutter trigger...`,
                                `[Capacitor/Camera] saving mock_pothole_proof_release.jpg to cache/ [1.4 MB]`,
                                `[Capacitor/Camera] returning filesystem asset URI... SUCCESS`
                              ]);
                              setIsSimulatingCamera(false);
                            }}
                            className="bg-rose-600 hover:bg-rose-500 text-white font-bold text-[10px] px-3.5 py-1.5 rounded-lg transition cursor-pointer"
                          >
                            Capture Frame
                          </button>
                          <button
                            onClick={() => {
                              setCapacitorConsoleLogs(prev => [...prev, `[Capacitor/Camera] capture session cancelled by user.`]);
                              setIsSimulatingCamera(false);
                            }}
                            className="bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-[10px] px-3.5 py-1.5 rounded-lg transition cursor-pointer"
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Device Status & Metadata Grid */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-[10px] bg-slate-950 p-3.5 rounded-xl border border-slate-900 font-mono">
                      <div>
                        <span className="text-slate-500 uppercase block font-bold font-sans">Target Device</span>
                        <span className="text-indigo-300 font-bold">Pixel 8 Pro (API 34)</span>
                      </div>
                      <div>
                        <span className="text-slate-500 uppercase block font-bold font-sans">Platform Engine</span>
                        <span className="text-slate-300">Capacitor v6.1.0</span>
                      </div>
                      <div>
                        <span className="text-slate-500 uppercase block font-bold font-sans">Database Engine</span>
                        <span className="text-slate-300">SQLite (Offline Cache)</span>
                      </div>
                      <div>
                        <span className="text-slate-500 uppercase block font-bold font-sans">Allocated Storage</span>
                        <span className="text-teal-400 font-bold">{filesystemSpace}</span>
                      </div>
                    </div>

                    {/* Interactive Action Buttons for SDK triggers */}
                    <div className="flex flex-wrap gap-2.5">
                      <button
                        onClick={() => {
                          setCapacitorConsoleLogs(prev => [
                            ...prev,
                            `[Capacitor/Camera] invoker: capturePhoto()`,
                            `[Capacitor/Camera] requesting camera permissions... SUCCESS`,
                            `[Capacitor/Camera] mounting camera view layers...`
                          ]);
                          setIsSimulatingCamera(true);
                        }}
                        className="bg-slate-900 hover:bg-slate-850 border border-slate-800 text-slate-200 text-[10px] font-bold px-3 py-2 rounded-lg transition flex items-center gap-1.5 cursor-pointer"
                      >
                        🎥 Trigger Native Camera SDK
                      </button>
                      <button
                        onClick={() => {
                          const lat = (12.9716 + (Math.random() - 0.5) * 0.01).toFixed(6);
                          const lng = (77.5946 + (Math.random() - 0.5) * 0.01).toFixed(6);
                          setCapacitorConsoleLogs(prev => [
                            ...prev,
                            `[Capacitor/Geolocation] invoker: getCurrentPosition()`,
                            `[Capacitor/Geolocation] GPS receiver calibrated: Lat ${lat}, Lng ${lng}`,
                            `[Capacitor/Geolocation] coordinate confidence lock: 98.4% (3.2m accuracy)`
                          ]);
                          setSimulatedLocation({ lat, lng, accuracy: "3.2m" });
                        }}
                        className="bg-slate-900 hover:bg-slate-850 border border-slate-800 text-slate-200 text-[10px] font-bold px-3 py-2 rounded-lg transition flex items-center gap-1.5 cursor-pointer"
                      >
                        📍 Query Native GPS Geolocation
                      </button>
                      <button
                        onClick={() => {
                          setCapacitorConsoleLogs(prev => [
                            ...prev,
                            `[Capacitor/Device] reading hardware telemetry...`,
                            `[Capacitor/Device] Battery: 84% (USB_CHARGING), Temp: 34.2°C, Cores: 8 (Tensor G3)`
                          ]);
                        }}
                        className="bg-slate-900 hover:bg-slate-850 border border-slate-800 text-slate-200 text-[10px] font-bold px-3 py-2 rounded-lg transition flex items-center gap-1.5 cursor-pointer"
                      >
                        ⚡ Query Hardware Metrics
                      </button>
                      <button
                        onClick={() => {
                          setCapacitorConsoleLogs([`[System] Capacitor native debug logs buffer cleared.`]);
                          setSimulatedLocation(null);
                        }}
                        className="bg-slate-900/50 hover:bg-slate-850 text-slate-400 text-[10px] font-semibold px-3 py-2 rounded-lg transition ml-auto cursor-pointer"
                      >
                        Clear Terminal
                      </button>
                    </div>

                    {/* Simulated Location Lock Banner */}
                    {simulatedLocation && (
                      <div className="bg-indigo-950/20 border border-indigo-500/20 p-2.5 rounded-lg text-[10px] text-slate-300 flex items-center justify-between">
                        <span className="font-bold text-indigo-400 flex items-center gap-1">📍 LATENCY-LOCK COORDINATES:</span>
                        <span className="font-mono bg-slate-950 px-2 py-0.5 rounded text-teal-400 font-bold border border-slate-900">
                          Lat: {simulatedLocation.lat}, Lng: {simulatedLocation.lng} (Accuracy: {simulatedLocation.accuracy})
                        </span>
                      </div>
                    )}

                    {/* Live Scrolling Terminal Window */}
                    <div className="space-y-1">
                      <span className="text-[9px] text-slate-500 font-bold block uppercase tracking-wider">Bridge Activity Terminal Stream:</span>
                      <div className="bg-slate-950 p-3 rounded-lg border border-slate-900 font-mono text-[9px] text-indigo-400 h-28 overflow-y-auto space-y-1">
                        {capacitorConsoleLogs.map((logLine, idx) => (
                          <div key={idx} className="flex gap-2">
                            <span className="text-slate-600">[{new Date().toLocaleTimeString()}]</span>
                            <span className={logLine.includes('SUCCESS') || logLine.includes('calibrated') ? 'text-teal-400 font-bold' : logLine.includes('Trigger') || logLine.includes('mounting') ? 'text-indigo-300' : 'text-slate-300'}>
                              {logLine}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 text-xs text-slate-400 leading-relaxed">
                    This step-by-step interactive workflow guides you from wrapping this React application in <strong>Capacitor</strong> to compiling and signing a secure <strong>Android App Bundle (.aab)</strong> ready for deployment on the Google Play Store.
                  </div>

                  <div className="space-y-4">
                    
                    {/* STEP 1 */}
                    <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-3">
                      <div className="flex items-center gap-2">
                        <span className="flex items-center justify-center w-5 h-5 rounded-full bg-indigo-500/15 text-indigo-400 font-bold text-xs">1</span>
                        <h4 className="text-xs font-black text-slate-200 uppercase tracking-wider">Scaffold the Native Android Project</h4>
                      </div>
                      <p className="text-[11px] text-slate-400 leading-relaxed pl-7">
                        Initialize Capacitor and generate the Android directory template mapped to your project configuration:
                      </p>
                      <div className="pl-7">
                        <div className="bg-slate-950 p-3 rounded-lg border border-slate-850 font-mono text-[10px] text-teal-400 flex justify-between items-center">
                          <span>npx cap add android</span>
                          <button
                            onClick={() => handleCopyToClipboard('npx cap add android', 'step1cmd')}
                            className="p-1 hover:bg-slate-900 rounded text-slate-500 hover:text-slate-200 transition"
                          >
                            {copiedText === 'step1cmd' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* STEP 2 */}
                    <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-3">
                      <div className="flex items-center gap-2">
                        <span className="flex items-center justify-center w-5 h-5 rounded-full bg-indigo-500/15 text-indigo-400 font-bold text-xs">2</span>
                        <h4 className="text-xs font-black text-slate-200 uppercase tracking-wider">Synchronize & Compile Web Assets</h4>
                      </div>
                      <p className="text-[11px] text-slate-400 leading-relaxed pl-7">
                        Build your React assets and synchronize them directly into your Android native project:
                      </p>
                      <div className="pl-7">
                        <div className="bg-slate-950 p-3 rounded-lg border border-slate-850 font-mono text-[10px] text-teal-400 flex justify-between items-center">
                          <span>npm run build:android</span>
                          <button
                            onClick={() => handleCopyToClipboard('npm run build:android', 'step2cmd')}
                            className="p-1 hover:bg-slate-900 rounded text-slate-500 hover:text-slate-200 transition"
                          >
                            {copiedText === 'step2cmd' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                        <p className="text-[9px] text-slate-500 mt-1">
                          This runs a production Vite compile and moves all bundles securely to the Capacitor native container assets.
                        </p>
                      </div>
                    </div>

                    {/* STEP 3 */}
                    <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-3">
                      <div className="flex items-center gap-2">
                        <span className="flex items-center justify-center w-5 h-5 rounded-full bg-indigo-500/15 text-indigo-400 font-bold text-xs">3</span>
                        <h4 className="text-xs font-black text-slate-200 uppercase tracking-wider">Generate a Secure Release Keystore File</h4>
                      </div>
                      <p className="text-[11px] text-slate-400 leading-relaxed pl-7">
                        Use the JDK <code>keytool</code> tool to create a production certificate key to digitally sign your App Bundle:
                      </p>
                      <div className="pl-7">
                        <div className="bg-slate-950 p-3 rounded-lg border border-slate-850 font-mono text-[10px] text-teal-400 flex justify-between items-center overflow-x-auto">
                          <span className="whitespace-nowrap">keytool -genkey -v -keystore release-keystore.jks -keyalg RSA -keysize 2048 -validity 10000 -alias atlasone-key</span>
                          <button
                            onClick={() => handleCopyToClipboard('keytool -genkey -v -keystore release-keystore.jks -keyalg RSA -keysize 2048 -validity 10000 -alias atlasone-key', 'step3cmd')}
                            className="p-1 hover:bg-slate-900 rounded text-slate-500 hover:text-slate-200 transition ml-4 flex-shrink-0"
                          >
                            {copiedText === 'step3cmd' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                        <p className="text-[9px] text-slate-500 mt-1">
                          Keep this keystore file and its password extremely safe. Google Play requires the same certificate for all future app updates.
                        </p>
                      </div>
                    </div>

                    {/* STEP 4 */}
                    <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-3">
                      <div className="flex items-center gap-2">
                        <span className="flex items-center justify-center w-5 h-5 rounded-full bg-indigo-500/15 text-indigo-400 font-bold text-xs">4</span>
                        <h4 className="text-xs font-black text-slate-200 uppercase tracking-wider">Configure Signing & Build Signed .aab in Android Studio</h4>
                      </div>
                      <p className="text-[11px] text-slate-400 leading-relaxed pl-7">
                        Launch your project in Android Studio to finalize compilation and sign the bundle:
                      </p>
                      <div className="pl-7 space-y-2">
                        <div className="bg-slate-950 p-3 rounded-lg border border-slate-850 font-mono text-[10px] text-teal-400 flex justify-between items-center">
                          <span>npx cap open android</span>
                          <button
                            onClick={() => handleCopyToClipboard('npx cap open android', 'step4cmd')}
                            className="p-1 hover:bg-slate-900 rounded text-slate-500 hover:text-slate-200 transition"
                          >
                            {copiedText === 'step4cmd' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                        <ul className="list-disc pl-5 space-y-1.5 text-[11px] text-slate-400">
                          <li>Inside Android Studio, wait for Gradle sync to complete successfully.</li>
                          <li>Go to <strong>Build &gt; Generate Signed Bundle / APK...</strong></li>
                          <li>Select <strong>Android App Bundle (.aab)</strong> and click Next.</li>
                          <li>Choose your <code>release-keystore.jks</code> file, enter your password, and specify alias <code>atlasone-key</code>.</li>
                          <li>Set destination folder, choose build variant <strong>release</strong>, and click <strong>Finish</strong>.</li>
                          <li>Your production-ready <code>app-release.aab</code> will be saved inside the <code>android/app/release</code> folder!</li>
                        </ul>
                      </div>
                    </div>

                  </div>
                </div>
              )}

            </div>
          )}
        </section>
      </main>

      {/* 4. DETAILS / MODAL OVERLAY */}
      {selectedIssue && (
        <div className="fixed inset-0 bg-slate-950/80 flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-2xl w-full p-6 space-y-6 shadow-2xl relative my-8">
            
            {/* Close */}
            <button
              onClick={() => setSelectedIssue(null)}
              className="absolute top-4 right-4 bg-slate-800 text-slate-400 hover:text-white p-2 rounded-full transition"
            >
              ✕
            </button>

            {/* Banner */}
            <div className="relative h-52 bg-slate-950 rounded-2xl overflow-hidden">
              <img src={selectedIssue.imageUrl} className="w-full h-full object-cover" alt="" />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent"></div>
              <span className="absolute bottom-4 left-4 text-xs font-bold bg-slate-900/80 text-teal-400 px-3 py-1 rounded-full border border-teal-500/30 uppercase">
                {selectedIssue.category}
              </span>
            </div>

            {/* Title */}
            <div className="space-y-2">
              <h3 className="text-xl font-black text-slate-100 leading-snug">{selectedIssue.title}</h3>
              <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400">
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-teal-400" /> {selectedIssue.location.address}
                </span>
                <span>• Status: <strong className="text-teal-400 uppercase">{selectedIssue.status}</strong></span>
              </div>
            </div>

            {/* Desc */}
            <p className="text-slate-300 text-xs leading-relaxed">{selectedIssue.description}</p>

            {/* Metadata Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 bg-slate-950 p-4 rounded-xl border border-slate-800/80 text-xs">
              <div>
                <span className="text-slate-500 text-[10px] block uppercase font-bold">Assigned Dept</span>
                <span className="text-slate-200 font-medium block mt-1">{selectedIssue.suggestedDepartment}</span>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] block uppercase font-bold">Budget Cost</span>
                <span className="text-slate-200 font-bold block mt-1">{selectedIssue.estimatedRepairCost}</span>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] block uppercase font-bold">Estimated Work</span>
                <span className="text-slate-200 font-medium block mt-1">{selectedIssue.estimatedRepairTime}</span>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] block uppercase font-bold">Priority Status</span>
                <span className="text-rose-400 font-bold block mt-1 uppercase">{selectedIssue.recommendedPriority}</span>
              </div>
            </div>

            {/* CPGRAMS Central Government Portal Dispatch Bridging Hub */}
            {selectedIssue.status === 'reported' && (
              <div className="bg-slate-950 p-4 rounded-xl border border-teal-900/40 space-y-3.5 shadow-xl">
                <div className="flex items-center justify-between pb-1.5 border-b border-slate-900">
                  <div className="flex items-center gap-1.5">
                    <Globe className="w-4 h-4 text-teal-400 animate-pulse" />
                    <p className="text-xs font-black text-slate-200 uppercase tracking-wider">CPGRAMS Central Dispatch Bridge</p>
                  </div>
                  <span className="text-[9px] bg-teal-500/10 text-teal-300 border border-teal-500/20 px-2 py-0.5 rounded font-black uppercase">NIC Gateway</span>
                </div>

                {selectedIssue.cpgramsDispatch ? (
                  /* Already Dispatched Receipt */
                  <div className="space-y-3">
                    <div className="p-3 bg-teal-950/20 border border-teal-500/20 rounded-lg text-[11px] text-slate-300 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-teal-400 font-extrabold flex items-center gap-1">
                          <CheckCircle className="w-4 h-4 text-teal-400" /> OFFICIAL PG PORTAL RECEIPT
                        </span>
                        <span className="text-slate-500 text-[10px]">{new Date(selectedIssue.cpgramsDispatch.dispatchedAt).toLocaleString()}</span>
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-[10px] bg-slate-950/60 p-2 rounded border border-slate-900">
                        <div>
                          <span className="text-slate-500 uppercase block font-bold">Ticket Registration</span>
                          <span className="text-teal-300 font-black font-mono">{selectedIssue.cpgramsDispatch.ticketNumber}</span>
                        </div>
                        <div>
                          <span className="text-slate-500 uppercase block font-bold">Designated Nodal Officer</span>
                          <span className="text-slate-200 font-semibold">{selectedIssue.cpgramsDispatch.nodalOfficer}</span>
                        </div>
                        <div className="col-span-2 border-t border-slate-900 pt-1 mt-1 font-mono">
                          <span className="text-slate-500 uppercase block font-bold font-sans">Digital Signature Token</span>
                          <span className="text-slate-400 block text-[8px] truncate">{selectedIssue.cpgramsDispatch.digitalSignature}</span>
                        </div>
                      </div>
                      <p className="text-[10px] text-slate-400">
                        Grievance successfully cataloged in standard <strong>GrievanceSchemaV4.xsd</strong> format and transferred to the <strong>{selectedIssue.cpgramsDispatch.assignedMinistry}</strong>.
                      </p>
                    </div>

                    {/* Collapsible raw dispatch payload */}
                    <div className="space-y-1">
                      <details className="group border border-slate-800 rounded-lg overflow-hidden bg-slate-950">
                        <summary className="flex items-center justify-between text-[10px] font-bold text-slate-400 p-2 cursor-pointer select-none hover:bg-slate-900 transition">
                          <span>Inspect Signed NIC-JSON Payload</span>
                          <span className="text-teal-400 group-open:rotate-180 transition-transform duration-200">▼</span>
                        </summary>
                        <div className="p-3 border-t border-slate-900 bg-black font-mono text-[9px] text-teal-300 overflow-x-auto space-y-1 max-h-40">
                          <pre>{JSON.stringify({
                            schema: "https://pgportal.gov.in/schemas/GrievanceSchemaV4.xsd",
                            complainant: {
                              name: userProfile?.displayName || "Citizen Auditor",
                              auth_type: "Atlasone Peer Verified Identity",
                              digital_sig_pub_key: "0x8fa4b7..."
                            },
                            grievance: {
                              category_code: selectedIssue.category.toUpperCase(),
                              title: selectedIssue.title,
                              description: selectedIssue.description,
                              coordinates: selectedIssue.location,
                              verification_hash: selectedIssue.cpgramsDispatch.digitalSignature,
                              evidence_photo: selectedIssue.imageUrl
                            },
                            routing: {
                              ministry_target: selectedIssue.cpgramsDispatch.assignedMinistry,
                              nic_payload_signature: "0x" + selectedIssue.cpgramsDispatch.digitalSignature.slice(-16)
                            }
                          }, null, 2)}</pre>
                        </div>
                      </details>
                    </div>
                  </div>
                ) : (
                  /* Form and Button to execute dispatch */
                  <div className="space-y-3">
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      This neighborhood defect has been audited. If local authorities remain unresponsive, you can execute an automated dispatch directly to the central e-Gov portal under the <strong>National PG Rules</strong>.
                    </p>

                    <div className="space-y-2">
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">Select Target Central Ministry</label>
                      <select
                        value={selectedMinistry}
                        onChange={(e) => setSelectedMinistry(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 text-slate-200 text-xs p-2.5 rounded-lg focus:outline-none focus:border-teal-500"
                      >
                        <option value="Ministry of Road Transport & Highways">Ministry of Road Transport & Highways (MoRTH)</option>
                        <option value="Ministry of Housing & Urban Affairs">Ministry of Housing & Urban Affairs (MoHUA)</option>
                        <option value="Department of Water Resources, River Development & Ganga Rejuvenation">Department of Water Resources & Sanitation</option>
                        <option value="Ministry of Power & Renewable Energy">Ministry of Power & LED Grids</option>
                      </select>
                    </div>

                    {dispatchingGrievanceId === selectedIssue.id ? (
                      /* Live animated routing steps console */
                      <div className="bg-slate-950 p-3 rounded-lg border border-teal-900/60 font-mono text-[9px] text-teal-400 space-y-1">
                        {dispatchStepsLog.map((logLine, idx) => (
                          <p key={idx} className="animate-fade-in">{logLine}</p>
                        ))}
                      </div>
                    ) : (
                      <button
                        onClick={() => handleExecuteCpgramsDispatch(selectedIssue.id)}
                        className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-400 hover:to-emerald-400 text-slate-950 font-black text-xs py-2.5 rounded-lg transition cursor-pointer"
                      >
                        <Send className="w-3.5 h-3.5" /> Execute Central CPGRAMS Portal Dispatch
                      </button>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* Dynamic Controls based on roles */}
            {selectedIssue.notifiedHead && (
              <div className="p-3.5 bg-indigo-500/15 border border-indigo-500/30 rounded-xl text-[11px] text-slate-300 space-y-1">
                <p className="font-extrabold text-indigo-400 flex items-center gap-1">
                  <CheckCircle className="w-4 h-4 text-indigo-400 animate-pulse" /> Formally Notified & Escalated
                </p>
                <p className="text-slate-200">
                  This grievance was officially forwarded to the personal desk of <strong>{selectedIssue.notifiedHead.name}</strong> ({selectedIssue.notifiedHead.role} of {selectedIssue.notifiedHead.mcName}) on {new Date(selectedIssue.notifiedHead.notifiedAt).toLocaleString()}.
                </p>
              </div>
            )}

            {selectedIssue.status === 'reported' && !selectedIssue.notifiedHead && (
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <p className="text-xs font-bold text-slate-300 uppercase tracking-wider">Local Government Alert Desk</p>
                  <span className="text-[9px] bg-indigo-500/10 text-indigo-400 border border-indigo-500/30 px-2 py-0.5 rounded font-bold uppercase">GovConnect</span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Has this issue been ignored? You can officially dispatch and forward this report directly to the personal desk of the <strong>{MUNICIPAL_DATA[selectedCity]?.headTitle}</strong> (<strong>{MUNICIPAL_DATA[selectedCity]?.headName}</strong>).
                </p>
                <button
                  onClick={() => handleNotifyHead(selectedIssue.id)}
                  className="w-full flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs py-2 rounded-lg transition"
                >
                  <Send className="w-3.5 h-3.5" /> Forward Grievance to MC Commissioner
                </button>
              </div>
            )}

            {currentRole === 'officer' && selectedIssue.status === 'reported' && (
              <div className="bg-slate-950 p-4 rounded-xl border border-indigo-900/40 space-y-3">
                <p className="text-xs font-bold text-indigo-400 uppercase tracking-wider">Officer Assign Station</p>
                <div className="flex gap-2">
                  <select
                    id="select-worker"
                    value={assignedWorkerId}
                    onChange={(e) => setAssignedWorkerId(e.target.value)}
                    className="flex-1 bg-slate-900 text-slate-200 text-xs p-2.5 rounded-lg border border-slate-800 focus:outline-none"
                  >
                    <option value="worker_sam">Sam Bahadur (Road & maintenance specialist)</option>
                  </select>
                  <button
                    onClick={() => assignIssue(selectedIssue.id, assignedWorkerId)}
                    className="bg-indigo-500 hover:bg-indigo-400 text-slate-950 font-bold text-xs px-4 py-2 rounded-lg transition"
                  >
                    Assign Work Orders
                  </button>
                </div>
              </div>
            )}

            {currentRole === 'worker' && selectedIssue.assignment?.workerId === 'worker_sam' && selectedIssue.status === 'assigned' && (
              <div className="bg-slate-950 p-4 rounded-xl border border-teal-500/20 space-y-3">
                <p className="text-xs font-bold text-teal-400 uppercase tracking-wider">Field Specialist Console</p>
                <button
                  onClick={() => submitResolution(selectedIssue.id, 'in_progress')}
                  className="w-full bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs py-2.5 rounded-lg transition"
                >
                  ✓ Mark Work In-Progress (At Site)
                </button>
              </div>
            )}

            {currentRole === 'worker' && selectedIssue.assignment?.workerId === 'worker_sam' && selectedIssue.status === 'in_progress' && (
              <div className="bg-slate-950 p-4 rounded-xl border border-teal-500/20 space-y-4">
                <p className="text-xs font-bold text-teal-400 uppercase tracking-wider">Field Specialist Resolution Console</p>
                
                {/* Image Upload Input */}
                <div className="space-y-2">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Resolution Proof Photo URL</label>
                  <input
                    type="text"
                    value={resolutionPhotoUrl}
                    onChange={(e) => setResolutionPhotoUrl(e.target.value)}
                    placeholder="Enter image URL or select a preset below..."
                    className="w-full bg-slate-900 border border-slate-800 focus:border-teal-500 rounded-lg py-2 px-3 text-xs text-slate-100 placeholder-slate-600 outline-none transition"
                  />
                  
                  {/* Preset Photos */}
                  <div className="space-y-1">
                    <span className="text-[9px] text-slate-500 font-bold block uppercase">Or Select Real Resolution Preset:</span>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => setResolutionPhotoUrl('https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=600&q=80')}
                        className={`text-[9px] bg-slate-900 border border-slate-800 hover:border-teal-500 text-slate-300 py-1.5 px-2 rounded-lg truncate text-left ${resolutionPhotoUrl.includes('1513694203232') ? 'border-teal-500 bg-teal-950/20' : ''}`}
                      >
                        🛣️ Asphalt Pavement
                      </button>
                      <button
                        type="button"
                        onClick={() => setResolutionPhotoUrl('https://images.unsplash.com/photo-1618477388954-7852f32655ec?auto=format&fit=crop&w=600&q=80')}
                        className={`text-[9px] bg-slate-900 border border-slate-800 hover:border-teal-500 text-slate-300 py-1.5 px-2 rounded-lg truncate text-left ${resolutionPhotoUrl.includes('1618477388954') ? 'border-teal-500 bg-teal-950/20' : ''}`}
                      >
                        🧹 Cleared Street Garbage
                      </button>
                      <button
                        type="button"
                        onClick={() => setResolutionPhotoUrl('https://images.unsplash.com/photo-1517059224940-d4af9eec41b7?auto=format&fit=crop&w=600&q=80')}
                        className={`text-[9px] bg-slate-900 border border-slate-800 hover:border-teal-500 text-slate-300 py-1.5 px-2 rounded-lg truncate text-left ${resolutionPhotoUrl.includes('1517059224940') ? 'border-teal-500 bg-teal-950/20' : ''}`}
                      >
                        💡 Repaired LED Streetlight
                      </button>
                      <button
                        type="button"
                        onClick={() => setResolutionPhotoUrl('https://images.unsplash.com/photo-1508873696983-2df519f0397e?auto=format&fit=crop&w=600&q=80')}
                        className={`text-[9px] bg-slate-900 border border-slate-800 hover:border-teal-500 text-slate-300 py-1.5 px-2 rounded-lg truncate text-left ${resolutionPhotoUrl.includes('1508873696983') ? 'border-teal-500 bg-teal-950/20' : ''}`}
                      >
                        🔧 Underground Pipeline Seal
                      </button>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Repair Completion Notes</label>
                  <textarea
                    placeholder="Describe resolution details (materials used, steps taken)..."
                    value={completionNotes}
                    onChange={(e) => setCompletionNotes(e.target.value)}
                    className="w-full bg-slate-900 text-slate-100 text-xs p-2.5 rounded-lg border border-slate-800 h-20 outline-none focus:border-teal-500"
                  />
                </div>

                <button
                  onClick={() => submitResolution(selectedIssue.id, 'completed')}
                  className="w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs py-2.5 rounded-lg transition"
                >
                  ✓ Submit Completed repairs to validation queue (+300 XP)
                </button>
              </div>
            )}

            {(selectedIssue.status === 'completed' || selectedIssue.status === 'confirmed') && (
              <div className="bg-slate-950 p-5 rounded-xl border border-teal-500/20 space-y-4">
                <div className="flex justify-between items-center pb-2 border-b border-slate-900">
                  <div>
                    <span className="text-[9px] bg-teal-500/15 text-teal-400 border border-teal-500/30 px-2.5 py-0.5 rounded font-black uppercase">Resolution Proof Live</span>
                    <h4 className="text-sm font-black text-slate-100 mt-1">Municipal Verification Stage</h4>
                  </div>
                  <span className="text-[11px] text-slate-400 font-medium">Citizen Moderated Portal</span>
                </div>

                {/* Show Completed Proof Image */}
                {selectedIssue.assignment?.afterPhoto && (
                  <div className="relative rounded-lg overflow-hidden border border-slate-800 h-44 bg-slate-900">
                    <img src={selectedIssue.assignment.afterPhoto} className="w-full h-full object-cover" alt="Repair proof" />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent" />
                    <span className="absolute bottom-3 left-3 text-[10px] bg-slate-900/80 border border-slate-800 font-bold px-2 py-0.5 rounded text-teal-400">
                      Resolution Proof Photo
                    </span>
                  </div>
                )}

                {selectedIssue.assignment?.completionNotes && (
                  <div className="bg-slate-900/50 p-3.5 rounded-xl border border-slate-800 space-y-1 text-xs">
                    <span className="font-bold text-slate-400 uppercase text-[9px] block">Field worker remarks:</span>
                    <p className="text-slate-300 italic">"{selectedIssue.assignment.completionNotes}"</p>
                  </div>
                )}

                {/* Verification Stats */}
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div className="bg-emerald-500/5 border border-emerald-500/10 p-3 rounded-xl">
                    <span className="text-[9px] text-emerald-400/80 font-black uppercase tracking-wider block">Verified Resolved</span>
                    <span className="text-base font-black text-emerald-400 mt-0.5 block">{selectedIssue.citizenVerificationsCount || 0} Citizens</span>
                  </div>
                  <div className="bg-rose-500/5 border border-rose-500/10 p-3 rounded-xl">
                    <span className="text-[9px] text-rose-400/80 font-black uppercase tracking-wider block">Disputes / Incomplete</span>
                    <span className="text-base font-black text-rose-400 mt-0.5 block">{selectedIssue.citizenDisputesCount || 0} Citizens</span>
                  </div>
                </div>

                {/* Actions for local people */}
                <div className="space-y-3">
                  <p className="text-[11px] text-slate-400 text-center font-medium">
                    Is the problem actually solved? Please verify if the repairs shown in the proof photo match reality on-site.
                  </p>
                  <div className="flex gap-3">
                    <button
                      onClick={() => handleVerifyResolution(selectedIssue.id, 'verify_done')}
                      className="flex-grow flex items-center justify-center gap-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs py-2.5 rounded-xl transition cursor-pointer"
                    >
                      <CheckCircle className="w-4 h-4" /> Yes, It's Fixed! (+40 XP)
                    </button>
                    <button
                      onClick={() => handleVerifyResolution(selectedIssue.id, 'dispute_fake')}
                      className="flex-grow flex items-center justify-center gap-1.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/20 font-black text-xs py-2.5 rounded-xl transition cursor-pointer"
                    >
                      <AlertTriangle className="w-4 h-4" /> No, Fake/Unfinished
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Comments Thread */}
            <div className="space-y-3">
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Comments & Audit Logs ({selectedIssue.comments?.length || 0})</p>
              <div className="space-y-2 max-h-32 overflow-y-auto pr-2">
                {selectedIssue.comments?.map((comment) => (
                  <div key={comment.id} className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 text-[11px] leading-relaxed">
                    <div className="flex justify-between font-bold text-teal-400 mb-0.5">
                      <span>{comment.userName} ({comment.userRole})</span>
                      <span className="text-slate-500 text-[9px]">{new Date(comment.timestamp).toLocaleDateString()}</span>
                    </div>
                    <p className="text-slate-300">{comment.text}</p>
                  </div>
                ))}
                {(!selectedIssue.comments || selectedIssue.comments.length === 0) && (
                  <p className="text-[11px] text-slate-500 italic">No verification comments yet.</p>
                )}
              </div>

              {/* Add Comment */}
              <div className="flex gap-2">
                <input
                  id="comment-input"
                  type="text"
                  placeholder="Add details, feedback, or update on repairs..."
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  className="flex-1 bg-slate-950 text-slate-100 text-xs p-2.5 rounded-xl border border-slate-800 focus:outline-none focus:border-teal-500"
                />
                <button
                  id="post-comment-btn"
                  onClick={handlePostComment}
                  className="bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs px-4 rounded-xl transition font-bold"
                >
                  Comment
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 5. Footer */}
      <footer id="app-footer" className="bg-slate-950 border-t border-slate-800 py-6 text-center text-xs text-slate-500 space-y-1">
        <p>© 2026 Atlasone AI. All Rights Reserved.</p>
        <p>Built with Google Cloud, Firebase, and Gemini 3.5 models to catalyze hyperlocal urban transformation.</p>
      </footer>

      {/* 6. Mobile Bottom Navigation Bar */}
      <div className="fixed bottom-4 left-4 right-4 z-50 lg:hidden flex flex-col items-center select-none">
        {/* Expanded "More" Menu Popover */}
        {mobileMoreOpen && (
          <>
            {/* Backdrop cover to click and close */}
            <div 
              className="fixed inset-0 bg-black/15 backdrop-blur-[1px] z-40" 
              onClick={() => setMobileMoreOpen(false)}
            />
            
            {/* Popover Card */}
            <div className="bg-slate-950 border border-slate-800 rounded-2xl p-2 w-56 shadow-2xl mb-3 space-y-0.5 z-50 animate-in fade-in slide-in-from-bottom-2 duration-150">
              <p className="text-[9px] uppercase tracking-wider font-extrabold text-slate-500 px-3 py-1.5 border-b border-slate-800/40 mb-1">
                More Services
              </p>
              
              <button
                onClick={() => {
                  setActiveTab('verify');
                  setMobileMoreOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition ${
                  activeTab === 'verify' ? 'bg-teal-500/10 text-teal-600' : 'text-slate-300 hover:bg-slate-900'
                }`}
              >
                <span className="flex items-center gap-2">
                  <Users className="w-3.5 h-3.5 text-teal-600" /> Citizen Verifications
                </span>
                <span className="text-[8px] bg-rose-500/10 text-rose-600 px-1.5 py-0.5 rounded font-bold">LIVE</span>
              </button>

              <button
                onClick={() => {
                  setActiveTab('ngo-csr');
                  setMobileMoreOpen(false);
                }}
                className={`w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold transition ${
                  activeTab === 'ngo-csr' ? 'bg-teal-500/10 text-teal-600' : 'text-slate-300 hover:bg-slate-900'
                }`}
              >
                <Heart className="w-3.5 h-3.5 text-rose-500" /> NGO & CSR Portal
              </button>

              <button
                onClick={() => {
                  setActiveTab('playstore');
                  setMobileMoreOpen(false);
                }}
                className={`w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold transition ${
                  activeTab === 'playstore' ? 'bg-indigo-500/10 text-indigo-400 font-bold' : 'text-slate-300 hover:bg-slate-900'
                }`}
              >
                <Smartphone className="w-3.5 h-3.5 text-indigo-400" /> Play Store Dev Kit
              </button>

              <button
                onClick={() => {
                  setActiveTab('emergency');
                  setMobileMoreOpen(false);
                }}
                className={`w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold transition bg-rose-50/80 text-rose-600 hover:bg-rose-100/90 border border-rose-200/40`}
              >
                <AlertTriangle className="w-3.5 h-3.5 text-rose-500 animate-pulse" /> Emergency SOS Panel
              </button>
            </div>
          </>
        )}

        {/* Main Floating Bar */}
        <nav className="w-full bg-slate-950/95 backdrop-blur-lg rounded-2xl border border-slate-800/80 shadow-[0_12px_40px_rgba(0,0,0,0.12)] px-1 py-1.5 flex items-center justify-around z-50">
          {/* Tab 1: Dashboard (Home) */}
          <button
            onClick={() => {
              setActiveTab('home');
              setMobileMoreOpen(false);
            }}
            className={`flex flex-col items-center gap-0.5 py-1 px-2.5 rounded-xl transition ${
              activeTab === 'home' ? 'text-teal-600 font-bold' : 'text-slate-400 hover:text-slate-500'
            }`}
          >
            <Activity className="w-5 h-5" />
            <span className="text-[9px] font-semibold">Dashboard</span>
          </button>

          {/* Tab 2: AI Vision (Scan) */}
          <button
            onClick={() => {
              setActiveTab('report');
              setScanResult(null);
              setSelectedPresetImage('');
              setMobileMoreOpen(false);
            }}
            className={`flex flex-col items-center gap-0.5 py-1 px-2.5 rounded-xl transition relative ${
              activeTab === 'report' ? 'text-teal-600 font-bold' : 'text-slate-400 hover:text-slate-500'
            }`}
          >
            <div className={`p-2 rounded-full absolute -top-5.5 shadow-lg border transition ${
              activeTab === 'report' 
                ? 'bg-gradient-to-tr from-teal-500 to-indigo-600 text-white border-teal-400 scale-105 shadow-teal-500/20' 
                : 'bg-slate-950 text-slate-400 border-slate-800'
            }`}>
              <Camera className="w-5 h-5" />
            </div>
            <span className="text-[9px] font-semibold mt-4.5">Scan</span>
          </button>

          {/* Tab 3: Interactive Map */}
          <button
            onClick={() => {
              setActiveTab('map');
              setMobileMoreOpen(false);
            }}
            className={`flex flex-col items-center gap-0.5 py-1 px-2.5 rounded-xl transition ${
              activeTab === 'map' ? 'text-teal-600 font-bold' : 'text-slate-400 hover:text-slate-500'
            }`}
          >
            <Layers className="w-5 h-5" />
            <span className="text-[9px] font-semibold">Map</span>
          </button>

          {/* Tab 4: Civic Bot */}
          <button
            onClick={() => {
              setActiveTab('chatbot');
              setMobileMoreOpen(false);
            }}
            className={`flex flex-col items-center gap-0.5 py-1 px-2.5 rounded-xl transition ${
              activeTab === 'chatbot' ? 'text-teal-600 font-bold' : 'text-slate-400 hover:text-slate-500'
            }`}
          >
            <Bot className="w-5 h-5" />
            <span className="text-[9px] font-semibold">Civic Bot</span>
          </button>

          {/* Tab 5: More */}
          <button
            onClick={() => setMobileMoreOpen(!mobileMoreOpen)}
            className={`flex flex-col items-center gap-0.5 py-1 px-2.5 rounded-xl transition ${
              mobileMoreOpen ? 'text-teal-600 font-bold' : 'text-slate-400 hover:text-slate-500'
            }`}
          >
            <MoreHorizontal className={`w-5 h-5 transition-transform duration-200 ${mobileMoreOpen ? 'rotate-90' : ''}`} />
            <span className="text-[9px] font-semibold">More</span>
          </button>
        </nav>
      </div>

      {/* 7. Modern Hamburger Navigation Drawer overlay */}
      {menuOpen && (
        <div className="fixed inset-0 z-50 flex justify-end select-none">
          {/* Glass backdrop */}
          <div 
            className="fixed inset-0 bg-slate-950/80 backdrop-blur-xs transition-opacity duration-300 animate-in fade-in cursor-pointer"
            onClick={() => setMenuOpen(false)}
          />
          
          {/* Sliding Drawer Container */}
          <div className="relative w-full max-w-sm h-full bg-slate-950 border-l border-slate-800 shadow-2xl p-6 flex flex-col justify-between overflow-y-auto z-10 transition-transform duration-300 animate-in slide-in-from-right">
            {/* Drawer Header */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-5 mb-6">
              <div className="flex items-center gap-2.5">
                <div className="p-1.5 rounded-xl bg-teal-500/10 border border-teal-500/20">
                  <Activity className="w-5 h-5 text-teal-600 animate-pulse" />
                </div>
                <div>
                  <p className="text-sm font-black text-slate-100 tracking-tight leading-none">AtlasOne Navigation</p>
                  <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider mt-1">AI Urban Management</p>
                </div>
              </div>
              
              <button 
                onClick={() => setMenuOpen(false)}
                className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-slate-100 transition duration-150 cursor-pointer active:scale-95"
                aria-label="Close menu"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Scrollable Navigation Options & Simulator Controls */}
            <div className="flex-1 space-y-6">
              
              {/* Main Navigation Links */}
              <div className="space-y-1.5">
                <p className="text-[10px] uppercase tracking-wider font-extrabold text-slate-500 px-3 mb-2">Main Services</p>
                
                <button
                  onClick={() => {
                    setActiveTab('home');
                    setMenuOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold tracking-wide transition ${
                    activeTab === 'home' 
                      ? 'bg-gradient-to-r from-teal-500/10 to-indigo-500/10 text-teal-400 border border-teal-500/20' 
                      : 'text-slate-300 hover:bg-slate-900 hover:text-slate-100 border border-transparent'
                  }`}
                >
                  <Activity className="w-4 h-4 text-teal-500" />
                  <span>Dashboard Overview</span>
                </button>

                <button
                  onClick={() => {
                    setActiveTab('report');
                    setScanResult(null);
                    setSelectedPresetImage('');
                    setMenuOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold tracking-wide transition ${
                    activeTab === 'report' 
                      ? 'bg-gradient-to-r from-teal-500/10 to-indigo-500/10 text-teal-400 border border-teal-500/20' 
                      : 'text-slate-300 hover:bg-slate-900 hover:text-slate-100 border border-transparent'
                  }`}
                >
                  <Camera className="w-4 h-4 text-teal-500" />
                  <span>Hyperlocal AI Vision Scan</span>
                </button>

                <button
                  onClick={() => {
                    setActiveTab('map');
                    setMenuOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold tracking-wide transition ${
                    activeTab === 'map' 
                      ? 'bg-gradient-to-r from-teal-500/10 to-indigo-500/10 text-teal-400 border border-teal-500/20' 
                      : 'text-slate-300 hover:bg-slate-900 hover:text-slate-100 border border-transparent'
                  }`}
                >
                  <Layers className="w-4 h-4 text-indigo-400" />
                  <span>Live Map & Hotspots</span>
                </button>

                <button
                  onClick={() => {
                    setActiveTab('chatbot');
                    setMenuOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold tracking-wide transition ${
                    activeTab === 'chatbot' 
                      ? 'bg-gradient-to-r from-teal-500/10 to-indigo-500/10 text-teal-400 border border-teal-500/20' 
                      : 'text-slate-300 hover:bg-slate-900 hover:text-slate-100 border border-transparent'
                  }`}
                >
                  <Bot className="w-4 h-4 text-teal-500" />
                  <span>Civic Bot AI Assistant</span>
                </button>

                <button
                  onClick={() => {
                    setActiveTab('verify');
                    setMenuOpen(false);
                  }}
                  className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold tracking-wide transition ${
                    activeTab === 'verify' 
                      ? 'bg-gradient-to-r from-teal-500/10 to-indigo-500/10 text-teal-400 border border-teal-500/20' 
                      : 'text-slate-300 hover:bg-slate-900 hover:text-slate-100 border border-transparent'
                  }`}
                >
                  <span className="flex items-center gap-3">
                    <Users className="w-4 h-4 text-teal-500" />
                    <span>Citizen Verifications</span>
                  </span>
                  <span className="text-[8px] bg-rose-500/15 text-rose-500 px-1.5 py-0.5 rounded font-bold uppercase tracking-wider animate-pulse">Live</span>
                </button>

                <button
                  onClick={() => {
                    setActiveTab('ngo-csr');
                    setMenuOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold tracking-wide transition ${
                    activeTab === 'ngo-csr' 
                      ? 'bg-gradient-to-r from-teal-500/10 to-indigo-500/10 text-teal-400 border border-teal-500/20' 
                      : 'text-slate-300 hover:bg-slate-900 hover:text-slate-100 border border-transparent'
                  }`}
                >
                  <Heart className="w-4 h-4 text-rose-500" />
                  <span>NGO & CSR Alliance Portal</span>
                </button>

                <button
                  onClick={() => {
                    setActiveTab('playstore');
                    setMenuOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold tracking-wide transition ${
                    activeTab === 'playstore' 
                      ? 'bg-gradient-to-r from-indigo-500/10 to-teal-500/10 text-indigo-400 border border-indigo-500/20' 
                      : 'text-slate-300 hover:bg-slate-900 hover:text-slate-100 border border-transparent'
                  }`}
                >
                  <Smartphone className="w-4 h-4 text-indigo-400" />
                  <span>Play Store Dev Kit</span>
                </button>

                <button
                  onClick={() => {
                    setActiveTab('emergency');
                    setMenuOpen(false);
                  }}
                  className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-extrabold tracking-wide transition bg-rose-500/10 text-rose-400 border border-rose-500/20 hover:bg-rose-500/20"
                >
                  <AlertTriangle className="w-4 h-4 text-rose-500 animate-pulse" />
                  <span>Emergency SOS Panel</span>
                </button>
              </div>

              {/* Account Portal controls inside hamburger drawer */}
              <div className="space-y-1.5 pt-4 border-t border-slate-900">
                <p className="text-[10px] uppercase tracking-wider font-extrabold text-slate-500 px-3 mb-2">Account Gateway</p>
                {userProfile ? (
                  <div className="px-3.5 py-3 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-black text-slate-100">{userProfile.displayName}</span>
                      <span className="text-[9px] bg-teal-500/10 text-teal-400 border border-teal-500/30 px-1.5 py-0.5 rounded font-black uppercase">{userProfile.role}</span>
                    </div>
                    <button
                      onClick={() => {
                        handleSignOut();
                        setMenuOpen(false);
                      }}
                      className="w-full py-2 rounded-xl bg-slate-950 hover:bg-slate-900 border border-slate-800 hover:border-slate-750 text-rose-400 hover:text-rose-300 text-[11px] font-bold uppercase tracking-wider transition cursor-pointer hidden"
                    >
                      Sign Out Account
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => {
                      setAuthMode('login');
                      setAuthModalOpen(true);
                      setMenuOpen(false);
                    }}
                    className="w-full flex items-center justify-center gap-2 px-3.5 py-2.5 rounded-xl text-xs font-extrabold uppercase tracking-widest transition bg-gradient-to-r from-teal-500 to-indigo-600 hover:brightness-110 text-white shadow-md cursor-pointer"
                  >
                    <User className="w-4 h-4" />
                    <span>Log In / Sign Up</span>
                  </button>
                )}
              </div>

              {/* Interactive Role Switcher Section (Fully integrated) */}
              <div className="bg-slate-900 p-4 rounded-2xl border border-slate-800 space-y-3">
                <div className="flex items-baseline justify-between">
                  <p className="text-[10px] uppercase tracking-wider font-extrabold text-slate-500">Simulator Control</p>
                  <span className="text-[9px] text-teal-500 font-bold uppercase tracking-wide bg-teal-500/10 px-1.5 py-0.5 rounded">Role: {currentRole}</span>
                </div>
                
                <p className="text-[10px] text-slate-400 leading-relaxed">
                  Dynamically switch user identities to test real-time officer coordination, field worker pipelines, and admin oversight.
                </p>

                <div className="grid grid-cols-2 gap-2 pt-1">
                  {(['citizen', 'worker', 'officer', 'admin', 'ngo', 'csr'] as const).map(role => (
                    <button
                      key={role}
                      id={`drawer-role-btn-${role}`}
                      onClick={() => {
                        setCurrentRole(role);
                      }}
                      className={`text-xs px-3 py-2 rounded-xl capitalize font-bold transition-all border ${
                        currentRole === role
                          ? 'bg-gradient-to-r from-teal-500 to-emerald-500 text-white border-transparent shadow-md scale-[1.02]'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-100 hover:border-slate-700'
                      }`}
                    >
                      {role}
                    </button>
                  ))}
                </div>
              </div>

            </div>

            {/* Bottom Drawer Footer: User Profile Card */}
            {userProfile && (
              <div className="border-t border-slate-800 pt-5 mt-6 bg-slate-900 -mx-6 px-6 -mb-6 pb-6 rounded-b-2xl">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-indigo-500/15 border border-indigo-500/30 flex items-center justify-center text-xs font-black text-indigo-400">
                    {userProfile.level}
                  </div>
                  <div>
                    <p className="text-xs font-black text-slate-100 leading-none">{userProfile.displayName}</p>
                    <span className="text-[9px] text-slate-500 font-bold uppercase tracking-wider mt-1 block">Level {userProfile.level} Officer • {userProfile.xp} XP</span>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2 mt-4">
                  <div className="bg-slate-950 p-2 rounded-xl border border-slate-800 text-center">
                    <p className="text-[9px] text-slate-500 font-bold uppercase">Eco-Coins</p>
                    <p className="text-xs font-black text-amber-500 mt-0.5">{userProfile.coins}</p>
                  </div>
                  <div className="bg-slate-950 p-2 rounded-xl border border-slate-800 text-center">
                    <p className="text-[9px] text-slate-500 font-bold uppercase">Streak</p>
                    <p className="text-xs font-black text-rose-500 mt-0.5">{userProfile.streak} Days</p>
                  </div>
                </div>
              </div>
            )}

          </div>
        </div>
      )}

      {/* 8. Stunning, High-Fidelity Authentication Modal Overlay */}
      {authModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Glass backdrop */}
          <div 
            className="fixed inset-0 bg-slate-950/80 backdrop-blur-md transition-opacity duration-300 animate-in fade-in cursor-pointer"
            onClick={() => setAuthModalOpen(false)}
          />
          
          {/* Form Container */}
          <div className="relative w-full max-w-md bg-slate-950 border border-slate-800 shadow-2xl rounded-3xl p-6 md:p-8 z-10 transition-all duration-300 animate-in zoom-in-95">
            <button 
              onClick={() => setAuthModalOpen(false)}
              className="absolute top-4 right-4 p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-slate-100 transition duration-150 cursor-pointer"
              aria-label="Close modal"
            >
              <X className="w-4 h-4" />
            </button>

            {/* Header */}
            <div className="text-center mb-6">
              <div className="mx-auto w-12 h-12 rounded-2xl bg-teal-500/10 border border-teal-500/25 flex items-center justify-center mb-3">
                {authMode === 'login' ? (
                  <Lock className="w-5 h-5 text-teal-400 animate-pulse" />
                ) : (
                  <Unlock className="w-5 h-5 text-teal-400 animate-pulse" />
                )}
              </div>
              <h3 className="text-lg font-black text-slate-100 tracking-tight">
                {authMode === 'login' ? 'Sign In to AtlasOne AI' : 'Create Civic Profile'}
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                {authMode === 'login' 
                  ? 'Access your saved issues, earn Eco-Coins & badges' 
                  : 'Register to join the civic taskforce and track progress'}
              </p>
            </div>

            {/* Form */}
            <form onSubmit={handleAuthSubmit} className="space-y-4">
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">Email Address</label>
                <div className="relative">
                  <span className="absolute left-3.5 top-3 text-slate-500">@</span>
                  <input
                    type="email"
                    required
                    value={authEmail}
                    onChange={(e) => setAuthEmail(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 focus:border-teal-500 rounded-xl py-2 px-3 pl-8 text-xs font-semibold text-slate-100 placeholder-slate-600 outline-none transition"
                    placeholder="you@example.com"
                  />
                </div>
              </div>

              {authMode === 'register' && (
                <>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">Display Name</label>
                    <input
                      type="text"
                      required
                      value={authDisplayName}
                      onChange={(e) => setAuthDisplayName(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 focus:border-teal-500 rounded-xl py-2 px-3 text-xs font-semibold text-slate-100 placeholder-slate-600 outline-none transition"
                      placeholder="e.g. Meera Nair"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">Your Platform Role</label>
                    <select
                      value={authRoleSelection}
                      onChange={(e: any) => setAuthRoleSelection(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 focus:border-teal-500 rounded-xl py-2 px-3 text-xs font-bold text-slate-100 outline-none transition capitalize"
                    >
                      <option value="citizen">Citizen (Raise & Verify Issues)</option>
                      <option value="worker">Field Worker (Repair Specialist)</option>
                      <option value="officer">Municipal Officer (Review & Assign Tasks)</option>
                      <option value="ngo">NGO Associate (Environmental drives)</option>
                      <option value="csr">CSR Executive (Corporate Sponsorships)</option>
                      <option value="admin">System Administrator</option>
                    </select>
                  </div>

                  {['worker', 'officer'].includes(authRoleSelection) && (
                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">Government Department (Optional)</label>
                      <input
                        type="text"
                        value={authDepartment}
                        onChange={(e) => setAuthDepartment(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 focus:border-teal-500 rounded-xl py-2 px-3 text-xs font-semibold text-slate-100 placeholder-slate-600 outline-none transition"
                        placeholder="e.g. Roads & Public Works Division"
                      />
                    </div>
                  )}
                </>
              )}

              {/* Error and Success states */}
              {authError && (
                <div className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-[11px] font-bold text-center">
                  {authError}
                </div>
              )}

              {authSuccess && (
                <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[11px] font-bold text-center flex items-center justify-center gap-1.5">
                  <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
                  {authSuccess}
                </div>
              )}

              <button
                type="submit"
                id="auth-submit-btn"
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-500 text-white text-xs font-extrabold uppercase tracking-widest hover:brightness-110 active:scale-95 transition-all shadow-md cursor-pointer mt-2"
              >
                {authMode === 'login' ? 'Sign In' : 'Register Profile'}
              </button>
            </form>

            {/* Toggle Modes */}
            <div className="text-center mt-5 pt-4 border-t border-slate-900">
              <button
                onClick={() => {
                  setAuthMode(authMode === 'login' ? 'register' : 'login');
                  setAuthError('');
                  setAuthSuccess('');
                }}
                id="auth-toggle-mode-btn"
                className="text-[11px] text-slate-400 hover:text-teal-400 transition font-bold"
              >
                {authMode === 'login' 
                  ? "Don't have an account yet? Create one" 
                  : "Already have a profile? Sign In"}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}

// Minimalist fallback for arrow icon imports that were not extracted
function ChevronRight() {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-chevron-right">
      <path d="m9 18 6-6-6-6"/>
    </svg>
  );
}

