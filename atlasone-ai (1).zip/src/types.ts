/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type UserRole = 'citizen' | 'worker' | 'officer' | 'admin' | 'ngo' | 'csr';

export type IssueCategory =
  | 'road_crack'
  | 'pothole'
  | 'garbage'
  | 'overflow_drain'
  | 'broken_streetlight'
  | 'illegal_dumping'
  | 'broken_bench'
  | 'tree_fallen'
  | 'electric_pole_damage'
  | 'flood'
  | 'water_leakage'
  | 'broken_sidewalk'
  | 'traffic_signal_damage'
  | 'park_damage'
  | 'school_infrastructure'
  | 'public_toilet'
  | 'graffiti'
  | 'noise_complaint'
  | 'animal_hazard';

export type IssueStatus =
  | 'reported'
  | 'reviewed'
  | 'verified'
  | 'assigned'
  | 'in_progress'
  | 'completed'
  | 'confirmed'
  | 'archived';

export type IssueSeverity = 'low' | 'medium' | 'high' | 'critical';

export interface LocationCoordinates {
  lat: number;
  lng: number;
  address: string;
}

export interface VerificationVote {
  userId: string;
  userName: string;
  vote: 'verified' | 'fixed' | 'fake' | 'evidence_needed';
  comment?: string;
  timestamp: string;
}

export interface Comment {
  id: string;
  userId: string;
  userName: string;
  userRole: UserRole;
  text: string;
  timestamp: string;
}

export interface WorkerAssignment {
  workerId: string;
  workerName: string;
  assignedAt: string;
  beforePhoto?: string;
  afterPhoto?: string;
  completionNotes?: string;
  completedAt?: string;
}

export interface Issue {
  id: string;
  title: string;
  description: string;
  category: IssueCategory;
  status: IssueStatus;
  severity: IssueSeverity;
  confidence: number;
  suggestedDepartment: string;
  estimatedRepairCost: string;
  estimatedRepairTime: string;
  recommendedPriority: 'low' | 'medium' | 'high' | 'immediate';
  location: LocationCoordinates;
  imageUrl?: string;
  videoUrl?: string;
  voiceUrl?: string;
  ocrAssetId?: string;
  reportedBy: string;
  reportedByName: string;
  isAnonymous: boolean;
  createdAt: string;
  updatedAt: string;
  verifications: VerificationVote[];
  comments: Comment[];
  assignment?: WorkerAssignment;
  duplicateOf?: string; // Merged issue ID
  mergedIds?: string[];
  citizenUpvotes: number; // For trending ranking
  citizenUpvoters: string[];
}

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  role: UserRole;
  xp: number;
  coins: number;
  level: number;
  department?: string; // For officers / workers
  badges: {
    id: string;
    title: string;
    description: string;
    unlockedAt: string;
    icon: string;
  }[];
  streak: number;
  lastReportedAt?: string;
}

export interface NGOProject {
  id: string;
  title: string;
  description: string;
  category: string;
  location: string;
  ngoName: string;
  volunteersCount: number;
  volunteersNeeded: number;
  donationsGoal: number;
  donationsCollected: number;
  linkedIssueId?: string;
  imageUrl?: string;
}

export interface CSRCampaign {
  id: string;
  companyName: string;
  projectTitle: string;
  fundingAmount: number;
  supportedSectors: string[];
  impactDescription: string;
  activeIssuesResolved: number;
  logoUrl?: string;
}

export interface PredictiveHotspot {
  id: string;
  category: IssueCategory;
  lat: number;
  lng: number;
  address: string;
  riskScore: number; // 0 to 100
  predictionReason: string;
  historicalIncidentCount: number;
  recommendedPreventativeAction: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: string;
}
