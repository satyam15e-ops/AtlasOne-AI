/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// Seeding standard data matching server.ts exactly
const initialIssues = [
  {
    id: 'issue-1',
    title: 'Dangerously Deep Pothole on School Zone Road',
    description: 'A massive 12-inch deep pothole has formed right outside the Greenfield Secondary School entrance. Multiple school buses have to swerve dangerously into oncoming traffic to avoid it. Extremely hazardous during rainy hours.',
    category: 'pothole',
    status: 'reported',
    severity: 'high',
    confidence: 0.96,
    suggestedDepartment: 'Road & Public Works Division',
    estimatedRepairCost: '₹8,500',
    estimatedRepairTime: '4 Hours',
    recommendedPriority: 'high',
    city: 'bengaluru',
    location: {
      lat: 12.9716,
      lng: 77.5946,
      address: 'Outside Greenfield Secondary School, Sector 4, Indiranagar, Bengaluru',
    },
    imageUrl: 'https://images.unsplash.com/photo-1515162305285-0293e4767cc2?auto=format&fit=crop&w=600&q=80',
    reportedBy: 'citizen_john',
    reportedByName: 'John Doe',
    isAnonymous: false,
    createdAt: new Date(Date.now() - 3600000 * 24 * 3).toISOString(), // 3 days ago
    updatedAt: new Date(Date.now() - 3600000 * 24 * 3).toISOString(),
    verifications: [
      {
        userId: 'citizen_sarah',
        userName: 'Sarah Jenkins',
        vote: 'verified',
        comment: 'Verified! Saw a scooter rider lose balance here yesterday. Needs immediate patching.',
        timestamp: new Date(Date.now() - 3600000 * 24 * 2).toISOString(),
      }
    ],
    comments: [
      {
        id: 'comment-1',
        userId: 'citizen_sarah',
        userName: 'Sarah Jenkins',
        userRole: 'citizen',
        text: 'The municipal office should prioritize this as schools reopen this week!',
        timestamp: new Date(Date.now() - 3600000 * 24 * 2).toISOString(),
      }
    ],
    citizenUpvotes: 18,
    citizenUpvoters: ['citizen_sarah', 'worker_sam'],
  },
  {
    id: 'issue-2',
    title: 'Illegal Garbage Dumping Blocking Sidewalk',
    description: 'A large pile of plastic waste, construction debris, and decomposing household organic garbage has been illegally dumped on the walkway. Pedestrians are forced to walk on the busy main road.',
    category: 'garbage',
    status: 'verified',
    severity: 'medium',
    confidence: 0.94,
    suggestedDepartment: 'Solid Waste Management & Sanitation',
    estimatedRepairCost: '₹3,200',
    estimatedRepairTime: '2 Hours',
    recommendedPriority: 'medium',
    city: 'bengaluru',
    location: {
      lat: 12.9756,
      lng: 77.6012,
      address: 'Opposite Community Park Entrance, 100 Feet Rd, Bengaluru',
    },
    imageUrl: 'https://images.unsplash.com/photo-1611284446314-60a58ac0deb9?auto=format&fit=crop&w=600&q=80',
    reportedBy: 'citizen_john',
    reportedByName: 'John Doe',
    isAnonymous: false,
    createdAt: new Date(Date.now() - 3600000 * 24 * 5).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 24 * 4).toISOString(),
    verifications: [
      {
        userId: 'citizen_rahul',
        userName: 'Rahul Verma',
        vote: 'verified',
        comment: 'Still there. Block is attracting stray dogs and flies.',
        timestamp: new Date(Date.now() - 3600000 * 24 * 4).toISOString(),
      }
    ],
    comments: [],
    citizenUpvotes: 8,
    citizenUpvoters: ['citizen_rahul'],
  },
  {
    id: 'issue-3',
    title: 'Broken Streetlight Pole #EL-402',
    description: 'A damaged streetlight pole with dangling electrical wiring. This entire stretch of the sidewalk remains Pitch-black after 6 PM, creating safety issues for women and elderly residents.',
    category: 'broken_streetlight',
    status: 'assigned',
    severity: 'high',
    confidence: 0.92,
    suggestedDepartment: 'Municipal Electricity Board',
    estimatedRepairCost: '₹12,000',
    estimatedRepairTime: '6 Hours',
    recommendedPriority: 'high',
    city: 'bengaluru',
    location: {
      lat: 12.9692,
      lng: 77.5891,
      address: 'Near Metro Station Pillar 12, Halasuru Road, Bengaluru',
    },
    imageUrl: 'https://images.unsplash.com/photo-1509395062183-67c5ad6faff9?auto=format&fit=crop&w=600&q=80',
    reportedBy: 'citizen_sarah',
    reportedByName: 'Sarah Jenkins',
    isAnonymous: false,
    createdAt: new Date(Date.now() - 3600000 * 24 * 2).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 12).toISOString(),
    verifications: [
      {
        userId: 'officer_meera',
        userName: 'Officer Meera Nair',
        vote: 'verified',
        comment: 'Verified asset ID EL-402. Dispatched to work orders.',
        timestamp: new Date(Date.now() - 3600000 * 20).toISOString(),
      }
    ],
    comments: [
      {
        id: 'comment-2',
        userId: 'officer_meera',
        userName: 'Officer Meera Nair',
        userRole: 'officer',
        text: 'Assigned to Field Specialist Sam. Replacing bulb and tape shielding.',
        timestamp: new Date(Date.now() - 3600000 * 12).toISOString(),
      }
    ],
    assignment: {
      workerId: 'worker_sam',
      workerName: 'Sam Bahadur',
      assignedAt: new Date(Date.now() - 3600000 * 12).toISOString(),
    },
    citizenUpvotes: 12,
    citizenUpvoters: ['citizen_john'],
  },
  {
    id: 'issue-4',
    title: 'Major Underground Water Pipeline Leakage',
    description: 'Clean drinking water has been bursting through a crack on the pavement for the last 48 hours, flooding the local block and wasting thousands of liters of clean water.',
    category: 'water_leakage',
    status: 'in_progress',
    severity: 'medium',
    confidence: 0.98,
    suggestedDepartment: 'Water Supply & Sewage Board',
    estimatedRepairCost: '₹15,000',
    estimatedRepairTime: '8 Hours',
    recommendedPriority: 'medium',
    city: 'bengaluru',
    location: {
      lat: 12.9811,
      lng: 77.6084,
      address: '12th Cross Street, Defence Colony, Bengaluru',
    },
    imageUrl: 'https://images.unsplash.com/photo-1542013936693-8848e57423e1?auto=format&fit=crop&w=600&q=80',
    reportedBy: 'citizen_rahul',
    reportedByName: 'Rahul Verma',
    isAnonymous: false,
    createdAt: new Date(Date.now() - 3600000 * 24 * 1).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 4).toISOString(),
    verifications: [],
    comments: [],
    assignment: {
      workerId: 'worker_sam',
      workerName: 'Sam Bahadur',
      assignedAt: new Date(Date.now() - 3600000 * 8).toISOString(),
      beforePhoto: 'https://images.unsplash.com/photo-1542013936693-8848e57423e1?auto=format&fit=crop&w=600&q=80',
    },
    citizenUpvotes: 5,
    citizenUpvoters: [],
  },
  {
    id: 'issue-5',
    title: 'Open Sewer Manhole with No Safety Warning',
    description: 'A sewer cover is missing, leaving a deep dark pit on a high-traffic pedestrian walkway. It is completely unlit, making it a critical threat to children and commuters in Darbhanga.',
    category: 'overflow_drain',
    status: 'reported',
    severity: 'critical',
    confidence: 0.99,
    suggestedDepartment: 'Water Supply & Sewage Division',
    estimatedRepairCost: '₹4,500',
    estimatedRepairTime: '3 Hours',
    recommendedPriority: 'immediate',
    city: 'darbhanga',
    location: {
      lat: 26.1512,
      lng: 85.8974,
      address: 'Near Tower Chowk Central Market, Darbhanga, Bihar 846004',
    },
    imageUrl: 'https://images.unsplash.com/photo-1584824486509-112e4181ff6b?auto=format&fit=crop&w=600&q=80',
    reportedBy: 'citizen_sarah',
    reportedByName: 'Sarah Jenkins',
    isAnonymous: false,
    createdAt: new Date(Date.now() - 3600000 * 2).toISOString(), // 2 hrs ago
    updatedAt: new Date(Date.now() - 3600000 * 2).toISOString(),
    verifications: [],
    comments: [],
    citizenUpvotes: 25,
    citizenUpvoters: ['citizen_john', 'citizen_rahul', 'citizen_sarah'],
  },
  {
    id: 'issue-6',
    title: 'Broken Park Bench and Damaged Swings',
    description: 'Three concrete park benches are cracked and dangerous to sit on. The children swings are also rusted and broken. The local park requires restorative works.',
    category: 'park_damage',
    status: 'completed',
    severity: 'low',
    confidence: 0.91,
    suggestedDepartment: 'Horticulture & Parks Department',
    estimatedRepairCost: '₹14,000',
    estimatedRepairTime: '12 Hours',
    recommendedPriority: 'low',
    city: 'darbhanga',
    location: {
      lat: 26.1642,
      lng: 85.8892,
      address: 'Children Playground, Laheriasarai Sector B, Darbhanga, Bihar 846001',
    },
    imageUrl: 'https://images.unsplash.com/photo-1541432901042-2d8bd64b4a9b?auto=format&fit=crop&w=600&q=80',
    reportedBy: 'citizen_rahul',
    reportedByName: 'Rahul Verma',
    isAnonymous: true,
    createdAt: new Date(Date.now() - 3600000 * 24 * 10).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 24 * 1).toISOString(),
    verifications: [
      {
        userId: 'citizen_john',
        userName: 'John Doe',
        vote: 'fixed',
        comment: 'Confirmed fixed! The benches are sturdy and beautifully painted. Great work!',
        timestamp: new Date(Date.now() - 3600000 * 24 * 1).toISOString(),
      }
    ],
    comments: [
      {
        id: 'comment-3',
        userId: 'worker_sam',
        userName: 'Sam Bahadur',
        userRole: 'worker',
        text: 'Swings are re-anchored and concrete benches are refitted with reinforcement steel bars.',
        timestamp: new Date(Date.now() - 3600000 * 24 * 2).toISOString(),
      }
    ],
    assignment: {
      workerId: 'worker_sam',
      workerName: 'Sam Bahadur',
      assignedAt: new Date(Date.now() - 3600000 * 24 * 4).toISOString(),
      beforePhoto: 'https://images.unsplash.com/photo-1541432901042-2d8bd64b4a9b?auto=format&fit=crop&w=600&q=80',
      afterPhoto: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=600&q=80',
      completionNotes: 'All 3 benches replaced with new ergonomic pre-cast concrete units. Swings re-oiled and rusty chains substituted.',
      completedAt: new Date(Date.now() - 3600000 * 24 * 2).toISOString(),
    },
    citizenUpvotes: 4,
    citizenUpvoters: [],
    citizenVerificationsCount: 1,
    verifiedByCitizens: ['citizen_john'],
  },
  {
    id: 'issue-7',
    title: 'Waterlogging & Clogged Drains at Market Crossing',
    description: 'Monsoon waters have filled up the entire Maurya Lok shopping corridor road because the primary sewage drains are completely clogged with commercial garbage bags.',
    category: 'overflow_drain',
    status: 'reported',
    severity: 'high',
    confidence: 0.95,
    suggestedDepartment: 'Solid Waste Management & Sewage Board',
    estimatedRepairCost: '₹9,800',
    estimatedRepairTime: '5 Hours',
    recommendedPriority: 'high',
    city: 'patna',
    location: {
      lat: 25.6112,
      lng: 85.1214,
      address: 'Maurya Lok Market Corridor, Patna, Bihar 800001',
    },
    imageUrl: 'https://images.unsplash.com/photo-1541888946425-d81bb19240f5?auto=format&fit=crop&w=600&q=80',
    reportedBy: 'citizen_rahul',
    reportedByName: 'Rahul Verma',
    isAnonymous: false,
    createdAt: new Date(Date.now() - 3600000 * 4).toISOString(), // 4 hrs ago
    updatedAt: new Date(Date.now() - 3600000 * 4).toISOString(),
    verifications: [],
    comments: [],
    citizenUpvotes: 11,
    citizenUpvoters: ['citizen_john'],
  }
];

const initialUserProfiles: Record<string, any> = {
  citizen_john: {
    uid: 'citizen_john',
    email: 'john@communityhero.ai',
    displayName: 'John Doe',
    role: 'citizen',
    xp: 750,
    coins: 340,
    level: 4,
    streak: 5,
    badges: [
      { id: 'badge-1', title: 'Pothole Patrol', description: 'Reported 3 active road issues', unlockedAt: new Date().toISOString(), icon: 'ShieldAlert' },
      { id: 'badge-2', title: 'Eagle Eye', description: 'High confidence report accepted by officers', unlockedAt: new Date().toISOString(), icon: 'Eye' },
    ],
  },
  worker_sam: {
    uid: 'worker_sam',
    email: 'sam@municipal.gov.in',
    displayName: 'Sam Bahadur',
    role: 'worker',
    department: 'Road & Maintenance Task Force',
    xp: 2350,
    coins: 120,
    level: 12,
    streak: 9,
    badges: [
      { id: 'badge-cleaner', title: 'Speedy Patch', description: 'Resolved 5 issues in under 24 hours', unlockedAt: new Date().toISOString(), icon: 'Zap' },
      { id: 'badge-hero', title: 'Local Savior', description: 'Earned 10 public confirmations', unlockedAt: new Date().toISOString(), icon: 'Award' },
    ],
  },
  officer_meera: {
    uid: 'officer_meera',
    email: 'meera.nair@municipal.gov.in',
    displayName: 'Officer Meera Nair',
    role: 'officer',
    department: 'Joint Civic Operations Command',
    xp: 4200,
    coins: 0,
    level: 21,
    streak: 15,
    badges: [
      { id: 'badge-justice', title: 'Fair Arbitrator', description: 'Reviewed 50 complaints accurately', unlockedAt: new Date().toISOString(), icon: 'Scale' },
    ],
  },
  admin_hero: {
    uid: 'admin_hero',
    email: 'admin@communityhero.ai',
    displayName: 'System Admin Hero',
    role: 'admin',
    xp: 9999,
    coins: 999,
    level: 50,
    streak: 100,
    badges: [],
  },
  ngo_clean_green: {
    uid: 'ngo_clean_green',
    email: 'info@cleangreenngo.org',
    displayName: 'Clean & Green Earth NGO',
    role: 'ngo',
    xp: 1500,
    coins: 1000,
    level: 8,
    streak: 4,
    badges: [
      { id: 'ngo-bunch', title: 'Eco Alliance', description: 'Orchestrated 3 civic tree drives', unlockedAt: new Date().toISOString(), icon: 'Leaf' },
    ],
  },
  csr_tech_corp: {
    uid: 'csr_tech_corp',
    email: 'csr@techcorp.com',
    displayName: 'TechCorp Solutions CSR',
    role: 'csr',
    xp: 3200,
    coins: 5000,
    level: 15,
    streak: 6,
    badges: [],
  }
};

const initialNgoProjects = [
  {
    id: 'ngo-p-1',
    title: 'Community Cleaning Drive & Waste Segregation Training',
    description: 'Join hands with our NGO this Saturday to clean up the Sector 4 Garbage spot and install 3 color-coded bins. Volunteers will receive participation certificates, meals, and 100 Civic XP!',
    category: 'garbage',
    location: 'Community Park Entrance, 100 Feet Rd',
    ngoName: 'Clean & Green Earth NGO',
    volunteersCount: 22,
    volunteersNeeded: 50,
    donationsGoal: 15000,
    donationsCollected: 8500,
    linkedIssueId: 'issue-2',
    imageUrl: 'https://images.unsplash.com/photo-1554123156-f084be196728?auto=format&fit=crop&w=600&q=80',
  },
  {
    id: 'ngo-p-2',
    title: 'Vanamahotsava: Plant 100 Saplings around Indiranagar',
    description: 'Sponsor or plant a tree! We are looking for 20 active volunteers to plant indigenous shady trees to restore microclimate and repair the broken park ecosystem.',
    category: 'tree_fallen',
    location: 'Cubbon Park Sector B and surrounding wards',
    ngoName: 'Save Tree canopy NGO',
    volunteersCount: 14,
    volunteersNeeded: 30,
    donationsGoal: 20000,
    donationsCollected: 18000,
    imageUrl: 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?auto=format&fit=crop&w=600&q=80',
  }
];

const initialCsrCampaigns = [
  {
    id: 'csr-1',
    companyName: 'TechCorp Solutions',
    projectTitle: 'Smart Solar Streetlighting for Outer Ring Road',
    fundingAmount: 450000,
    supportedSectors: ['Renewable Energy', 'Urban Safety'],
    impactDescription: 'Sponsoring the installation of 50 intelligent, auto-dimming LED streetlights with low-impact batteries to eliminate safety blackspots near Indiranagar.',
    activeIssuesResolved: 15,
    logoUrl: 'https://images.unsplash.com/photo-1560179707-f14e90ef3623?auto=format&fit=crop&w=120&q=80',
  },
  {
    id: 'csr-2',
    companyName: 'Apex Hydrotech',
    projectTitle: 'Municipal Pipeline Pressure Sensors Deployment',
    fundingAmount: 750000,
    supportedSectors: ['Water Conservation', 'Smart Infrastructure'],
    impactDescription: 'Sponsoring smart IoT sensors connected with municipal main feeders to identify real-time pressure anomalies and immediately signal leaks prior to road floods.',
    activeIssuesResolved: 32,
    logoUrl: 'https://images.unsplash.com/photo-1516841273335-e39b37888115?auto=format&fit=crop&w=120&q=80',
  }
];

const initialPredictiveHotspots = [
  {
    id: 'hotspot-1',
    category: 'flood',
    lat: 12.9825,
    lng: 77.5985,
    address: 'Vasanth Nagar Lowland Feeder Circle',
    riskScore: 89,
    predictionReason: 'Calculated using 5-year historical storm data, topography models showing a 4-meter basin dip, and upcoming heavy pre-monsoon precipitation forecasting.',
    historicalIncidentCount: 14,
    recommendedPreventativeAction: 'Clear silt traps and expand storm sewage diameter from 400mm to 800mm before July 5th.',
  },
  {
    id: 'hotspot-2',
    category: 'pothole',
    lat: 12.9642,
    lng: 77.6111,
    address: 'Outer Ring Main Flyover Access Ramp',
    riskScore: 78,
    predictionReason: 'High freight vehicular load indices combined with asphalt wear-life calculation (asphalt has been unsealed for 32 months) and micro-cracking visual indicators.',
    historicalIncidentCount: 9,
    recommendedPreventativeAction: 'Apply hot micro-surfacing protective overlay to seal micro-fissures and water seepage points.',
  },
  {
    id: 'hotspot-3',
    category: 'garbage',
    lat: 12.9722,
    lng: 77.6055,
    address: 'Halasuru Metro Back Road Commercial Zone',
    riskScore: 72,
    predictionReason: 'High street-food vendor density coupled with insufficient public dustbin infrastructure and irregular sanitation truck schedules during festival seasons.',
    historicalIncidentCount: 22,
    recommendedPreventativeAction: 'Establish an AI-monitored smart community trash compactor hub and daily corporate food waste audit.',
  }
];

const officialGovCases = [
  {
    id: 'gov-issue-101',
    title: '[GOV-BBMP-9821] Illegal Stormwater Trenching & Silt Blockage',
    description: 'Official record imported from the Municipal Drainage and Sanitation Board. Major block detected via deep-sensor monitoring. Public warning issued for surrounding residents of Indiranagar Sector 2.',
    category: 'overflow_drain',
    status: 'verified',
    severity: 'critical',
    confidence: 1.0,
    suggestedDepartment: 'Water Supply & Sewage Board',
    estimatedRepairCost: '₹42,000',
    estimatedRepairTime: '24 Hours',
    recommendedPriority: 'immediate',
    location: { lat: 12.9788, lng: 77.5999, address: 'Halasuru Canal feeder inlet point, Ward 98' },
    reportedBy: 'gov_portal',
    reportedByName: 'Central Municipal Portal',
    isAnonymous: false,
    isGovSynced: true,
    createdAt: new Date(Date.now() - 3600000 * 5).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 5).toISOString(),
    verifications: [],
    comments: [],
    citizenUpvotes: 14,
    citizenUpvoters: [],
  },
  {
    id: 'gov-issue-102',
    title: '[GOV-BESCOM-140] Exposed High-Voltage Line Over Hanging Branch',
    description: 'High voltage main transmission lines are tangled with a heavy broken tree branch on HAL Old Airport Road. Dispatched by State Power Board inspectors.',
    category: 'electric_pole_damage',
    status: 'assigned',
    severity: 'high',
    confidence: 1.0,
    suggestedDepartment: 'Municipal Electricity Board',
    estimatedRepairCost: '₹18,500',
    estimatedRepairTime: '6 Hours',
    recommendedPriority: 'high',
    location: { lat: 12.9621, lng: 77.6015, address: 'Near Airport Main Gate road junction, Sector 1' },
    reportedBy: 'gov_portal',
    reportedByName: 'State Grid Commission',
    isAnonymous: false,
    isGovSynced: true,
    createdAt: new Date(Date.now() - 3600000 * 2).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 2).toISOString(),
    verifications: [],
    comments: [],
    citizenUpvotes: 21,
    citizenUpvoters: [],
  },
  {
    id: 'gov-issue-103',
    title: '[GOV-HEALTH-349] Major Sewage Contamination of Drinking Tap Water Tanker',
    description: 'Public health alert reported at municipal distribution pump station. Cross connection suspected. Immediate chlorination, valve seals replacement and audit requested.',
    category: 'water_leakage',
    status: 'reported',
    severity: 'critical',
    confidence: 1.0,
    suggestedDepartment: 'Public Health & Sanitation Division',
    estimatedRepairCost: '₹75,000',
    estimatedRepairTime: '18 Hours',
    recommendedPriority: 'immediate',
    location: { lat: 12.9845, lng: 77.5899, address: 'Public Tanker Depot Road, Indiranagar Block C' },
    reportedBy: 'gov_portal',
    reportedByName: 'National Ministry of Health & Sanitation',
    isAnonymous: false,
    isGovSynced: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    verifications: [],
    comments: [],
    citizenUpvotes: 35,
    citizenUpvoters: [],
  }
];

// Helper to access LocalStorage with fallbacks
function getStorage<T>(key: string, fallback: T): T {
  try {
    const val = localStorage.getItem(key);
    if (val) {
      return JSON.parse(val) as T;
    }
  } catch (e) {
    console.error(`Error reading ${key} from storage:`, e);
  }
  return fallback;
}

function setStorage<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    console.error(`Error writing ${key} to storage:`, e);
  }
}

// Global In-Memory and LocalStorage Backed database
let issues = getStorage<any[]>('atlasone_issues', initialIssues);
let userProfiles = getStorage<Record<string, any>>('atlasone_user_profiles', initialUserProfiles);
let ngoProjects = getStorage<any[]>('atlasone_ngo_projects', initialNgoProjects);
let csrCampaigns = getStorage<any[]>('atlasone_csr_campaigns', initialCsrCampaigns);
let predictiveHotspots = getStorage<any[]>('atlasone_predictive_hotspots', initialPredictiveHotspots);
let isGovConnected = getStorage<boolean>('atlasone_is_gov_connected', true);

// Save states back to local storage
const persistAll = () => {
  setStorage('atlasone_issues', issues);
  setStorage('atlasone_user_profiles', userProfiles);
  setStorage('atlasone_ngo_projects', ngoProjects);
  setStorage('atlasone_csr_campaigns', csrCampaigns);
  setStorage('atlasone_predictive_hotspots', predictiveHotspots);
  setStorage('atlasone_is_gov_connected', isGovConnected);
};

// Override window.fetch to capture /api requests locally
const originalFetch = window.fetch.bind(window);

const mockFetch = async function (input: RequestInfo | URL, init?: RequestInit): Promise<Response> {
  const url = typeof input === 'string' ? input : (input instanceof URL ? input.toString() : input.url);
  const method = init?.method?.toUpperCase() || 'GET';
  
  if (url.startsWith('/api/') || url.includes('/api/')) {
    console.log(`[Mock API Interceptor] intercepted: ${method} ${url}`);
    
    // Parse body if present
    let body: any = {};
    if (init?.body) {
      try {
        body = JSON.parse(init.body as string);
      } catch (e) {
        // Not JSON or empty
      }
    }

    // Process endpoints
    try {
      // 1. GET /api/issues
      if (url.match(/\/api\/issues$/) && method === 'GET') {
        return new Response(JSON.stringify(issues), {
          status: 200,
          headers: { 'Content-Type': 'application/json' }
        });
      }

      // 2. POST /api/issues
      if (url.match(/\/api\/issues$/) && method === 'POST') {
        const {
          title, description, category, severity, location, imageUrl,
          reportedBy, reportedByName, isAnonymous, ocrAssetId, city
        } = body;

        const newIssue = {
          id: `issue-${Date.now()}`,
          title: title || 'Reported Civic Problem',
          description: description || 'No details provided.',
          category: category || 'pothole',
          status: 'reported',
          severity: severity || 'medium',
          confidence: 0.95,
          suggestedDepartment: 'General Municipal Operations',
          estimatedRepairCost: '₹5,000 - ₹15,000',
          estimatedRepairTime: '12-24 Hours',
          recommendedPriority: severity === 'critical' ? 'immediate' : (severity === 'high' ? 'high' : 'medium'),
          location: location || { lat: 12.9716, lng: 77.5946, address: 'Central Ward Circle' },
          imageUrl: imageUrl || 'https://images.unsplash.com/photo-1584824486509-112e4181ff6b?auto=format&fit=crop&w=600&q=80',
          reportedBy: reportedBy || 'citizen_john',
          reportedByName: reportedByName || 'John Doe',
          isAnonymous: !!isAnonymous,
          ocrAssetId: ocrAssetId || null,
          city: city || 'bengaluru',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          verifications: [],
          comments: [],
          citizenUpvotes: 1,
          citizenUpvoters: [reportedBy || 'citizen_john'],
        };

        issues.unshift(newIssue);

        // Reward user
        const userId = reportedBy || 'citizen_john';
        if (userProfiles[userId]) {
          userProfiles[userId].xp += 100;
          userProfiles[userId].coins += 50;
          userProfiles[userId].streak += 1;
          userProfiles[userId].lastReportedAt = new Date().toISOString();
          userProfiles[userId].level = Math.floor(userProfiles[userId].xp / 500) + 1;
        }

        persistAll();
        return new Response(JSON.stringify(newIssue), {
          status: 201,
          headers: { 'Content-Type': 'application/json' }
        });
      }

      // 3. POST /api/issues/:id/upvote
      const upvoteMatch = url.match(/\/api\/issues\/([^/]+)\/upvote$/);
      if (upvoteMatch && method === 'POST') {
        const id = upvoteMatch[1];
        const { userId } = body;
        const issue = issues.find(i => i.id === id);
        if (!issue) {
          return new Response(JSON.stringify({ error: 'Issue not found' }), { status: 404 });
        }

        if (!issue.citizenUpvoters) {
          issue.citizenUpvoters = [];
        }

        if (issue.citizenUpvoters.includes(userId)) {
          issue.citizenUpvoters = issue.citizenUpvoters.filter((uid: string) => uid !== userId);
          issue.citizenUpvotes = Math.max(0, issue.citizenUpvotes - 1);
        } else {
          issue.citizenUpvoters.push(userId);
          issue.citizenUpvotes += 1;
          if (userProfiles[userId]) {
            userProfiles[userId].xp += 10;
          }
        }

        persistAll();
        return new Response(JSON.stringify(issue), { status: 200, headers: { 'Content-Type': 'application/json' } });
      }

      // 4. POST /api/issues/:id/comments
      const commentMatch = url.match(/\/api\/issues\/([^/]+)\/comments$/);
      if (commentMatch && method === 'POST') {
        const id = commentMatch[1];
        const { userId, userName, userRole, text } = body;
        const issue = issues.find(i => i.id === id);
        if (!issue) {
          return new Response(JSON.stringify({ error: 'Issue not found' }), { status: 404 });
        }

        const comment = {
          id: `comment-${Date.now()}`,
          userId,
          userName,
          userRole,
          text,
          timestamp: new Date().toISOString(),
        };

        if (!issue.comments) issue.comments = [];
        issue.comments.push(comment);
        issue.updatedAt = new Date().toISOString();

        if (userProfiles[userId]) {
          userProfiles[userId].xp += 15;
        }

        persistAll();
        return new Response(JSON.stringify(issue), { status: 201, headers: { 'Content-Type': 'application/json' } });
      }

      // 5. POST /api/issues/:id/vote (Community verification voting)
      const voteMatch = url.match(/\/api\/issues\/([^/]+)\/vote$/);
      if (voteMatch && method === 'POST') {
        const id = voteMatch[1];
        const { userId, userName, vote, comment } = body;
        const issue = issues.find(i => i.id === id);
        if (!issue) {
          return new Response(JSON.stringify({ error: 'Issue not found' }), { status: 404 });
        }

        const newVote = {
          userId,
          userName,
          vote,
          comment,
          timestamp: new Date().toISOString(),
        };

        if (!issue.verifications) {
          issue.verifications = [];
        }

        issue.verifications = issue.verifications.filter((v: any) => v.userId !== userId);
        issue.verifications.push(newVote);

        const verifiedVotes = issue.verifications.filter((v: any) => v.vote === 'verified').length;
        const fixedVotes = issue.verifications.filter((v: any) => v.vote === 'fixed').length;
        const fakeVotes = issue.verifications.filter((v: any) => v.vote === 'fake').length;

        if (issue.status === 'reported' && verifiedVotes >= 1) {
          issue.status = 'verified';
        } else if (issue.status === 'completed' && fixedVotes >= 2) {
          issue.status = 'confirmed';
        } else if (fakeVotes >= 3 && issue.status !== 'archived') {
          issue.status = 'archived';
        }

        issue.updatedAt = new Date().toISOString();

        if (userProfiles[userId]) {
          userProfiles[userId].xp += 40;
          userProfiles[userId].coins += 20;
          userProfiles[userId].level = Math.floor(userProfiles[userId].xp / 500) + 1;
        }

        persistAll();
        return new Response(JSON.stringify(issue), { status: 200, headers: { 'Content-Type': 'application/json' } });
      }

      // 6. POST /api/issues/:id/assign
      const assignMatch = url.match(/\/api\/issues\/([^/]+)\/assign$/);
      if (assignMatch && method === 'POST') {
        const id = assignMatch[1];
        const { workerId, workerName } = body;
        const issue = issues.find(i => i.id === id);
        if (!issue) {
          return new Response(JSON.stringify({ error: 'Issue not found' }), { status: 404 });
        }

        issue.status = 'assigned';
        issue.assignment = {
          workerId,
          workerName,
          assignedAt: new Date().toISOString(),
        };
        issue.updatedAt = new Date().toISOString();

        persistAll();
        return new Response(JSON.stringify(issue), { status: 200, headers: { 'Content-Type': 'application/json' } });
      }

      // 7. POST /api/issues/:id/progress
      const progressMatch = url.match(/\/api\/issues\/([^/]+)\/progress$/);
      if (progressMatch && method === 'POST') {
        const id = progressMatch[1];
        const { beforePhoto, afterPhoto, completionNotes, status } = body;
        const issue = issues.find(i => i.id === id);
        if (!issue) {
          return new Response(JSON.stringify({ error: 'Issue not found' }), { status: 404 });
        }

        if (!issue.assignment) {
          issue.assignment = {
            workerId: 'worker_sam',
            workerName: 'Sam Bahadur',
            assignedAt: new Date().toISOString()
          };
        }

        issue.status = status;
        if (beforePhoto) issue.assignment.beforePhoto = beforePhoto;
        if (afterPhoto) issue.assignment.afterPhoto = afterPhoto;
        if (completionNotes) issue.assignment.completionNotes = completionNotes;

        if (status === 'completed') {
          issue.assignment.completedAt = new Date().toISOString();
          const workerId = issue.assignment.workerId;
          if (userProfiles[workerId]) {
            userProfiles[workerId].xp += 300;
            userProfiles[workerId].coins += 100;
            userProfiles[workerId].level = Math.floor(userProfiles[workerId].xp / 500) + 1;
          }
        }

        issue.updatedAt = new Date().toISOString();
        persistAll();
        return new Response(JSON.stringify(issue), { status: 200, headers: { 'Content-Type': 'application/json' } });
      }

      // 8. POST /api/issues/:id/notify-head
      const notifyHeadMatch = url.match(/\/api\/issues\/([^/]+)\/notify-head$/);
      if (notifyHeadMatch && method === 'POST') {
        const id = notifyHeadMatch[1];
        const { headName, headRole, mcName } = body;
        const issue = issues.find(i => i.id === id);
        if (!issue) {
          return new Response(JSON.stringify({ error: 'Issue not found' }), { status: 404 });
        }

        if (issue.status === 'reported') {
          issue.status = 'reviewed';
        }

        const systemComment = {
          id: `comment-sys-${Date.now()}`,
          userId: 'system',
          userName: 'GovConnect™ Dispatcher',
          userRole: 'admin',
          text: `🚨 Grievance formally dispatched to ${mcName}. Notified the office of ${headRole} ${headName || 'Municipal Commissioner'}.`,
          timestamp: new Date().toISOString()
        };

        if (!issue.comments) issue.comments = [];
        issue.comments.push(systemComment);

        issue.notifiedHead = {
          name: headName,
          role: headRole,
          mcName: mcName,
          notifiedAt: new Date().toISOString()
        };

        issue.updatedAt = new Date().toISOString();
        persistAll();
        return new Response(JSON.stringify(issue), { status: 200, headers: { 'Content-Type': 'application/json' } });
      }

      // 9. POST /api/issues/:id/verify-resolution
      const verifyResMatch = url.match(/\/api\/issues\/([^/]+)\/verify-resolution$/);
      if (verifyResMatch && method === 'POST') {
        const id = verifyResMatch[1];
        const { userId, userName, vote, comment } = body;
        const issue = issues.find(i => i.id === id);
        if (!issue) {
          return new Response(JSON.stringify({ error: 'Issue not found' }), { status: 404 });
        }

        if (!issue.citizenVerificationsCount) issue.citizenVerificationsCount = 0;
        if (!issue.citizenDisputesCount) issue.citizenDisputesCount = 0;
        if (!issue.verifiedByCitizens) issue.verifiedByCitizens = [];
        if (!issue.disputedByCitizens) issue.disputedByCitizens = [];

        if (vote === 'verify_done') {
          if (issue.verifiedByCitizens.includes(userId)) {
            return new Response(JSON.stringify({ error: 'You have already verified this resolution.' }), { status: 400 });
          }
          if (issue.disputedByCitizens.includes(userId)) {
            issue.disputedByCitizens = issue.disputedByCitizens.filter((u: string) => u !== userId);
            issue.citizenDisputesCount = Math.max(0, issue.citizenDisputesCount - 1);
          }
          issue.verifiedByCitizens.push(userId);
          issue.citizenVerificationsCount += 1;

          if (issue.citizenVerificationsCount >= 2 && issue.status === 'completed') {
            issue.status = 'confirmed';
          }
        } else if (vote === 'dispute_fake') {
          if (issue.disputedByCitizens.includes(userId)) {
            return new Response(JSON.stringify({ error: 'You have already disputed this resolution.' }), { status: 400 });
          }
          if (issue.verifiedByCitizens.includes(userId)) {
            issue.verifiedByCitizens = issue.verifiedByCitizens.filter((u: string) => u !== userId);
            issue.citizenVerificationsCount = Math.max(0, issue.citizenVerificationsCount - 1);
          }
          issue.disputedByCitizens.push(userId);
          issue.citizenDisputesCount += 1;
        }

        if (!issue.verifications) issue.verifications = [];
        issue.verifications.push({
          userId,
          userName,
          vote: vote === 'verify_done' ? 'fixed' : 'fake',
          comment: comment || (vote === 'verify_done' ? 'Verified that the resolution works and the issue is completely fixed!' : 'Disputed this repair. The problem still exists on-site.'),
          timestamp: new Date().toISOString()
        });

        if (userProfiles[userId]) {
          userProfiles[userId].xp += 40;
          userProfiles[userId].coins += 20;
          userProfiles[userId].level = Math.floor(userProfiles[userId].xp / 500) + 1;
        }

        issue.updatedAt = new Date().toISOString();
        persistAll();
        return new Response(JSON.stringify(issue), { status: 200, headers: { 'Content-Type': 'application/json' } });
      }

      // 10. POST /api/issues/:id/draft-grievance
      const draftMatch = url.match(/\/api\/issues\/([^/]+)\/draft-grievance$/);
      if (draftMatch && method === 'POST') {
        const id = draftMatch[1];
        const { type, complainantName } = body;
        const issue = issues.find(i => i.id === id);
        if (!issue) {
          return new Response(JSON.stringify({ error: 'Issue not found' }), { status: 404 });
        }

        const dateStr = new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' });
        const nameVal = complainantName || 'Concerned Citizen / Ward Representative';

        let simulatedDraft = '';
        if (type === 'work_order') {
          simulatedDraft = `### 📋 MUNICIPAL CONTRACTOR WORK ORDER
**Order Reference:** WO-ATLASONE-${issue.id.slice(-5).toUpperCase()}  
**Date of Dispatch:** ${dateStr}  
**Target Department:** ${issue.suggestedDepartment || 'Municipal Operations Board'}  

---

#### 1. SITE & ASSET DETAILS
* **Location Reference:** ${issue.location.address}  
* **Coordinates:** Latitude ${issue.location.lat.toFixed(4)}, Longitude ${issue.location.lng.toFixed(4)}  
* **Asset/OCR Tags Detected:** ${issue.ocrAssetId || 'N/A'}  
* **Category:** ${issue.category.replace('_', ' ').toUpperCase()}  

#### 2. FIELD BRIEFING & DEFECT DIAGNOSIS
The community visual grid has captured severe **${issue.severity.toUpperCase()}** priority infrastructure degradation at the site. 
* **Primary Defect:** ${issue.title}  
* **Diagnosis:** ${issue.description}  
* **Visual Telemetry Confidence:** ${(issue.confidence * 100).toFixed(0)}% AI Verified  

#### 3. ALLOCATED MATERIAL & LABOR PARAMETERS
* **Estimated Payout Budget:** ${issue.estimatedRepairCost || '₹8,500'} (Escrow Held)  
* **Standard Operational Duration:** ${issue.estimatedRepairTime || '4 Hours'}  
* **Recommended Crew Size:** 3 Skilled Repair Technicians  

#### 4. OPERATIONAL DIRECTIVES
1. **Secure Safety Boundaries:** Immediately erect high-visibility warning warning barricades around the work site.
2. **Pre-Repair Photography:** Capture detailed on-site telemetry images before unsealing.
3. **Execution Protocol:** Excavate/patch/replace materials matching municipal standard specifications (M-25 Concrete / VG-30 Bitumen mix).
4. **Validation:** Upload post-repair high-resolution images via the Field App to release escrow funds from corporate CSR backers.

---
**Issued by Order of:** Joint Civic Operations Command (GovConnect System Node)`;
        } else if (type === 'email') {
          simulatedDraft = `Subject: URGENT: Redressal requested for ${issue.title} at ${issue.location.address}

Dear District Representative / Ward Councillor,

I am writing to you as a resident and active constituent of this ward to draw your immediate attention to a persistent and hazardous public safety issue in our locality.

**Issue Location:** ${issue.location.address}  
**Report Reference ID:** ATLASONE-${issue.id.slice(-5).toUpperCase()}  
**Severity:** ${issue.severity.toUpperCase()}  

**Detailed Complaint Description:**
${issue.description}

This issue represents a substantial risk to school children, elderly commuters, and local residents. It has already been verified and endorsed by many community members on our neighborhood monitoring grid.

As our elected representative, we look to your office to expedite public works intervention. We kindly request you to coordinate with the **${issue.suggestedDepartment}** to initiate immediate repairs.

We have queued this report formally on the Unified National Civic Grid (CPGRAMS Node). You may audit the real-time visual telemetry and GPS logs directly on our community portal.

Thank you for your time, consideration, and swift action in making our neighborhood safer.

Sincerely,  
**${nameVal}**  
Active Resident, CPGRAMS Community Node`;
        } else {
          simulatedDraft = `### 🏛️ FORMAL WARD-LEVEL CIVIC PETITION
**To,**  
The Chief Municipal Commissioner,  
${issue.suggestedDepartment || 'Department of Public Works & Urban Infrastructure'}  
State Municipal Corporation  

**Date:** ${dateStr}  
**Subject:** Formal Grievance and Petition for Immediate Redressal of: **${issue.title}**  

---

#### PREAMBLE & JURISDICTION STATEMENT
Under Section 58 of the Municipal Corporation Act, we, the undersigned residents of the ward, formally invoke our citizen rights to safe public infrastructure and sanitary living conditions. We submit this petition to demand immediate restorative action at the following coordinates:
* **Locality Address:** ${issue.location.address}  
* **GPS Coordinates:** Lat: ${issue.location.lat.toFixed(5)}, Lng: ${issue.location.lng.toFixed(5)}  

---

#### STATEMENT OF GRIEVANCE
We formally record the presence of a critical public defect: **${issue.title}**. 

Our community inspection reports the following conditions:
> ${issue.description}

This defect is classified as **${issue.severity.toUpperCase()}** priority. It has been active for several days, causing severe vehicular gridlock and posing an imminent danger of physical injury to pedestrians and commuters.

---

#### TECHNICAL AND TELEMETRY LOGS
Our community-led Edge AI vision scanning system has processed visual telemetry for this site:
* **Feature ID Tag:** ${issue.ocrAssetId || 'ASSET-MUNICIPAL-UNSPECIFIED'}
* **Visual Confidence Score:** ${(issue.confidence * 100).toFixed(0)}% AI Verified Match
* **Public Endorsement Rating:** ${issue.citizenUpvotes || 1} Registered Ward Endorsements
* **Estimated Budget Standard:** ${issue.estimatedRepairCost || '₹8,500'}

---

#### DEMAND FOR RELIEF & DIRECTIVE
We respectfully demand that:
1. An on-site engineer inspect this hazard within 24 hours of this dispatch.
2. Formally assign a municipal task force to initiate repairs.
3. Repair works be concluded within **${issue.estimatedRepairTime || '6 Hours'}** of assignment.

Failure to address this critical grievance will force residents to escalate this matter to the State Lokayukta (Ombudsman) and file a formal public interest complaint with district safety boards.

**Respectfully Filed by:**  
**${nameVal}**  
*Representing the Verified Neighbors of Ward Grid*  
*Submitted electronically via CPGRAMS GovConnect Gateway*`;
        }

        return new Response(JSON.stringify({ text: simulatedDraft, simulated: true }), {
          status: 200,
          headers: { 'Content-Type': 'application/json' }
        });
      }

      // 11. POST /api/issues/:id/sponsor
      const sponsorMatch = url.match(/\/api\/issues\/([^/]+)\/sponsor$/);
      if (sponsorMatch && method === 'POST') {
        const id = sponsorMatch[1];
        const { companyName, sponsorAmount, userId } = body;
        const issue = issues.find(i => i.id === id);
        if (!issue) {
          return new Response(JSON.stringify({ error: 'Issue not found' }), { status: 404 });
        }

        const amt = Number(sponsorAmount) || 10000;
        if (!issue.escrowSponsors) issue.escrowSponsors = [];
        issue.escrowSponsors.push({
          companyName,
          amount: amt,
          userId,
          timestamp: new Date().toISOString()
        });

        issue.sponsoredAmount = (issue.sponsoredAmount || 0) + amt;
        if (issue.status === 'reported' || issue.status === 'verified') {
          issue.status = 'sponsored';
        }

        issue.updatedAt = new Date().toISOString();

        if (userProfiles[userId]) {
          userProfiles[userId].xp += 250;
          userProfiles[userId].coins += 150;
        }

        const systemComment = {
          id: `comment-sys-spons-${Date.now()}`,
          userId: 'system',
          userName: 'Atlasone Escrow Engine',
          userRole: 'admin',
          text: `💼 **COMMUNITY SPONSORSHIP LOCKED:** Corporate sponsor **${companyName}** has allocated a local CSR budget of **₹${amt.toLocaleString()}** to this active issue card. Payout is secured in escrow and will be dispatched directly to contractors immediately upon crowd-sourced P2P citizen verification of repairs!`,
          timestamp: new Date().toISOString()
        };

        if (!issue.comments) issue.comments = [];
        issue.comments.push(systemComment);

        persistAll();
        return new Response(JSON.stringify(issue), { status: 200, headers: { 'Content-Type': 'application/json' } });
      }

      // 12. GET /api/verification-tasks
      if (url.match(/\/api\/verification-tasks/) && method === 'GET') {
        const urlObj = new URL(url, window.location.origin);
        const city = urlObj.searchParams.get('city') || 'bengaluru';
        const cityIssues = issues.filter(i => i.city === city && ['reported', 'completed', 'sponsored', 'assigned', 'in_progress'].includes(i.status));
        
        const tasks = cityIssues.map(issue => {
          const isCompleted = issue.status === 'completed';
          return {
            id: `task-${issue.id}`,
            issueId: issue.id,
            title: isCompleted ? `Audit Resolved: ${issue.title}` : `Verify Active Issue: ${issue.title}`,
            description: isCompleted 
              ? `A field technician reported this defect as completely repaired. Tap to inspect the site and confirm if the work was executed successfully.`
              : `A neighbor reported this active defect. Tap to verify if the issue is still active at this site to eliminate duplicates.`,
            rewardXp: isCompleted ? 80 : 50,
            rewardCoins: isCompleted ? 45 : 25,
            issueCategory: issue.category,
            imageUrl: issue.imageUrl,
            location: issue.location,
            status: issue.status,
          };
        });

        return new Response(JSON.stringify(tasks), { status: 200, headers: { 'Content-Type': 'application/json' } });
      }

      // 13. GET /api/users/:uid
      const userMatch = url.match(/\/api\/users\/([^/]+)$/);
      if (userMatch && method === 'GET') {
        const uid = userMatch[1];
        let profile = userProfiles[uid];
        if (!profile) {
          profile = {
            uid,
            email: `${uid}@communityhero.ai`,
            displayName: uid.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' '),
            role: uid.includes('worker') ? 'worker' : (uid.includes('officer') ? 'officer' : 'citizen'),
            xp: 100,
            coins: 50,
            level: 1,
            streak: 1,
            badges: [],
          };
          userProfiles[uid] = profile;
          persistAll();
        }
        return new Response(JSON.stringify(profile), { status: 200, headers: { 'Content-Type': 'application/json' } });
      }

      // 14. POST /api/users/auth/register
      if (url.match(/\/api\/users\/auth\/register$/) && method === 'POST') {
        const { email, displayName, role, department } = body;
        if (!email || !displayName) {
          return new Response(JSON.stringify({ error: 'Email and Display Name are required.' }), { status: 400 });
        }

        const uid = 'user_' + Date.now();
        const newProfile = {
          uid,
          email,
          displayName,
          role: role || 'citizen',
          department: department || undefined,
          xp: 100,
          coins: 50,
          level: 1,
          streak: 1,
          badges: [],
        };

        userProfiles[uid] = newProfile;
        persistAll();
        return new Response(JSON.stringify(newProfile), { status: 201, headers: { 'Content-Type': 'application/json' } });
      }

      // 15. POST /api/users/auth/login
      if (url.match(/\/api\/users\/auth\/login$/) && method === 'POST') {
        const { email } = body;
        if (!email) {
          return new Response(JSON.stringify({ error: 'Email is required.' }), { status: 400 });
        }

        const foundUid = Object.keys(userProfiles).find(
          uid => userProfiles[uid].email?.toLowerCase() === email.toLowerCase()
        );

        if (foundUid) {
          return new Response(JSON.stringify(userProfiles[foundUid]), { status: 200, headers: { 'Content-Type': 'application/json' } });
        } else {
          // Auto register on login if not found
          const uid = 'user_' + Date.now();
          const mockName = email.split('@')[0].split(/[._-]/).map((w: string) => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
          const newProfile = {
            uid,
            email,
            displayName: mockName || 'New Citizen',
            role: 'citizen',
            xp: 100,
            coins: 50,
            level: 1,
            streak: 1,
            badges: [],
          };
          userProfiles[uid] = newProfile;
          persistAll();
          return new Response(JSON.stringify(newProfile), { status: 200, headers: { 'Content-Type': 'application/json' } });
        }
      }

      // 16. GET /api/predictive-hotspots
      if (url.match(/\/api\/predictive-hotspots$/) && method === 'GET') {
        return new Response(JSON.stringify(predictiveHotspots), { status: 200, headers: { 'Content-Type': 'application/json' } });
      }

      // 17. GET /api/ngo-projects
      if (url.match(/\/api\/ngo-projects$/) && method === 'GET') {
        return new Response(JSON.stringify(ngoProjects), { status: 200, headers: { 'Content-Type': 'application/json' } });
      }

      // 17a. POST /api/ngo-projects/:id/volunteer
      const volunteerMatch = url.match(/\/api\/ngo-projects\/([^/]+)\/volunteer$/);
      if (volunteerMatch && method === 'POST') {
        const id = volunteerMatch[1];
        const { userId } = body;
        const project = ngoProjects.find(p => p.id === id);
        if (!project) {
          return new Response(JSON.stringify({ error: 'NGO Project not found' }), { status: 404 });
        }

        project.volunteersCount = (project.volunteersCount || 0) + 1;
        if (userProfiles[userId]) {
          userProfiles[userId].xp += 150;
          userProfiles[userId].coins += 50;
        }

        persistAll();
        return new Response(JSON.stringify(project), { status: 200, headers: { 'Content-Type': 'application/json' } });
      }

      // 18. GET /api/csr-campaigns
      if (url.match(/\/api\/csr-campaigns$/) && method === 'GET') {
        return new Response(JSON.stringify(csrCampaigns), { status: 200, headers: { 'Content-Type': 'application/json' } });
      }

      // 19. GET /api/analytics
      if (url.match(/\/api\/analytics$/) && method === 'GET') {
        const total = issues.length;
        const pending = issues.filter(i => i.status === 'reported').length;
        const verified = issues.filter(i => i.status === 'verified').length;
        const active = issues.filter(i => ['assigned', 'in_progress'].includes(i.status)).length;
        const resolved = issues.filter(i => ['completed', 'confirmed'].includes(i.status)).length;

        const categoriesCount = issues.reduce((acc, curr) => {
          acc[curr.category] = (acc[curr.category] || 0) + 1;
          return acc;
        }, {} as Record<string, number>);

        const stats = {
          totalReports: total,
          resolutionRate: total > 0 ? Math.round((resolved / total) * 100) : 0,
          averageResolutionTime: '4.8 Hours',
          reportedToday: 3,
          breakdown: { pending, verified, active, resolved },
          categoriesCount,
          monthlyPerformance: [
            { month: 'Jan', reports: 34, resolved: 30 },
            { month: 'Feb', reports: 45, resolved: 38 },
            { month: 'Mar', reports: 62, resolved: 55 },
            { month: 'Apr', reports: 78, resolved: 70 },
            { month: 'May', reports: 95, resolved: 88 },
            { month: 'Jun', reports: total + 120, resolved: resolved + 105 },
          ],
          departmentLoad: [
            { name: 'Roads Dept', load: issues.filter(i => i.category === 'pothole' || i.category === 'broken_sidewalk').length, budget: '₹4.5L' },
            { name: 'Sanitation', load: issues.filter(i => i.category === 'garbage' || i.category === 'illegal_dumping').length, budget: '₹2.8L' },
            { name: 'Electricity', load: issues.filter(i => i.category === 'broken_streetlight' || i.category === 'electric_pole_damage').length, budget: '₹3.1L' },
            { name: 'Water & Sewage', load: issues.filter(i => i.category === 'water_leakage' || i.category === 'overflow_drain').length, budget: '₹5.2L' },
          ]
        };

        return new Response(JSON.stringify(stats), { status: 200, headers: { 'Content-Type': 'application/json' } });
      }

      // 20. GET /api/gov/status
      if (url.match(/\/api\/gov\/status$/) && method === 'GET') {
        const availableCount = officialGovCases.filter(gc => !issues.some(i => i.id === gc.id)).length;
        return new Response(JSON.stringify({
          connected: isGovConnected,
          gatewayName: 'National e-Gov Unified Civic Grid (CPGRAMS v4.0)',
          officialNode: 'BBMP-GRID-NODE-048',
          lastSyncTime: new Date().toISOString(),
          availableGovRecordsCount: availableCount,
        }), { status: 200, headers: { 'Content-Type': 'application/json' } });
      }

      // 21. POST /api/gov/toggle-connection
      if (url.match(/\/api\/gov\/toggle-connection$/) && method === 'POST') {
        isGovConnected = !isGovConnected;
        persistAll();
        return new Response(JSON.stringify({ connected: isGovConnected }), { status: 200, headers: { 'Content-Type': 'application/json' } });
      }

      // 22. POST /api/gov/sync
      if (url.match(/\/api\/gov\/sync$/) && method === 'POST') {
        if (!isGovConnected) {
          return new Response(JSON.stringify({ error: 'Government gateway is disconnected. Please connect the portal first.' }), { status: 400 });
        }

        let newlySyncedCount = 0;
        officialGovCases.forEach(govCase => {
          if (!issues.some(i => i.id === govCase.id)) {
            issues.unshift({ ...govCase });
            newlySyncedCount++;
          }
        });

        persistAll();
        return new Response(JSON.stringify({
          success: true,
          syncedCount: newlySyncedCount,
          totalIssuesNow: issues.length,
          message: newlySyncedCount > 0 
            ? `Successfully synchronized ${newlySyncedCount} official government cases into your community grid!`
            : 'All official municipal grievance cases are already up-to-date!'
        }), { status: 200, headers: { 'Content-Type': 'application/json' } });
      }

      // 23. POST /api/gov/dispatch
      if (url.match(/\/api\/gov\/dispatch$/) && method === 'POST') {
        const { issueId, ministry, complainantName, email } = body;
        const issue = issues.find(i => i.id === issueId);
        if (!issue) {
          return new Response(JSON.stringify({ error: 'Issue not found in active database.' }), { status: 404 });
        }

        const ticketNumber = `CPG/${issue.city ? issue.city.substring(0, 3).toUpperCase() : 'GEN'}/2026/${Math.floor(100000 + Math.random() * 900000)}`;
        const signature = 'sig_0x' + Array.from({length: 40}, () => Math.floor(Math.random()*16).toString(16)).join('');
        
        const formattedPayload = {
          CPG_SCHEMAS_V4: "https://pgportal.gov.in/CPGRAMS/GrievanceSchemaV4.xsd",
          Grievance_Receipt: {
            Ticket_Number: ticketNumber,
            Timestamp: new Date().toISOString(),
            Gateway_Node: "SECURE_BRIDGE_GATEWAY_NODE_8842",
            Digital_Signature: signature
          },
          Complainant_Profile: {
            Complainant_Name: complainantName || "Anonymous Resident",
            Contact_Email: email || "citizen@atlasone.ai",
            Citizen_Verified_ID: "P2P_VERIFIED_CIVIC_USER"
          },
          Grievance_Details: {
            Title: issue.title,
            Description: issue.description,
            Defect_Category: issue.category,
            Severity_Class: issue.severity,
            Assigned_Ministry: ministry || "Ministry of Road Transport & Highways",
            Reference_Coordinates: issue.location || { lat: 12.9716, lng: 77.5946 },
            Estimated_Repair_Cost: issue.estimatedRepairCost || "₹10,000"
          }
        };

        issue.isGovSynced = true;
        issue.cpgramsDispatch = {
          ticketNumber,
          dispatchedAt: new Date().toISOString(),
          signature,
          payload: formattedPayload,
          ministry: ministry || "Ministry of Road Transport & Highways",
          status: 'dispatched_to_ministry'
        };

        persistAll();
        return new Response(JSON.stringify({
          success: true,
          message: `Issue dispatched successfully to CPGRAMS portal! Designated Ticket Number is: ${ticketNumber}`,
          dispatchReceipt: issue.cpgramsDispatch
        }), { status: 200, headers: { 'Content-Type': 'application/json' } });
      }

      // 24. POST /api/ai-analyze
      if (url.match(/\/api\/ai-analyze$/) && method === 'POST') {
        const mockAnalyses = [
          {
            title: 'Severe Asphalt Pothole',
            description: 'Deep pavement failure with sharp rim boundaries showing underlying gravel and water logging. Poses an immediate vehicular traffic hazard and requires hot-mix asphalt patching.',
            category: 'pothole',
            severity: 'high',
            confidence: 0.94,
            suggestedDepartment: 'Road & Public Works Division',
            estimatedRepairCost: '₹8,500',
            estimatedRepairTime: '4 Hours',
            recommendedPriority: 'high',
            ocrAssetId: null,
          },
          {
            title: 'Overflowing Sewage Drain',
            description: 'Heavy blockage of storm drain grate resulting in surface blackwater runoff, sludge buildup, and strong microbial odor. Immediate back-jetting vacuum truck needed.',
            category: 'overflow_drain',
            severity: 'critical',
            confidence: 0.98,
            suggestedDepartment: 'Water Supply & Sewage Board',
            estimatedRepairCost: '₹6,000',
            estimatedRepairTime: '3 Hours',
            recommendedPriority: 'immediate',
            ocrAssetId: 'POLE-601-W',
          },
          {
            title: 'Illegal Community Trash Pile',
            description: 'Large volumes of municipal garbage, polythene bags, and compostable organic waste accumulated in a non-designated area near public walking path.',
            category: 'garbage',
            severity: 'medium',
            confidence: 0.95,
            suggestedDepartment: 'Solid Waste Management & Sanitation',
            estimatedRepairCost: '₹2,500',
            estimatedRepairTime: '2 Hours',
            recommendedPriority: 'medium',
            ocrAssetId: null,
          },
          {
            title: 'Broken Pole Streetlight',
            description: 'Flickering or completely inactive high-pressure sodium streetlight on support column. Poses a safety hazard for pedestrians during evening hours.',
            category: 'broken_streetlight',
            severity: 'medium',
            confidence: 0.91,
            suggestedDepartment: 'Electrical Grid & Lighting Services',
            estimatedRepairCost: '₹4,200',
            estimatedRepairTime: '1.5 Hours',
            recommendedPriority: 'medium',
            ocrAssetId: 'ST-LT-943-S',
          }
        ];
        const mockResult = mockAnalyses[Math.floor(Math.random() * mockAnalyses.length)];
        
        // Short timeout simulation
        await new Promise(resolve => setTimeout(resolve, 1000));
        return new Response(JSON.stringify({ ...mockResult, simulated: true }), {
          status: 200,
          headers: { 'Content-Type': 'application/json' }
        });
      }

      // 25. POST /api/voice-report
      if (url.match(/\/api\/voice-report$/) && method === 'POST') {
        const { speechText } = body;
        const text = (speechText || '').toLowerCase();
        let category = 'pothole';
        let title = 'Reported via Voice';
        let suggestedDepartment = 'Road & Public Works Division';

        if (text.includes('trash') || text.includes('garbage') || text.includes('waste') || text.includes('dump')) {
          category = 'garbage';
          title = 'Waste dumping reported near location';
          suggestedDepartment = 'Solid Waste Management & Sanitation';
        } else if (text.includes('light') || text.includes('bulb') || text.includes('dark') || text.includes('streetlight')) {
          category = 'broken_streetlight';
          title = 'Broken streetlight report';
          suggestedDepartment = 'Municipal Electricity Board';
        } else if (text.includes('leak') || text.includes('water') || text.includes('pipe')) {
          category = 'water_leakage';
          title = 'Major water line rupture';
          suggestedDepartment = 'Water Supply & Sewage Board';
        } else if (text.includes('flood') || text.includes('rain') || text.includes('waterlogged')) {
          category = 'flood';
          title = 'Flooded road sector';
          suggestedDepartment = 'Drainage Maintenance Unit';
        }

        const mockResult = {
          title,
          description: `Citizen voiced: "${speechText}". Structured automatically using Atlasone AI NLP engine.`,
          category,
          severity: text.includes('dangerous') || text.includes('worst') || text.includes('urgent') ? 'high' : 'medium',
          confidence: 0.91,
          suggestedDepartment,
          estimatedRepairCost: '₹4,000 - ₹10,000',
          estimatedRepairTime: '6 Hours',
          recommendedPriority: text.includes('urgent') ? 'high' : 'medium',
        };

        return new Response(JSON.stringify({ ...mockResult, simulated: true }), {
          status: 200,
          headers: { 'Content-Type': 'application/json' }
        });
      }

      // 26. POST /api/chatbot
      if (url.match(/\/api\/chatbot$/) && method === 'POST') {
        const { messages, userProfile: prof } = body;
        const lastUserMessage = messages?.[messages.length - 1]?.text || 'Hello';
        const text = lastUserMessage.toLowerCase();
        
        let reply = `Hello ${prof?.displayName || 'Citizen'}! I am CivicHero, your community assistant. How can I help you make our neighborhood better today?`;
        
        if (text.includes('pothole') || text.includes('road')) {
          reply = `Road safety is crucial! You can file a pothole report using our **AI Camera Scanner**. It will automatically detect depth, estimate repair costs, and dispatch to the **Roads Department**. Other citizens nearby will get a ping to verify it. You'll earn **100 XP** and **50 Eco-Coins**!`;
        } else if (text.includes('coin') || text.includes('xp') || text.includes('reward') || text.includes('badge')) {
          reply = `You have **${prof?.coins || 100} Eco-Coins** and are at **Level ${prof?.level || 1}**! You earn Eco-Coins and XP by:
  1. Reporting issues (+100 XP, +50 Coins)
  2. Verifying nearby reported problems (+40 XP, +20 Coins)
  3. Upvoting genuine alerts (+10 XP)
  Coins can be redeemed for local transport subsidies, park entry tokens, or donated to local green NGOs!`;
        } else if (text.includes('status') || text.includes('issue') || text.includes('active')) {
          reply = `There are currently **${issues.length} active issues** in our sector. 
  - **1 critical open manhole** near Central Market.
  - **1 streetlight replacement** assigned to Field Specialist Sam.
  You can inspect these live on our **Interactive Grid Map**!`;
        } else if (text.includes('ngo') || text.includes('volunteer')) {
          reply = `How wonderful! You can check our **NGO & CSR Portal**. There is an active **Community Cleaning Drive** this Saturday at Sector 4 park with Save Earth NGO. Volunteers earn **150 XP** and a community certificate!`;
        }

        return new Response(JSON.stringify({ text: reply, simulated: true }), {
          status: 200,
          headers: { 'Content-Type': 'application/json' }
        });
      }

    } catch (err: any) {
      console.error(`Mock API Error on ${method} ${url}:`, err);
      return new Response(JSON.stringify({ error: err.message || 'Internal Server Error' }), { status: 500 });
    }
  }

  // Fallback to normal fetch
  return originalFetch(input, init);
};

try {
  window.fetch = mockFetch;
} catch (e) {
  try {
    Object.defineProperty(window, 'fetch', {
      value: mockFetch,
      writable: true,
      configurable: true,
    });
  } catch (err) {
    console.error('[Mock API Interceptor] Failed to define window.fetch property:', err);
  }
}

console.log('[Mock API Interceptor] Fully initialized.');
