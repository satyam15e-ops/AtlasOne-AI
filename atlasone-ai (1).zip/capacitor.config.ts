import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.atlasone.ai',
  appName: 'Atlasone AI',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  }
};

export default config;
